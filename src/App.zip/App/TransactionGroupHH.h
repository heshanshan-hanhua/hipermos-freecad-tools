﻿/*===================================================================
Copyright (c) 2022 HHIntech
Unpublished - All rights reserved

=====================================================================
File description:
Group object to manager multi transaction for undo/redo.

=====================================================================
Date            Name            Description of Change
2022/07/26      Liulei          Written
2024/05/20      Liulei          Add AddChildTransactions
====================================================================*/

#ifndef APP_TRANSACTION_GROUP_H
#define APP_TRANSACTION_GROUP_H

#include "Transactions.h"

namespace App
{
/** Represents a atomic transaction of the document
 */
class AppExport TransactionGroup : public Transaction
{
    TYPESYSTEM_HEADER();

public:
    /** Construction
     *
     * @param id: transaction id. If zero, then it will be generated
     * automatically as a monotonically increasing index across the entire
     * application. User can pass in a transaction id to group multiple
     * transactions from different document, so that they can be undo/redo
     * together.
     */
    TransactionGroup(int id = 0);
    /// Construction
    virtual ~TransactionGroup();

    /// apply the content to the document
    virtual void apply(Document& Doc, bool forward, const ApplyType& applyTp = ApplyType_None);
    // ****************

    virtual unsigned int getMemSize (void) const;
    virtual void Save (Base::Writer &writer) const;
    /// This method is used to restore properties from an XML document.
    virtual void Restore(Base::XMLReader &reader);

    /// Returns true if the transaction list is empty; otherwise returns false.
    virtual bool isEmpty() const;
    /// check if this object is used in a transaction
    virtual bool hasObject(const TransactionalObject* Obj) const;

    const std::list<App::Transaction*>& GetChildTransactions();
    void SetChildTransactions(const std::list<App::Transaction*>& childTrans);
    void AddChildTransactions(App::Transaction* act);
    App::Transaction* GetLastTransactions();
private:
    std::list<App::Transaction*> _childTransactions;
};
} //namespace App

#endif // APP_TRANSACTION_GROUP_H

