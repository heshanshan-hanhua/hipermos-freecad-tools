/***************************************************************************
 *   Copyright (c) 2011 Jürgen Riegel <juergen.riegel@web.de>              *
 *   Copyright (c) 2011 Werner Mayer <wmayer[at]users.sourceforge.net>     *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/

 /*===================================================================
 Date            Name            Description of Change
 2018/06/06      WangSong        change the order of _objectExcute
 2018/08/30      MZG             Support log
 2018/12/18      JHQ             change redo undo process order in Transaction::apply to fix color bug
 2019/03/27      LL              Add obj apply type
 2019/04/15      WS              apply new after apply all del. Reorder object list when add new and object is existed.
 2021/01/28      WJZ             add GetTransactionMap
 2021/08/18      JHQ             upgrade to 0.19
 2021/09/02      LL              move dealTp to TransactionalObject
 2021/09/03      JHQ             change undo order
 2021/09/10      HSS             change apply(do not set state to DealType_None after applyDel)
 2021/09/11      LL              remove viewprovider while applydel of documentobject
 2021/09/27      LL              add signalApplyNewTransactionObjects
 2021/09/29      LL              revert redo sequence
 2022/03/23      LL              Refactor manufacturing
 2022/07/18      LL              move viewprovider to the back while resort
 2022/07/19      LL              Fixed bug of addobjectNew
 2023/06/29      LL              Fixed bug of property status lost while apply change
 2023/07/21      LL              change apply
 2023/07/20      LL              Support ignore prop changes
 2023/12/26      LL              Extend func of _ignoreChanges
 2023/12/30      LL              Use document ignorepropChange status
 2024/01/11      LL              Support ignore TransactionObject
 2024/08/19      LL              Support set transaction as IsInternal
 2024/12/27      HX              add RemoveSpecifyTransObj/GetSpecifyStatusTransObjs/GetAllTransObjProperty/RemoveSpecifyTransObjProperty
  2024/01/07      HX            when data.isRemovedProperty is true, don't use prop to getPropertyName when redo
 HISTORY
 ====================================================================*/

#include "PreCompiled.h"

#ifndef _PreComp_
# include <cassert>
#endif

#include <atomic>

/// Here the FreeCAD includes sorted by Base,App,Gui......
#include <Base/Writer.h>
using Base::Writer;
#include <Base/Reader.h>
using Base::XMLReader;
#include <Base/Console.h>
#include "Transactions.h"
#include "Property.h"
#include "Document.h"
#include "DocumentObject.h"
#include "Application.h"

FC_LOG_LEVEL_INIT("App",true,true)

using namespace App;
using namespace std;

TYPESYSTEM_SOURCE(App::Transaction, Base::Persistence)

//**************************************************************************
// Construction/Destruction

Transaction::Transaction(int id):_ignoreChanges(false), _internal(false)
{
    if(!id) id = getNewID();
    transID = id;
}

/**
 * A destructor.
 * A more elaborate description of the destructor.
 */
Transaction::~Transaction()
{
    auto &index = _Objects.get<0>();
    for (auto It= index.begin();It!=index.end();++It) {
        if (It->second->status == TransactionObject::New) {
            // If an object has been removed from the document the transaction
            // status is 'New'. The 'pcNameInDocument' member serves as criterion
            // to check whether the object is part of the document or not.
            // Note, it's possible that the transaction status is 'New' while the
            // object is (again) part of the document. This usually happens when
            // a previous removal is undone.
            // Thus, if the object has been removed, i.e. the status is 'New' and
            // is still not part of the document the object must be destroyed not
            // to cause a memory leak. This usually is the case when the removal
            // of an object is not undone or when an addition is undone.

            if (!It->first->isAttachedToDocument()) {
                if (It->first->getTypeId().isDerivedFrom(DocumentObject::getClassTypeId())) {
                    // #0003323: Crash when clearing transaction list
                    // It can happen that when clearing the transaction list several objects
                    // are destroyed with dependencies which can lead to dangling pointers.
                    // When setting the 'Destroy' flag of an object the destructors of link
                    // properties don't ry to remove backlinks, i.e. they don't try to access
                    // possible dangling pointers.
                    // An alternative solution is to call breakDependency inside
                    // Document::_removeObject. Make this change in v0.18.
                    const DocumentObject* obj = static_cast<const DocumentObject*>(It->first);
                    const_cast<DocumentObject*>(obj)->setStatus(ObjectStatus::Destroy, true);
                }
                delete It->first;
            }
        }
        delete It->second;
    }
}

static std::atomic<int> _TransactionID;

int Transaction::getNewID() {
    int id = ++_TransactionID;
    if(id) return id;
    // wrap around? really?
    return ++_TransactionID;
}

int Transaction::getLastID() {
    return _TransactionID;
}

unsigned int Transaction::getMemSize (void) const
{
    return 0;
}

void Transaction::Save (Base::Writer &/*writer*/) const
{
    assert(0);
}

void Transaction::Restore(Base::XMLReader &/*reader*/)
{
    assert(0);
}

int Transaction::getID(void) const
{
    return transID;
}

bool Transaction::isEmpty() const
{
    return _Objects.empty();
}

bool Transaction::hasObject(const TransactionalObject *Obj) const
{
    return !!_Objects.get<1>().count(Obj);
}

void Transaction::addOrRemoveProperty(TransactionalObject *Obj,
                                    const Property* pcProp, bool add)
{
    auto &index = _Objects.get<1>();
    auto pos = index.find(Obj);

    TransactionObject *To;

    if (pos != index.end()) {
        To = pos->second;
    }
    else {
        To = TransactionFactory::instance().createTransaction(Obj->getTypeId());
        To->status = TransactionObject::Chn;
        index.emplace(Obj,To);
    }

    To->addOrRemoveProperty(pcProp,add);
}

//**************************************************************************
// separator for other implementation aspects

// FreeCAD19_Update
void Transaction::apply(Document &Doc, bool forward, const ApplyType& applyTp/* = ApplyType_None*/)
{
    //reorder add or delete process
    bool isNeedReorder = ((Name == "Insert robot") || (Name == "Insert tool") ||
        (Name == "Insert external device"));

    auto& index = _Objects.get<1>();
    auto& index0 = _Objects.get<0>();
    std::vector<const TransactionalObject*> objsTemp;
    for (auto It = index0.begin(); It != index0.end(); ++It)
    {
        const TransactionalObject* pObject = It->first;
        objsTemp.push_back(pObject);
    }
    objsTemp.swap(_ObjectToExecute);
    //the process sequence should be reversed while undo
    if(applyTp == ApplyType_Undo || applyTp == ApplyType_Redo)
    {
        reverse(_ObjectToExecute.begin(), _ObjectToExecute.end());
    }
    
    if (Name == "Delete")
    {
        for (auto item : _ObjectToExecute)
        {
            auto pos = index.find(item);
            if (pos != index.end())
            {
                if ((pos->second->status != TransactionObject::Chn) &&
                    (item->isDerivedFrom(Base::Type::fromName(
                        "StructureBase::StructuralElementGroup"))))
                {
                    isNeedReorder = true;
                    break;
                }
            }
        }
    }

    if (isNeedReorder)
    {
        std::vector<int> viewprovidersIndex;
        std::vector<int> meshObjsIndex;
        std::vector<int> otherObjsIndex;
        std::vector<int> groupObjsIndex;
        for (size_t i = 0; i < _ObjectToExecute.size(); ++i)
        {
            auto pos = index.find(_ObjectToExecute[i]);
            if (pos != index.end())
            {
                if (pos->second->status != TransactionObject::Chn)// only reorder add or delete
                {
                    if (_ObjectToExecute[i]->isDerivedFrom(Base::Type::fromName("Mesh::Feature")))
                    {
                        meshObjsIndex.push_back(i);
                    }
                    else if (_ObjectToExecute[i]->isDerivedFrom(
                        Base::Type::fromName("StructureBase::StructuralElementGroup")))
                    {
                        groupObjsIndex.push_back(i);
                    }
                    else if (_ObjectToExecute[i]->isDerivedFrom(
                        Base::Type::fromName("Gui::ViewProvider")))
                    {
                        viewprovidersIndex.push_back(i);
                    }
                    else
                    {
                        otherObjsIndex.push_back(i);
                    }
                }
                else
                {
                    otherObjsIndex.push_back(i);
                }
            }
        }

        //new order: 1.TransactionViewProvider 2. Mesh::Feature 3. others 4. StructureBase::StructuralElementGroup 
        std::vector<int> newIndex;
        //newIndex.swap(viewprovidersIndex);
        newIndex.insert(newIndex.end(), meshObjsIndex.begin(), meshObjsIndex.end());
        newIndex.insert(newIndex.end(), otherObjsIndex.begin(), otherObjsIndex.end());
        newIndex.insert(newIndex.end(), groupObjsIndex.begin(), groupObjsIndex.end());
        newIndex.insert(newIndex.end(), viewprovidersIndex.begin(), viewprovidersIndex.end());

        std::vector<const TransactionalObject*> newObjectToExecute;
        for (auto item : newIndex)
        {
            newObjectToExecute.push_back(_ObjectToExecute[item]);
        }
        _ObjectToExecute.swap(newObjectToExecute);
    }

    assert(_Objects.size() == _ObjectToExecute.size());
    //set obj deal type before processing
    for (auto obj : _ObjectToExecute)
    {
        TransactionalObject* objTemp = const_cast<TransactionalObject*>(obj);
        switch (applyTp)
        {
        case ApplyType_Redo:
        {
            objTemp->SetDealType(DealType_Redo);
        }
        break;
        case ApplyType_Undo:
        {
            objTemp->SetDealType(DealType_Undo);
        }
        break;
        default:break;
        }
    }

    std::string errMsg;
    try 
    {
        //if abort ,the new object and viewprovider would be deleted at the same time
        if(Doc.IsRollback())
        {
            std::vector< size_t> vpObjsIdxToDel;

            for(size_t ii=0;ii< _ObjectToExecute.size() ;++ii)
            {
                auto obj = _ObjectToExecute[ii];
                auto pos = index.find(obj);
                int state = pos->second->status;
                if(pos != index.end() && state == 1) //delete
                {
                    //we assume that the viewprovider and documentobject are deleted on pair
                    if(obj->isDerivedFrom(Base::Type::fromName("Gui::ViewProvider")) )
                    {
                        vpObjsIdxToDel.insert(vpObjsIdxToDel.begin(),ii);
                    }
                }
            }

            for(auto& vpObjIdx : vpObjsIdxToDel)
            {
                _ObjectToExecute.erase(_ObjectToExecute.begin() + vpObjIdx);
            }
        }

        for(auto obj : _ObjectToExecute)
        {
            auto pos = index.find(obj);
            int state = pos->second->status;
            if(pos != index.end() && state == 1) //delete
            {
                pos->second->applyDel(Doc, const_cast<TransactionalObject*>(obj));
            }
        }

        std::vector<App::TransactionalObject*> newObjs;
        for (auto obj : _ObjectToExecute)
        {
            auto pos = index.find(obj);
            int state = pos->second->status;

            if (pos != index.end() &&state==0) //new
            {
                pos->second->applyNew(Doc, const_cast<TransactionalObject*>(obj));
                newObjs.push_back(const_cast<TransactionalObject*>(obj));
            }
        }
        //refresh object tree nodes after all object is added
        Doc.signalApplyNewTransactionObjects(newObjs);

        for(auto obj : _ObjectToExecute)
        {
            auto pos = index.find(obj);
            int state = pos->second->status;
            if(pos != index.end())
            {
                if((state == 0) || (state == 2))    //New/Chn
                {
                    pos->second->applyChn(Doc, const_cast<TransactionalObject*>(obj), forward);

                    TransactionalObject* objTemp = const_cast<TransactionalObject*>(obj);
                    objTemp->SetDealType(DealType_None);
                }
            }
        }
    }
    catch (Base::Exception& e) {
        e.ReportException();
        errMsg = e.what();
    }
    catch (std::exception& e) {
        errMsg = e.what();
    }
    catch (...) {
        errMsg = "Unknown exception";
    }
    if (errMsg.size()) {
        FC_ERR("Exception on " << (forward ? "redo" : "undo") << " '"
            << Name << "':" << errMsg);
    }
}
// ****************

void Transaction::addObjectNew(TransactionalObject *Obj)
{
    if (_IsIgnore(Obj))
    {
        return;
    }
    auto &index = _Objects.get<1>();
    auto pos = index.find(Obj);
    if (pos != index.end()) {
        //FreeCAD019_update
        // delete from to execute vector;
        auto posInExeV = std::find(_ObjectToExecute.begin(), _ObjectToExecute.end(), pos->first);
        if (posInExeV != _ObjectToExecute.end())
        {
            _ObjectToExecute.erase(posInExeV);
        }
        // ****************

        if (pos->second->status == TransactionObject::Del) {
            delete pos->second;
            delete pos->first;
            index.erase(pos);
        }
        else {
            pos->second->status = TransactionObject::New;
            pos->second->_NameInDocument = Obj->detachFromDocument();
            // move item at the end to make sure the order of removal is kept
            auto &seq = _Objects.get<0>();
            seq.relocate(seq.end(),_Objects.project<0>(pos));

            //FreeCAD019_update
            _ObjectToExecute.insert(_ObjectToExecute.begin(),Obj);
        }
    }
    else {
        TransactionObject *To = TransactionFactory::instance().createTransaction(Obj->getTypeId());
        To->status = TransactionObject::New;
        index.emplace(Obj,To);
        //this may cause property change and interrupt to addObjectChange()
        To->_NameInDocument = Obj->detachFromDocument();
        // add to execute vector;
        _ObjectToExecute.insert(_ObjectToExecute.begin(), Obj);//FreeCAD019_update
    }
}

void Transaction::addObjectDel(const TransactionalObject *Obj)
{
    if (_IsIgnore(Obj))
    {
        return;
    }
    auto &index = _Objects.get<1>();
    auto pos = index.find(Obj);

    // is it created in this transaction ?
    if (pos != index.end() && pos->second->status == TransactionObject::New) {
        //FreeCAD019_update
        auto posInExeV = std::find(_ObjectToExecute.begin(), _ObjectToExecute.end(), pos->first);
        if (posInExeV != _ObjectToExecute.end())
        {
            _ObjectToExecute.erase(posInExeV);
        }
        // ****************

        // remove completely from transaction
        delete pos->second;
        index.erase(pos);
    }
    else if (pos != index.end() && pos->second->status == TransactionObject::Chn) {
        pos->second->status = TransactionObject::Del;
    }
    else {
        TransactionObject *To = TransactionFactory::instance().createTransaction(Obj->getTypeId());
        To->status = TransactionObject::Del;
        index.emplace(Obj,To);

        // add to execute vector;
        _ObjectToExecute.insert(_ObjectToExecute.begin(), Obj); //FreeCAD019_update
    }
}

void Transaction::SetIgnoreChanges(bool ignore)
{
    _ignoreChanges = ignore;
}

void Transaction::addObjectChange(const TransactionalObject *Obj, const Property *Prop)
{
    if (_IsIgnore(Obj))
    {
        return;
    }
    auto &index = _Objects.get<1>();
    auto pos = index.find(Obj);

    TransactionObject *To;

    if (pos != index.end()) {
        To = pos->second;
    }
    else {
        To = TransactionFactory::instance().createTransaction(Obj->getTypeId());
        To->status = TransactionObject::Chn;
        index.emplace(Obj,To);

        // add to execute vector;
        _ObjectToExecute.push_back(Obj);//FreeCAD019_update
    }

    To->setProperty(Prop);
}


void App::Transaction::RemoveSpecifyTransObj(const TransactionalObject* Obj, bool isDestructObj)
{
    if (hasObject(Obj))
    {
        auto& index = _Objects.get<1>();
        auto pos = index.find(Obj);
        if (pos != index.end()) {
            //FreeCAD019_update
            // delete from to execute vector;
            auto posInExeV = std::find(_ObjectToExecute.begin(), _ObjectToExecute.end(), pos->first);
            if (posInExeV != _ObjectToExecute.end())
            {
                _ObjectToExecute.erase(posInExeV);
            }

            delete pos->second;
            if (isDestructObj)
            {
                delete pos->first;
            }
            index.erase(pos);
        }
    }
}

std::vector<const TransactionalObject*> App::Transaction::GetSpecifyStatusTransObjs(int stats)
{
    std::vector<const TransactionalObject*> objs;
    auto& index = _Objects.get<1>();
    for (auto It = index.begin(); It != index.end(); ++It)
    {
        if (It->second->status == (TransactionObject::Status)stats)
        {
            objs.push_back(It->first);
        }
    }
    return objs;
}

std::vector<const Property*> App::Transaction::GetAllTransObjProperty()
{
    std::vector<const Property*> res;
    auto& index = _Objects.get<1>();
    for (auto It = index.begin(); It != index.end(); ++It)
    {
        std::vector<const Property*> curPropertyData = It->second->GetProperty();
        res.insert(res.end(), curPropertyData.begin(), curPropertyData.end());
    }
    return res;
}


void App::Transaction::RemoveSpecifyTransObjProperty(const Property* prop)
{
    auto& index = _Objects.get<1>();
    for (auto It = index.begin(); It != index.end(); ++It)
    {
        It->second->RemoveProperty(prop);
    }
}

bool Transaction::_IsIgnore(const TransactionalObject* obj)
{
    if (_ignoreChanges)
    {
        return true;
    }
    App::Document* doc = App::GetApplication().getActiveDocument();
    if (doc && doc->IsIgnorePropChange())
    {
        return true;
    }

    if (obj && obj->IsIgnoreRedoUndo())
    {
        return true;
    }

    return false;
}

void Transaction::SetIsInternal(bool inter)
{
    _internal = inter;
}

bool Transaction::IsInternal()
{
    return _internal;
}
//**************************************************************************
//**************************************************************************
// TransactionObject
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

TYPESYSTEM_SOURCE_ABSTRACT(App::TransactionObject, Base::Persistence)

//**************************************************************************
// Construction/Destruction

/**
 * A constructor.
 * A more elaborate description of the constructor.
 */
TransactionObject::TransactionObject()
  : status(New)
{
}

/**
 * A destructor.
 * A more elaborate description of the destructor.
 */
TransactionObject::~TransactionObject()
{
    for(auto &v : _PropChangeMap)
        delete v.second.property;
}

void TransactionObject::applyDel(Document & /*Doc*/, TransactionalObject * /*pcObj*/)
{
}

void TransactionObject::applyNew(Document & /*Doc*/, TransactionalObject * /*pcObj*/)
{
}

void TransactionObject::applyChn(Document & /*Doc*/, TransactionalObject *pcObj, bool /* Forward */)
{
    if (status == New || status == Chn) {
        // Property change order is not preserved, as it is recursive in nature
        for(auto &v : _PropChangeMap) {
            auto &data = v.second;
            auto prop = const_cast<Property*>(v.first);

            if(!data.property) {
                // here means we are undoing/redoing and property add operation
                pcObj->removeDynamicProperty(v.second.name.c_str());
                continue;
            }

            // getPropertyName() is specially coded to be safe even if prop has
            // been destroies. We must prepare for the case where user removed
            // a dynamic property but does not recordered as transaction.
            const char* name = NULL;
            if (!data.isRemovedProperty)//if the data isRemovedProperty true, means the prop(v.first) has been destroyed when undo, so it is invalid and don't use it to getPropertyName when redo
            {
                name = pcObj->getPropertyName(prop);
            }
            if(!name) {
                // Here means the original property is not found, probably removed
                if(v.second.name.empty()) {
                    // not a dynamic property, nothing to do
                    continue;
                }

                // It is possible for the dynamic property to be removed and
                // restored. But since restoring property is actually creating
                // a new property, the property key inside redo stack will not
                // match. So we search by name first.
                prop = pcObj->getDynamicPropertyByName(v.second.name.c_str());
                if(!prop) {
                    // Still not found, re-create the property
                    prop = pcObj->addDynamicProperty(
                            data.property->getTypeId().getName(),
                            v.second.name.c_str(), data.group.c_str(), data.doc.c_str(),
                            data.attr, data.readonly, data.hidden);
                    if(!prop)
                        continue;
                    prop->setStatusValue(data.property->getStatus());
                }
            }

            // Many properties do not bother implement Copy() and accepts
            // derived types just fine in Paste(). So we do not enforce type
            // matching here. But instead, strengthen type checking in all
            // Paste() implementation.
            //
            // if(data.propertyType != prop->getTypeId()) {
            //     FC_WARN("Cannot " << (Forward?"redo":"undo")
            //             << " change of property " << prop->getName()
            //             << " because of type change: "
            //             << data.propertyType.getName()
            //             << " -> " << prop->getTypeId().getName());
            //     continue;
            // }
            try 
            {
                prop->setStatus(App::Property::User4, data.property->testStatus(App::Property::User4));
                prop->Paste(*data.property);
   
                //prop->setStatusValue(data.property->getStatus());
            } catch (Base::Exception &e) {
                e.ReportException();
                FC_ERR("exception while restoring " << prop->getFullName() << ": " << e.what());
            } catch (std::exception &e) {
                FC_ERR("exception while restoring " << prop->getFullName() << ": " << e.what());
            } catch (...)
            {}
        }
    }
}

void TransactionObject::setProperty(const Property* pcProp)
{
    auto &data = _PropChangeMap[pcProp];
    if(!data.property && data.name.empty()) {
        static_cast<DynamicProperty::PropData&>(data) = 
            pcProp->getContainer()->getDynamicPropertyData(pcProp);
        data.property = pcProp->Copy();
        data.propertyType = pcProp->getTypeId();
        data.property->setStatusValue(pcProp->getStatus());
    }
}

void TransactionObject::addOrRemoveProperty(const Property* pcProp, bool add)
{
    (void)add;
    if(!pcProp || !pcProp->getContainer())
        return;

    auto &data = _PropChangeMap[pcProp];
    if(data.name.size()) {
        if(!add && !data.property) {
            // this means add and remove the same property inside a single
            // transaction, so they cancel each other out.
            _PropChangeMap.erase(pcProp);
        }
        return;
    }
    if(data.property) {
        delete data.property;
        data.property = 0;
    }

    static_cast<DynamicProperty::PropData&>(data) = 
        pcProp->getContainer()->getDynamicPropertyData(pcProp);
    if(add) 
        data.property = 0;
    else {
        data.property = pcProp->Copy();
        data.propertyType = pcProp->getTypeId();
        data.property->setStatusValue(pcProp->getStatus());
        data.isRemovedProperty = true;
    }
}

std::vector<const Property*> App::TransactionObject::GetProperty()
{
    std::vector<const Property*> res;
    for (auto& item : _PropChangeMap)
    {
        const Property* pFirst = item.first;
        res.push_back(pFirst);
    }
    return res;
}

void App::TransactionObject::RemoveProperty(const Property* pcProp)
{
    if (_PropChangeMap.count(pcProp))
    {
        _PropChangeMap.erase(pcProp);
    }
}

unsigned int TransactionObject::getMemSize (void) const
{
    return 0;
}

void TransactionObject::Save (Base::Writer &/*writer*/) const
{
    assert(0);
}

void TransactionObject::Restore(Base::XMLReader &/*reader*/)
{
    assert(0);
}

//**************************************************************************
//**************************************************************************
// TransactionDocumentObject
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

TYPESYSTEM_SOURCE_ABSTRACT(App::TransactionDocumentObject, App::TransactionObject)

//**************************************************************************
// Construction/Destruction

/**
 * A constructor.
 * A more elaborate description of the constructor.
 */
TransactionDocumentObject::TransactionDocumentObject()
{
}

/**
 * A destructor.
 * A more elaborate description of the destructor.
 */
TransactionDocumentObject::~TransactionDocumentObject()
{
}

void TransactionDocumentObject::applyDel(Document &Doc, TransactionalObject *pcObj)
{
    if (status == Del) {
        DocumentObject* obj = static_cast<DocumentObject*>(pcObj);

#ifndef USE_OLD_DAG
        //Make sure the backlinks of all linked objects are updated. As the links of the removed
        //object are never set to [] they also do not remove the backlink. But as they are 
        //not in the document anymore we need to remove them anyway to ensure a correct graph
        auto list = obj->getOutList();
        for (auto link : list)
            link->_removeBackLink(obj);
#endif

        // simply filling in the saved object
        Doc._removeObject(obj);

        //FreeCAD019_update
        // <YJ> 26-Sep-2017
        // After add the del object, the property has been lost, in order to go to the DocumentItem::slotChangeObject
        // at last to rearrange the hierarchy of the tree views, add the first property to the object, the first must
        // be the Label setValue, because each time when addObject, the Label is setValue. (Refactor the transaction undo/redo)
        //if (!_PropChangeMap.empty())
        //{
        //    auto It = _PropChangeMap.begin();
        //    Doc._chnObject(obj, const_cast<Property*>(It->first));
        //}
        // ****************
    }
}

void TransactionDocumentObject::applyNew(Document &Doc, TransactionalObject *pcObj)
{
    if (status == New) {
        DocumentObject* obj = static_cast<DocumentObject*>(pcObj);
        Doc._addObject(obj, _NameInDocument.c_str());

#ifndef USE_OLD_DAG
        //make sure the backlinks of all linked objects are updated
        auto list = obj->getOutList();
        for (auto link : list)
            link->_addBackLink(obj);
#endif
    }
}

//**************************************************************************
//**************************************************************************
// TransactionFactory
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

App::TransactionFactory* App::TransactionFactory::self = nullptr;

TransactionFactory& TransactionFactory::instance()
{
    if (self == nullptr)
        self = new TransactionFactory;
    return *self;
}

void TransactionFactory::destruct()
{
    delete self;
    self = nullptr;
}

void TransactionFactory::addProducer (const Base::Type& type, Base::AbstractProducer *producer)
{
    producers[type] = producer;
}

/**
 * Creates a transaction object for the given type id.
 */
TransactionObject* TransactionFactory::createTransaction (const Base::Type& type) const
{
    std::map<Base::Type, Base::AbstractProducer*>::const_iterator it;
    for (it = producers.begin(); it != producers.end(); ++it) {
        if (type.isDerivedFrom(it->first)) {
            return static_cast<TransactionObject*>(it->second->Produce());
        }
    }

    assert(0);
    return nullptr;
}

//FreeCAD019_update
void TransactionObject::Dumping()
{
    Base::Console().Log("TransactionObject Dumping: %d Property Change Map\n", _PropChangeMap.size());
    for (auto item : _PropChangeMap)
    {
        const Property* pFirst = item.first;
        PropData& pSecond = item.second;
        if (pSecond.property && pSecond.property->getContainer() != NULL)
        {
            Base::Console().Log("    first %s , mem size %d; second %s, mem size %d. \n",
                pFirst->getName(), pFirst->getMemSize(),
                pSecond.property->getName(), pSecond.property->getMemSize());
        }
        else
        {
            Base::Console().Log("    first %s , mem size %d; second , NULL \n",
                pFirst->getName(), pFirst->getMemSize());
        }
    }
}


void App::Transaction::DumpTransaction()
{
    Base::Console().Log("Transaction Dumping: %s\n", this->Name.c_str());

    auto& index = _Objects.get<0>();
    for (auto It = index.begin(); It != index.end(); ++It)
    {
        const TransactionalObject* pObject = It->first;

        const DocumentObject* object = static_cast<const DocumentObject*>(pObject);
        Base::Console().Log(" Object: %s\n", object->getNameInDocument(), object->getMemSize());
        if (It->second)
            It->second->Dumping();
        else
            Base::Console().Log(" Transaction Object: NULL\n");
    }
}
// ****************