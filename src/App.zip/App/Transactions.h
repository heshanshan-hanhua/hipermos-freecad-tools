/***************************************************************************
 *   Copyright (c) 2011 Jürgen Riegel <juergen.riegel@web.de>              *
 *   Copyright (c) 2011 Werner Mayer <wmayer[at]users.sourceforge.net>     *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/

 /*===================================================================
 Date            Name            Description of Change
 2019/03/27      LL              Add obj apply type
 2021/01/28      WJZ             add GetTransactionMap
 2021/08/18      JHQ             upgrade to 0.19
 2022/07/27      LL              Support combine redo/undo
 2023/07/20      LL              Support ignore prop changes
 2024/01/11      LL              Support ignore TransactionObject
 2024/08/19      LL              Support set transaction as IsInternal
 2024/12/27      HX              add RemoveSpecifyTransObj/GetSpecifyStatusTransObjs/GetAllTransObjProperty/RemoveSpecifyTransObjProperty
 2025/01/06      HX              add isRemovedProperty into PropData
 HISTORY
 ====================================================================*/

#ifndef APP_TRANSACTION_H
#define APP_TRANSACTION_H

#include <unordered_map>
#include <Base/Factory.h>
#include <Base/Persistence.h>
#include <App/PropertyContainer.h>

namespace App
{

class Document;
class Property;
class Transaction;
class TransactionObject;
class TransactionalObject;


/** Represents a atomic transaction of the document
 */
class AppExport Transaction : public Base::Persistence
{
    TYPESYSTEM_HEADER();

public:

    // FreeCAD19_Update
    enum ApplyType
    {
        ApplyType_None = 0,
        ApplyType_Undo = 1,
        ApplyType_Redo = 2,
    };
    // ****************

    /** Construction
     *
     * @param id: transaction id. If zero, then it will be generated
     * automatically as a monotonically increasing index across the entire
     * application. User can pass in a transaction id to group multiple
     * transactions from different document, so that they can be undo/redo
     * together.
     */
    Transaction(int id = 0);
    /// Construction
    virtual ~Transaction();

    // FreeCAD19_Update
    /// apply the content to the document
    virtual void apply(Document& Doc, bool forward, const ApplyType& applyTp = ApplyType_None);
    void DumpTransaction();
    //const std::map<const DocumentObject*, TransactionObject*>& GetTransactionMap() const;

    void SetIgnoreChanges(bool ignore);

    void SetIsInternal(bool inter);
    bool IsInternal();
    // ****************

    // the utf-8 name of the transaction
    std::string Name;

    virtual unsigned int getMemSize (void) const;
    virtual void Save (Base::Writer &writer) const;
    /// This method is used to restore properties from an XML document.
    virtual void Restore(Base::XMLReader &reader);

    /// Return the transaction ID
    int getID(void) const;

    /// Generate a new unique transaction ID
    static int getNewID(void);
    static int getLastID(void);

    /// Returns true if the transaction list is empty; otherwise returns false.
    virtual bool isEmpty() const;
    /// check if this object is used in a transaction
    virtual bool hasObject(const TransactionalObject *Obj) const;
    void addOrRemoveProperty(TransactionalObject *Obj, const Property* pcProp, bool add);

    void addObjectNew(TransactionalObject *Obj);
    void addObjectDel(const TransactionalObject *Obj);
    void addObjectChange(const TransactionalObject* Obj, const Property* Prop);
    void RemoveSpecifyTransObj(const TransactionalObject* transObj,bool isDestructObj);
    std::vector<const TransactionalObject*>  GetSpecifyStatusTransObjs(int stats);
    std::vector<const Property*> GetAllTransObjProperty();
    void RemoveSpecifyTransObjProperty(const Property*);
private:
    int transID;
    typedef std::pair<const TransactionalObject*, TransactionObject*> Info;
    bmi::multi_index_container<Info,bmi::indexed_by<bmi::sequenced<>,bmi::hashed_unique<bmi::member<Info, const TransactionalObject*, &Info::first>>>
    > _Objects;

    bool _IsIgnore(const TransactionalObject* obj);
    std::vector<const TransactionalObject*> _ObjectToExecute; //FreeCAD019_update
    bool _ignoreChanges;
    //internal transaction is not show in undo list
    bool _internal;
};

/** Represents an entry for an object in a Transaction
 */
class AppExport TransactionObject : public Base::Persistence
{
    TYPESYSTEM_HEADER();

public:
    /// Construction
    TransactionObject();
    /// Destruction
    virtual ~TransactionObject();

    virtual void applyNew(Document &Doc, TransactionalObject *pcObj);
    virtual void applyDel(Document &Doc, TransactionalObject *pcObj);
    virtual void applyChn(Document &Doc, TransactionalObject *pcObj, bool Forward);

    void setProperty(const Property* pcProp);
    void addOrRemoveProperty(const Property* pcProp, bool add);
    std::vector<const Property*> GetProperty();
    void RemoveProperty(const Property* pcProp);
    virtual unsigned int getMemSize (void) const;
    virtual void Save (Base::Writer &writer) const;
    /// This method is used to restore properties from an XML document.
    virtual void Restore(Base::XMLReader &reader);

    friend class Transaction;

    void Dumping(); //FreeCAD019_update
protected:
    enum Status { New, Del, Chn } status;

    struct PropData : DynamicProperty::PropData {
        Base::Type propertyType;
        bool isRemovedProperty = false;
    };
    std::unordered_map<const Property*, PropData> _PropChangeMap;

    std::string _NameInDocument;
};

/** Represents an entry for a document object in a transaction
 */
class AppExport TransactionDocumentObject : public TransactionObject
{
    TYPESYSTEM_HEADER();

public:
    /// Construction
    TransactionDocumentObject();
    /// Destruction
    virtual ~TransactionDocumentObject();

    void applyNew(Document &Doc, TransactionalObject *pcObj);
    void applyDel(Document &Doc, TransactionalObject *pcObj);
};

class AppExport TransactionFactory
{
public:
    static TransactionFactory& instance();
    static void destruct ();

    TransactionObject* createTransaction (const Base::Type& type) const;
    void addProducer (const Base::Type& type, Base::AbstractProducer *producer);

private:
    static TransactionFactory* self;
    std::map<Base::Type, Base::AbstractProducer*> producers;

    TransactionFactory(){}
    ~TransactionFactory(){}
};

template <class CLASS>
class TransactionProducer : public Base::AbstractProducer
{
public:
    TransactionProducer (const Base::Type& type)
    {
        TransactionFactory::instance().addProducer(type, this);
    }

    virtual ~TransactionProducer (){}

    /**
     * Creates an instance of the specified transaction object.
     */
    virtual void* Produce () const
    {
        return (new CLASS);
    }
};

} //namespace App

#endif // APP_TRANSACTION_H

