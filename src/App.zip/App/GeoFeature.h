/***************************************************************************
 *   Copyright (c) 2002 Jürgen Riegel <juergen.riegel@web.de>              *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/

 /*===================================================================
 Date           Name        Description of Change
 2018/06/26     LL          add getGeoFeatures
 2018/07/09     LL          move signalStateChange from csys to here for 
                            observing obj placement change
 2018/07/26     LL          Add OnDeleted
 2018/11/12     WJZ         code refactor
 2020/05/22     WJZ         Add GeoLocalPlacement
 2021/08/31     JHQ         Add GeoLocalPlacement
 2021/08/18     JHQ         update to FreeCAD19
 2022/12/14      LL         Add para to signalStateChange
 2023/05/08      LJ         Add CopyObjectProperties
 2023/06/30      LL         Add obj in signalStateChange
 2024/01/25      LL         Add default para useWhole of GetGeoFeatures
 2024/12/26      LL         Do not update state while undo/redo
 HISTORY
 ====================================================================*/


#ifndef APP_GEOFEATURE_H
#define APP_GEOFEATURE_H

#include "DocumentObject.h"
#include "PropertyGeo.h"

#include <boost_signals2.hpp>//FreeCAD019_update


namespace App
{


/** Base class of all geometric document objects.
 */
class AppExport GeoFeature : public App::DocumentObject
{
    PROPERTY_HEADER(App::GeoFeature);

public:
    PropertyPlacement Placement;

    PropertyPlacement GeoLocalPlacement;//FreeCAD019_update
    /// Constructor
    GeoFeature(void);
    virtual ~GeoFeature();

    /**
     * @brief transformPlacement applies transform to placement of this shape.
     * Override this function to propagate the change of placement to base
     * features, for example. By the time of writing this comment, the function
     * was only called by alignment task (Edit->Alignment)
     * @param transform (input).
     */
    virtual void transformPlacement(const Base::Placement &transform);
    /**
     * This method returns the main property of a geometric object that holds
     * the actual geometry. For a part object this is the Shape property, for
     * a mesh object the Mesh property and so on.
     * The default implementation returns null.
     */
    virtual const PropertyComplexGeoData* getPropertyOfGeometry() const;
    /**
     * @brief getPyObject returns the Python binding object
     * @return the Python binding object
     */
    virtual PyObject* getPyObject(void);

    /// Specify the type of element name to return when calling getElementName() 
    enum ElementNameType {
        /// Normal usage
        Normal=0,
        /// For importing
        Import=1,
        /// For exporting
        Export=2,
    };
    /** Return the new and old style sub-element name
     *
     * @param name: input name
     * @param type: desired element name type to return
     *
     * @return a pair(newName,oldName). New element name may be empty.
     *
     * This function currently is does nothing. The new style element name
     * generation will be added in the next batch of patches.
     */
    virtual std::pair<std::string,std::string> getElementName(
            const char *name, ElementNameType type=Normal) const;

    /** Resolve both the new and old style element name
     *
     * @param obj: top parent object
     * @param subname: subname reference 
     * @param elementName: output of a pair(newElementName,oldElementName)
     * @param append: Whether to include subname prefix into the returned
     *                element name
     * @param type: the type of element name to request
     * @param filter: If none zero, then only perform lookup when the element
     *                owner object is the same as this filter
     * @param element: return the start of element name in subname
     *
     * @return Return the owner object of the element
     */
    static DocumentObject *resolveElement(App::DocumentObject *obj, 
            const char *subname, std::pair<std::string,std::string> &elementName, 
            bool append=false, ElementNameType type=Normal,
            const DocumentObject *filter=0,const char **element=0, GeoFeature **geo=0);

    /**
     * @brief Calculates the placement in the global reference coordinate system
     * 
     * In FreeCAD the GeoFeature placement describes the local placement of the object in its parent
     * coordinate system. This is however not always the same as the global reference system. If the
     * object is in a GeoFeatureGroup, hence in another local coordinate system, the Placement
     * property does only give the local transformation. This function can be used to calculate the 
     * placement of the object in the global reference coordinate system taking all stacked local 
     * systems into account.
     * 
     * @return Base::Placement The transformation from the global reference coordinate system
     */
    Base::Placement globalPlacement() const;


    //FreeCAD019_update
    //get the real geo object of element
    virtual std::vector<GeoFeature*> GetGeoFeatures(bool useWhole = true);

    virtual void Restore(Base::XMLReader&/*reader*/);

    boost::signals2::signal<void(bool statu,App::DocumentObject* obj)> signalStateChange;

    void SetSetupStatuChangable(bool changable) { _isSetupStatuChangable = changable; }
    bool GetSetupStatuChangable() const { return _isSetupStatuChangable; }
    virtual void OnDeleted();

    virtual void CopyObjectProperties(DocumentObject* obj);
private:
    bool _isSetupStatuChangable; //LL 2018-01-03 deal with the condition that setup statu should not change
                                 //while the setup relationship change, for example restore the document
    // ****************
};

} //namespace App


#endif // APP_GEOFEATURE_H
