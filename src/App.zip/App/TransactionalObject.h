/***************************************************************************
 *   Copyright (c) 2016 Werner Mayer <wmayer[at]users.sourceforge.net>     *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/
//2021/09/02      LL              move dealTp to TransactionalObject
//2024/01/11      LL              Add IsIgnore

#ifndef APP_TRANSACTIONALOBJECT_H
#define APP_TRANSACTIONALOBJECT_H

#include <App/ExtensionContainer.h>

namespace App
{

class Document;
class TransactionObject;

//FreeCAD19_update
enum DealType
{
    DealType_None = 0,
    DealType_New = 1,
    DealType_Delete = 2,
    DealType_Change = 3,
    DealType_Undo = 4,
    DealType_Redo = 5,
};

/** Base class of transactional objects
 */
class AppExport TransactionalObject : public App::ExtensionContainer
{
    PROPERTY_HEADER(App::TransactionalObject);

public:
    /// Constructor
    TransactionalObject(void);
    virtual ~TransactionalObject();
    virtual bool isAttachedToDocument() const;
    virtual const char* detachFromDocument();

    //FreeCAD19_update
    void SetDealType(const DealType& tp);
    const DealType& GetDealType() const;

    void SetIgnoreRedoUndo(bool ig);
    bool IsIgnoreRedoUndo() const;
    //
protected:
    void onBeforeChangeProperty(Document *doc, const Property *prop);

private:
    DealType _dealTp;//FreeCAD019_update
    bool _isIgnoreRedoUndo;
};

} //namespace App


#endif // APP_TRANSACTIONALOBJECT_H
