/***************************************************************************
 *   Copyright (c) 2013 Jürgen Riegel (FreeCAD@juergen-riegel.net)         *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/

//2018-07-25             MZG                  Written

#ifndef SYSTEM_INFO_H
#define SYSTEM_INFO_H

#include "PreCompiled.h"
#include <QProcess> 
#include <QSysInfo>

using namespace std;

namespace App
{
    class SystemInfo {
        public:
            static QString getOperatingSystem()
            {
#if defined (Q_OS_WIN32)
                switch(QSysInfo::windowsVersion())
                {
                    case QSysInfo::WV_NT:
                        return QString::fromLatin1("Windows NT");
                    case QSysInfo::WV_2000:
                        return QString::fromLatin1("Windows 2000");
                    case QSysInfo::WV_XP:
                        return QString::fromLatin1("Windows XP");
                    case QSysInfo::WV_2003:
                        return QString::fromLatin1("Windows Server 2003");
                    case QSysInfo::WV_VISTA:
                        return QString::fromLatin1("Windows Vista");
                    case QSysInfo::WV_WINDOWS7:
                        return QString::fromLatin1("Windows 7");
#if QT_VERSION >= 0x040800
                    case QSysInfo::WV_WINDOWS8:
                        return QString::fromLatin1("Windows 8");
#endif
#if ((QT_VERSION >= 0x050200) || (QT_VERSION >= 0x040806 && QT_VERSION < 0x050000))
                    case QSysInfo::WV_WINDOWS8_1:
                        return QString::fromLatin1("Windows 8.1");
#endif
#if QT_VERSION >= 0x040807
                    case QSysInfo::WV_WINDOWS10:
                        return QString::fromLatin1("Windows 10");
#endif
                    default:
                        return QString::fromLatin1("Windows");
                }
#elif defined (Q_OS_MAC)
                switch(QSysInfo::MacVersion())
                {
                    case QSysInfo::MV_10_3:
                        return QString::fromLatin1("Mac OS X 10.3");
                    case QSysInfo::MV_10_4:
                        return QString::fromLatin1("Mac OS X 10.4");
                    case QSysInfo::MV_10_5:
                        return QString::fromLatin1("Mac OS X 10.5");
#if QT_VERSION >= 0x040700
                    case QSysInfo::MV_10_6:
                        return QString::fromLatin1("Mac OS X 10.6");
#endif
#if QT_VERSION >= 0x040800
                    case QSysInfo::MV_10_7:
                        return QString::fromLatin1("Mac OS X 10.7");
                    case QSysInfo::MV_10_8:
                        return QString::fromLatin1("Mac OS X 10.8");
                    case QSysInfo::MV_10_9:
                        return QString::fromLatin1("Mac OS X 10.9");
#endif
                    default:
                        return QString::fromLatin1("Mac OS X");
                }
#elif defined (Q_OS_LINUX)
                QString exe(QLatin1String("lsb_release"));
                QStringList args;
                args << QLatin1String("-ds");
                QProcess proc;
                proc.setEnvironment(QProcess::systemEnvironment());
                proc.start(exe, args);
                if (proc.waitForStarted() && proc.waitForFinished()) {
                    QByteArray info = proc.readAll();
                    info.replace('\n',"");
                    return QString::fromLatin1((const char*)info);
                }

                return QString::fromLatin1("Linux");
#elif defined (Q_OS_UNIX)
                return QString::fromLatin1("UNIX");
#else
                return QString();
#endif
            }

            static int getWordSizeOfOS()
            {
#if defined(Q_OS_WIN64)
                return 64; // 64-bit process running on 64-bit windows
#elif defined(Q_OS_WIN32)

                // determine if 32-bit process running on 64-bit windows in WOW64 emulation
                // or 32-bit process running on 32-bit windows
                // default bIsWow64 to false for 32-bit process on 32-bit windows

                BOOL bIsWow64 = false; // must default to false
                typedef BOOL (WINAPI *LPFN_ISWOW64PROCESS) (HANDLE, PBOOL);

                LPFN_ISWOW64PROCESS fnIsWow64Process = (LPFN_ISWOW64PROCESS) GetProcAddress(
                        GetModuleHandle("kernel32"), "IsWow64Process");

                if (NULL != fnIsWow64Process) {
                    if (!fnIsWow64Process(GetCurrentProcess(), &bIsWow64)) {
                        assert(false); // something went majorly wrong
                    }
                }
                return bIsWow64 ? 64 : 32;

#elif defined (Q_OS_LINUX)
                // http://stackoverflow.com/questions/246007/how-to-determine-whether-a-given-linux-is-32-bit-or-64-bit
                QString exe(QLatin1String("getconf"));
                QStringList args;
                args << QLatin1String("LONG_BIT");
                QProcess proc;
                proc.setEnvironment(QProcess::systemEnvironment());
                proc.start(exe, args);
                if (proc.waitForStarted() && proc.waitForFinished()) {
                    QByteArray info = proc.readAll();
                    info.replace('\n',"");
                    return info.toInt();
                }

                return 0; // failed

#elif defined (Q_OS_UNIX) || defined (Q_OS_MAC)
                QString exe(QLatin1String("uname"));
                QStringList args;
                args << QLatin1String("-m");
                QProcess proc;
                proc.setEnvironment(QProcess::systemEnvironment());
                proc.start(exe, args);
                if (proc.waitForStarted() && proc.waitForFinished()) {
                    QByteArray info = proc.readAll();
                    info.replace('\n',"");
                    if (info.indexOf("x86_64") >= 0)
                        return 64;
                    else if (info.indexOf("amd64") >= 0)
                        return 64;
                    else if (info.indexOf("ia64") >= 0)
                        return 64;
                    else if (info.indexOf("ppc64") >= 0)
                        return 64;
                    else if (info.indexOf("i386") >= 0)
                        return 32;
                    else if (info.indexOf("i686") >= 0)
                        return 32;
                    else if (info.indexOf("x86") >= 0)
                        return 32;
                }

                return 0; // failed
#else
                return 0; // unknown
#endif
            }
    };
} //namespace App


#endif // SYSTEM_INFO_H
