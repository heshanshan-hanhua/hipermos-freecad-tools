/*===================================================================
Copyright (c) 2019
Unpublished - All rights reserved

=====================================================================
File description:
the class for version information management

=====================================================================
Date            Name            Description of Change
2018/07/25      MZG        Written
2021/08/18      JHQ        upgrade to 0.19

HISTORY
====================================================================*/

#include "PreCompiled.h"

#ifndef _PreComp_
#endif

#include "VersionObjectHH.h"

using namespace App;
using namespace std;

PROPERTY_SOURCE(App::VersionObjectHH, App::DocumentObject)

VersionObjectHH::VersionObjectHH()
{
    ADD_PROPERTY_TYPE(Versions, (""), "Versions", App::PropertyType(Prop_None | Prop_Hidden), "Versions");
    ADD_PROPERTY_TYPE(Times, (""), "Times", App::PropertyType(Prop_None | Prop_Hidden), "Times");
    ADD_PROPERTY_TYPE(Machines, (""), "Machines", App::PropertyType(Prop_None | Prop_Hidden), "Machines");
    ADD_PROPERTY_TYPE(Authors, (""), "Authors", App::PropertyType(Prop_None | Prop_Hidden), "Authors");
    ADD_PROPERTY_TYPE(Programs, (""), "Programs", App::PropertyType(Prop_None | Prop_Hidden), "Programs");
    ADD_PROPERTY_TYPE(Licenses, (""), "Licenses", App::PropertyType(Prop_None | Prop_Hidden), "Licenses");

    Versions.setSize(0);
    Times.setSize(0);
    Machines.setSize(0);
    Authors.setSize(0);
    Programs.setSize(0);
    Licenses.setSize(0);
}

VersionObjectHH::~VersionObjectHH()
{
}

void VersionObjectHH::AppendSaveRecord(string ver, string time, string mach, string author, string prog, string lic)
{
    const_cast<vector<string>&>(Versions.getValues()).push_back(ver);
    const_cast<vector<string>&>(Times.getValues()).push_back(time);
    const_cast<vector<string>&>(Machines.getValues()).push_back(mach);
    const_cast<vector<string>&>(Authors.getValues()).push_back(author);
    const_cast<vector<string>&>(Programs.getValues()).push_back(prog);
    const_cast<vector<string>&>(Licenses.getValues()).push_back(lic);
}


void VersionObjectHH::SetOpenRecord(string ver, string time, string mach, string author, string prog, string lic)
{
    _openRecord.ver = ver;
    _openRecord.time = time;
    _openRecord.mach = mach;
    _openRecord.auth = author;
    _openRecord.prog = prog;
    _openRecord.lic = lic;
}

VersionRecord VersionObjectHH::GetOpenRecord()
{
    return _openRecord;
}

vector<VersionRecord> VersionObjectHH::GetSaveRecord()
{
    vector<VersionRecord> res;

    if (!IsValid())
        return res;

    int size = Times.getSize();
    for (int i = 0; i < size; i++)
    {
        VersionRecord tmp;

        tmp.ver = Versions[i];
        tmp.time = Times[i];
        tmp.mach = Machines[i];
        tmp.auth = Authors[i];
        tmp.prog = Programs[i];
        tmp.lic = Licenses[i];

        res.push_back(tmp);
    }

    return res;
}


bool VersionObjectHH::IsValid()
{
    int size = Times.getSize();
    if (size != Machines.getSize() ||
        size != Authors.getSize() ||
        size != Programs.getSize() ||
        size != Licenses.getSize() ||
        size != Versions.getSize())
        return false;

    return true;
}
