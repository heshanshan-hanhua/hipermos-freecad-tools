/*===================================================================
Copyright (c) 2018
Unpublished - All rights reserved

=====================================================================
File description:
the errors of App

=====================================================================
Date            Name            Description of Change
2018/07/23      MZG             Written
2019/03/23      LL              Add InvalidShapeForExport
2021/09/08      ZJF             Set HiperMOS style
2022/01/13      WS              add AppError_NotSupportedFormat
2022/01/23      LL              add AppError_ProjectFileIsNewer & AppError_CannotCreateObject
2022/03/23      LL              add AppError_NoActiveDoc
2022/06/24      LL              Fixed translate of ProjecFileIsNewer
2022/07/14      LL              Add FailedToOpenFile and FileSaved
2022/07/18      ZJF             normalize text info
2023/02/05      LL              add ExportShapeIsNull
2023/02/09      HX              add AppError_ExceptionCaughtWithMessage,AppError_UnknownExceptionCaught
2023/07/16      LL              add AppError_NoShapeOfTypeCanExport
2023/09/25      LL              Add InvalidFilePath InvalidFileExtension
2024/05/27      WS              add AppError_InvalidFilePathWithName
2024/05/28      WS              change AppError_InvalidFilePathWithName
2024/11/26      LL              add some file error
2024/11/27      LL              add error of RequireAdministrator
2025/01/10      LL              add error of NoAuthorized
2025/02/11      LL              add error of NeedAdministratorPrivilegeToSaveFile and NeedWritePermissionToSaveFile
HISTORY
====================================================================*/
#include "PreCompiled.h"
#include "AppErrorList.h"
#include <QtCore/qglobal.h>

namespace App
{
    AppErrorList::AppErrorList():
        _errorInfo({
            {AppError_Default, QT_TRANSLATE_NOOP("ErrorList", "Unknown error!")},
            {AppError_InvalidDocument, QT_TRANSLATE_NOOP("ErrorList", "Invalid file!")},
            {AppError_CannotOpenNewerVersion, QT_TRANSLATE_NOOP("ErrorList", "Could not open file from a newer version of HiperMOS than this one!")},
            {AppError_InvalidShapeForExport, QT_TRANSLATE_NOOP("ErrorList", "'%1' is not a shape, export will be ignored!") },
            {AppError_NotSupportedFormat, QT_TRANSLATE_NOOP("ErrorList", "File format cannot open: '%1'!")},
            {AppError_ProjectFileIsNewer, QT_TRANSLATE_NOOP("ErrorList", "The project file you are opening was created with a new version of the software!\nTo ensure the project is opened correctly, please upgrade your software!")},
            {AppError_CannotCreateObject,QT_TRANSLATE_NOOP("ErrorList", "Cannot create object: '%1'!\nPlease make sure your software is authorized for this function module!")},
            {AppError_PropertyTypeChanged,QT_TRANSLATE_NOOP("ErrorList", "A property with the same name but different type has been removed!")},
            {AppError_UnsupportedType,QT_TRANSLATE_NOOP("ErrorList", "The specified type is unsupported!")},
            {AppError_CannotCreateObjAs, QT_TRANSLATE_NOOP("ErrorList", "Cannot create object %1: %2!") },
            { AppError_NoActiveDoc, QT_TRANSLATE_NOOP("ErrorList", "No active document!") },
            {AppError_FailedToOpenFile, QT_TRANSLATE_NOOP("ErrorList", "The file '%1' is open failed!\nPlease check the file path and read-write permission!") },
            {AppError_FileSaved,QT_TRANSLATE_NOOP("ErrorList", "'%1' is saved.") },

            {AppError_ExportShapeIsNull,QT_TRANSLATE_NOOP("ErrorList", "'%1' has null shape.") },
            {AppError_NoShapeOfTypeCanExport,QT_TRANSLATE_NOOP("ErrorList", "None shape of type '%1' can be exported.") },
            {AppError_ExceptionCaughtWithMessage,QT_TRANSLATE_NOOP("ErrorList", "Exception caught.\nThe error message is: %1\n") },
            {AppError_UnknownExceptionCaught,QT_TRANSLATE_NOOP("ErrorList", "Unknown exception caught.\n") },
            {AppError_InvalidFilePath,QT_TRANSLATE_NOOP("ErrorList", "File path is invalid.\n") },
            {AppError_InvalidFilePathWithName, QT_TRANSLATE_NOOP("ErrorList", "%1: File path \"%2\" is invalid!") },
            {AppError_InvalidFileExtension,QT_TRANSLATE_NOOP("ErrorList", "File extension is not supported.\n") },
            {AppError_FileCanNotRead,QT_TRANSLATE_NOOP("ErrorList", "File is not readable:%1\n") },
            {AppError_FileCanNotWrite,QT_TRANSLATE_NOOP("ErrorList", "File is not writable:%1\n") },
            {AppError_EditReadOnlyFile,QT_TRANSLATE_NOOP("ErrorList", "File is read only,edit operation will change it's property,do you want to continue?\n") },
            {AppError_RequireAdministrator,QT_TRANSLATE_NOOP("ErrorList", "No permission to edit file,please run software as administrator\n") },
            {AppError_NoAuthorized,QT_TRANSLATE_NOOP("ErrorList", "The module of %1 is not authorized.\n") },
            {AppError_NeedAdministratorPrivilegeToSaveFile, QT_TRANSLATE_NOOP("ErrorList", "Failed to save file '%1'!\nPlease run the software with administrator privileges!") },
            {AppError_NeedReadWritePermissionToSaveFile, QT_TRANSLATE_NOOP("ErrorList", "Failed to save file '%1'\nPlease check the file path and read-write permission!") },
            {AppErrorEnd, "" }
            })
    {
    }


    AppErrorList::~AppErrorList()
    {

    }

    void AppErrorList::init()
    {
        static AppErrorList mErrorList = AppErrorList();
        for (auto it : mErrorList._errorInfo)
        {
            Base::ErrorMessage.insert(std::make_pair(it.first, it.second));
        }
    }
}
