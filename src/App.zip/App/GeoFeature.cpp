/***************************************************************************
 *   Copyright (c) 2002 Jürgen Riegel <juergen.riegel@web.de>              *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/

 /*===================================================================
 Date           Name        Description of Change
 2018/06/26     LL          add getgeoFeatures
 2018/07/09     LL          move signalStateChange from csys to here for
                             observing obj placement change
 2020/05/22     WJZ         Add GeoLocalPlacement
 2021/08/18     JHQ         update to FreeCAD19
 2023/01/16     LL          Fixed bug GeoLocalPlacement is not restored
 2023/05/08     LJ          Add CopyObjectProperties
 2023/05/08     LJ          Copying some properties in the parent class DocumentObject
 2024/01/25     LL          Add default para useWhole of GetGeoFeatures
 2024/12/26     LL          do not update state while undo/redo

 HISTORY
 ====================================================================*/

#include "PreCompiled.h"

#ifndef _PreComp_
#endif

#include "GeoFeature.h"
#include "GeoFeatureGroupExtension.h"
#include <App/GeoFeaturePy.h>

#include <App/Document.h>
using namespace App;


PROPERTY_SOURCE(App::GeoFeature, App::DocumentObject)


//===========================================================================
// Feature
//===========================================================================

GeoFeature::GeoFeature(void)
{
    ADD_PROPERTY_TYPE(Placement,(Base::Placement()),nullptr,Prop_NoRecompute,nullptr);
    ADD_PROPERTY_TYPE(GeoLocalPlacement, (Base::Placement()), nullptr, Prop_NoRecompute, nullptr);
}

GeoFeature::~GeoFeature(void)
{
}

void GeoFeature::transformPlacement(const Base::Placement &transform)
{
    Base::Placement plm = this->Placement.getValue();
    plm = transform * plm;
    this->Placement.setValue(plm);
}

Base::Placement GeoFeature::globalPlacement() const
{
    auto* group = GeoFeatureGroupExtension::getGroupOfObject(this);
    if (group) {
        auto ext = group->getExtensionByType<GeoFeatureGroupExtension>();
        return ext->globalGroupPlacement() * Placement.getValue();
    }
    return Placement.getValue();    
}

const PropertyComplexGeoData* GeoFeature::getPropertyOfGeometry() const
{
    return nullptr;
}

PyObject* GeoFeature::getPyObject(void)
{
    if (PythonObject.is(Py::_None())) {
        // ref counter is set to 1
        PythonObject = Py::Object(new GeoFeaturePy(this),true);
    }
    return Py::new_reference_to(PythonObject);
}


std::pair<std::string,std::string> GeoFeature::getElementName(
        const char *name, ElementNameType type) const
{
    (void)type;

    std::pair<std::string,std::string> ret;
    if(!name) return ret;

    ret.second = name;
    return ret;
}

DocumentObject *GeoFeature::resolveElement(DocumentObject *obj, const char *subname, 
        std::pair<std::string,std::string> &elementName, bool append, 
        ElementNameType type, const DocumentObject *filter, 
        const char **_element, GeoFeature **geoFeature)
{
    if(!obj || !obj->getNameInDocument())
        return 0;
    if(!subname)
        subname = "";
    const char *element = Data::ComplexGeoData::findElementName(subname);
    if(_element) *_element = element;
    auto sobj = obj->getSubObject(subname);
    if(!sobj)
        return 0;
    obj = sobj->getLinkedObject(true);
    auto geo = dynamic_cast<GeoFeature*>(obj);
    if(geoFeature) 
        *geoFeature = geo;
    if(!obj || (filter && obj!=filter))
        return 0;
    if(!element || !element[0]) {
        if(append) 
            elementName.second = Data::ComplexGeoData::oldElementName(subname);
        return sobj;
    }

    if(!geo || hasHiddenMarker(element)) {
        if(!append) 
            elementName.second = element;
        else
            elementName.second = Data::ComplexGeoData::oldElementName(subname);
        return sobj;
    }
    if(!append) 
        elementName = geo->getElementName(element,type);
    else{
        const auto &names = geo->getElementName(element,type);
        std::string prefix(subname,element-subname);
        if(names.first.size())
            elementName.first = prefix + names.first;
        elementName.second = prefix + names.second;
    }
    return sobj;
}


//FreeCAD019_update
std::vector<GeoFeature*> App::GeoFeature::GetGeoFeatures(bool useWhole)
{
    std::vector<GeoFeature*> fts;
    fts.reserve(1);
    fts.push_back(this);
    return fts;
}

void App::GeoFeature::Restore(Base::XMLReader& reader)
{
    SetSetupStatuChangable(false);
    App::DocumentObject::Restore(reader);
    SetSetupStatuChangable(true);
}

void App::GeoFeature::CopyObjectProperties(DocumentObject* obj)
{
    if (obj->isDerivedFrom(Base::Type::fromName("App::GeoFeature")))
    {
        App::GeoFeature* srcGeoFeature = static_cast<App::GeoFeature*>(obj);
        Placement.Paste(*(srcGeoFeature->Placement.Copy()));
        GeoLocalPlacement.Paste(*(srcGeoFeature->GeoLocalPlacement.Copy()));
        _isSetupStatuChangable = srcGeoFeature->_isSetupStatuChangable;
    }

    DocumentObject::CopyObjectProperties(obj);
}

void App::GeoFeature::OnDeleted()
{ 
    if (GetDealType() == App::DealType_Redo || GetDealType() == App::DealType_Undo ||
        getDocument()->testStatus(App::Document::UndoRedo))
    {
        // do not update state while undo/redo
        return;
    }
    signalStateChange(true, this); 
}
// ****************
