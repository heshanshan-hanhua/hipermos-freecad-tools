﻿/*===================================================================
Copyright (c) 2022 HHIntech
Unpublished - All rights reserved

=====================================================================
File description:
Group object to manager multi transaction for undo/redo.

=====================================================================
Date            Name            Description of Change
2022/07/26      Liulei          Written
2024/05/20      Liulei          Add AddChildTransactions
2024/09/19      HX              reverse _childTransactions before delete
2024/12/27      HX              remove repeat Property and transObj from each other _childTransactions when AddChildTransactions

====================================================================*/

#include "PreCompiled.h"

#ifndef _PreComp_
# include <cassert>
#endif

#include <atomic>

/// Here the FreeCAD includes sorted by Base,App,Gui......
#include <Base/Writer.h>
using Base::Writer;
#include <Base/Reader.h>
using Base::XMLReader;
#include <Base/Console.h>
#include "TransactionGroupHH.h"
#include "Property.h"
#include "Document.h"
#include "DocumentObject.h"

using namespace App;
using namespace std;

TYPESYSTEM_SOURCE(App::TransactionGroup, App::Transaction)

//**************************************************************************
// Construction/Destruction

TransactionGroup::TransactionGroup(int id):Transaction(id)
{
}

/**
 * A destructor.
 * A more elaborate description of the destructor.
 */
TransactionGroup::~TransactionGroup()
{
    _childTransactions.reverse();

    for (auto& childItm : _childTransactions)
    {
        delete childItm;
        childItm = NULL;
    }
    _childTransactions.clear();
}

unsigned int TransactionGroup::getMemSize (void) const
{
    return 0;
}

void TransactionGroup::Save (Base::Writer &/*writer*/) const
{
    assert(0);
}

void TransactionGroup::Restore(Base::XMLReader &/*reader*/)
{
    assert(0);
}

bool TransactionGroup::isEmpty() const
{
    for (auto& childItm : _childTransactions)
    {
        if (!childItm->isEmpty())
        {
            return false;
        }
    }
    return true;
}

bool TransactionGroup::hasObject(const TransactionalObject *Obj) const
{
    for (auto& childItm : _childTransactions)
    {
        if (childItm->hasObject(Obj) )
        {
            return true;
        }
    }
    return false;
}


//**************************************************************************
// separator for other implementation aspects
void TransactionGroup::apply(Document &Doc, bool forward, const ApplyType& applyTp/* = ApplyType_None*/)
{
    std::list<App::Transaction*> childTrans = _childTransactions;
    if (!forward)
    {
        childTrans.reverse();
    }
    for (auto& childItm : childTrans)
    {
        childItm->apply(Doc, forward, applyTp);
    }
}

// ****************

const std::list<App::Transaction*>& TransactionGroup::GetChildTransactions()
{
    return _childTransactions;
}

void TransactionGroup::SetChildTransactions(const std::list<App::Transaction*>& childTrans)
{
    _childTransactions = childTrans;
}


void TransactionGroup::AddChildTransactions(App::Transaction* act)
{
    if (act)
    {
        _childTransactions.insert(_childTransactions.end(), act);
    }
    std::vector<App::Transaction*> hasCheck;
    std::set<const TransactionalObject*> needRemovTransObjs;
    for (auto& childItm : _childTransactions)
    {
        hasCheck.push_back(childItm);
        std::vector<const TransactionalObject*> delStasTransObjs = childItm->GetSpecifyStatusTransObjs(1);//1 meas TransactionObject::Del.  
        std::vector<const Property*> allProps = childItm->GetAllTransObjProperty();
        for (auto& itm : _childTransactions)
        {
            if (std::find(hasCheck.begin(), hasCheck.end(), itm)!= hasCheck.end())
            {
                continue;
            }
            std::vector<const TransactionalObject*> newStasTransObjs = itm->GetSpecifyStatusTransObjs(0);//0 meas TransactionObject::New
            for (auto& obj : newStasTransObjs)
            {
                if (std::find(delStasTransObjs.begin(), delStasTransObjs.end(), obj) != delStasTransObjs.end())
                {
                    needRemovTransObjs.insert(obj);
                }
            }

            for (auto& it : allProps)
            {
                itm->RemoveSpecifyTransObjProperty(it);
            }
        }
        
    }
    bool isDestructObj = false;
    for (auto& obj : needRemovTransObjs)
    {
        for (auto& itm : _childTransactions)
        {
            itm->RemoveSpecifyTransObj(obj, isDestructObj);//the second parameter isDestructObj set as false to avoid multiple destructions
        }
        delete obj;//and the obj is destructed here
    }

}

App::Transaction* TransactionGroup::GetLastTransactions()
{
    if (!_childTransactions.empty())
    {
        return _childTransactions.back();
    }
    return NULL;
}
