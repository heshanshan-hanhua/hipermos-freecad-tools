/*===================================================================
Copyright (c) 2018
Unpublished - All rights reserved

=====================================================================
File description:
the errors of App

=====================================================================
Date            Name            Description of Change
2018/07/23      MZG             Written
2019/03/23      LL              Add InvalidShapeForExport
2022/01/13      WS              add AppError_NotSupportedFormat
2022/01/23      LL              add AppError_ProjectFileIsNewer & AppError_CannotCreateObject
2022/03/23      LL              add AppError_NoActiveDoc
2022/07/14      LL              Add FailedToOpenFile and FileSaved
2023/02/05      LL              add ExportShapeIsNull
2023/02/09      HX              add AppError_ExceptionCaughtWithMessage,AppError_UnknownExceptionCaught
2023/07/16      LL              add AppError_NoShapeOfTypeCanExport
2023/09/25      LL              Add InvalidFilePath InvalidFileExtension
2024/05/27      WS              add AppError_InvalidFilePathWithName
2024/11/26      LL              add some file error
2024/11/27      LL              add error of RequireAdministrator
2025/01/10      LL              add error of NoAuthorized
2025/02/11      LL              add error of NeedWritePermissionToSaveFile
HISTORY
====================================================================*/
#ifndef APP_ERROR_LIST_H
#define APP_ERROR_LIST_H

#include <BaseHH/BaseErrorList.h>

namespace App
{
    enum AppError
    {
        AppError_Default = ERROR_MAIN_START,
        
        AppError_InvalidDocument,
        AppError_CannotOpenNewerVersion,

        AppError_InvalidShapeForExport,
        AppError_NotSupportedFormat,
        AppError_ProjectFileIsNewer,
        AppError_CannotCreateObject,
        AppError_PropertyTypeChanged,
        AppError_UnsupportedType,
        AppError_CannotCreateObjAs,

        AppError_NoActiveDoc,
        AppError_FailedToOpenFile,
        AppError_FileSaved,

        AppError_ExportShapeIsNull,
        AppError_NoShapeOfTypeCanExport,

        AppError_ExceptionCaughtWithMessage,
        AppError_UnknownExceptionCaught,
        AppError_InvalidFilePath,
        AppError_InvalidFilePathWithName,
        AppError_InvalidFileExtension,
        AppError_FileCanNotRead,
        AppError_FileCanNotWrite,
        AppError_EditReadOnlyFile,
        AppError_RequireAdministrator,
        AppError_NoAuthorized,

        AppError_NeedAdministratorPrivilegeToSaveFile,
        AppError_NeedReadWritePermissionToSaveFile,

        AppErrorEnd = ERROR_MAIN_END
    };

    class AppErrorList
    {
    public:
        AppErrorList();
        ~AppErrorList();

        static void init();
    private:
        std::map<AppError, const char*> _errorInfo;
    };
}
#endif // APP_ERROR_LIST_H
