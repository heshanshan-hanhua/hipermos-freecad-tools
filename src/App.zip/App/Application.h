/***************************************************************************
 *   Copyright (c) 2002 Jürgen Riegel <juergen.riegel@web.de>              *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License (LGPL)   *
 *   as published by the Free Software Foundation; either version 2 of     *
 *   the License, or (at your option) any later version.                   *
 *   for detail see the LICENCE text file.                                 *
 *                                                                         *
 *   FreeCAD is distributed in the hope that it will be useful,            *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with FreeCAD; if not, write to the Free Software        *
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  *
 *   USA                                                                   *
 *                                                                         *
 ***************************************************************************/

 /*===================================================================
 Copyright (c) 2018
 Unpublished - All rights reserved

 =====================================================================
 File description:

 =====================================================================
 Date            Name            Description of Change
 2018/05/01      Liulei          Add signalCloseMDIView
 2018/06/15      WangSong        Add signalShowErrorMessage
 2018/06/21      WangSong        change signalShowErrorMessage to signalShowMessage
 2018/07/24      MZG             Add version control
 2018/08/30      MZG             Support log
 2018/11/15      MZG             Add sGetTargetName
 2021/06/30      JHQ             update to FreeCAD19
 2021/12/19      LL              move signalShowMessage to MessageTool
 2022/01/13      LL              Add GetHiperMOSBinDir
 2022/06/24      LL              Add SignalCreateBasicObj
 2023/06/02      LL              Add typeOfObjMustExist
 2023/09/20      LL              add runAutoProcessScript
 2024/05/20      LL              Add IsOpenningTransaction
 2024/06/12      LL              Add file path to newDocument()
 2024/10/25      LL              Add signalBeforeOpenDocument
 2025/03/18      LL              Add signalStarted

 HISTORY
 ====================================================================*/
#ifndef APP_APPLICATION_H
#define APP_APPLICATION_H

#include <boost_signals2.hpp>

#include <vector>
#include <deque>

#include <Base/PyObjectBase.h>
#include <Base/Parameter.h>
#include <Base/Observer.h>


namespace Base
{
    class ConsoleObserverStd;
    class ConsoleObserverFile;
}

namespace App
{

class Document;
class DocumentObject;
class ApplicationObserver;
class Property;
class AutoTransaction;
class ExtensionContainer;

enum GetLinkOption {
    /// Get all links (both directly and in directly) linked to the given object
    GetLinkRecursive = 1,
    /// Get link array element instead of the array
    GetLinkArrayElement = 2,
    /// Get linked object instead of the link, no effect if GetLinkRecursive
    GetLinkedObject = 4,
    /// Get only external links, no effect if GetLinkRecursive
    GetLinkExternal = 8,
};


/** The Application
 *  The root of the whole application
 *  @see App::Document
 */
class AppExport Application
{

public:

    //---------------------------------------------------------------------
    // exported functions go here +++++++++++++++++++++++++++++++++++++++++
    //---------------------------------------------------------------------

    /** @name methods for document handling */
    //@{
    /** Creates a new document
     * The first name is a the identifier and some kind of an internal (english)
     * name. It has to be like an identifier in a programming language, with no
     * spaces and not starting with a number. This name gets also forced to be unique
     * in this Application. You can avoid the renaming by using getUniqueDocumentName()
     * to get a unique name before calling newDoucument().
     * The second name is a UTF8 name of any kind. It's that name normally shown to
     * the user and stored in the App::Document::Name property.
     */
    App::Document* newDocument(const char * Name=0l, const char * UserName=0l,
            bool createView=true, bool tempDoc=false,const char* path="");
    /// Closes the document \a name and removes it from the application.
    bool closeDocument(const char* name);
    /// find a unique document name
    std::string getUniqueDocumentName(const char *Name, bool tempDoc=false) const;
    /// Open an existing document from a file
    App::Document* openDocument(const char * FileName=0l, bool createView=true);
    /** Open multiple documents
     *
     * @param filenames: input file names
     * @param paths: optional input file path in case it is different from
     * filenames (mainly used during recovery).
     * @param labels: optional label assign to document (mainly used during recovery).
     * @param errs: optional output error message corresponding to each input
     * file name. If errs is given, this function will catch all
     * Base::Exception and save the error message inside. Otherwise, it will
     * throw on exception when opening the input files.
     * @param createView: whether to signal Gui module to create view on restore.
     *
     * @return Return opened document object corresponding to each input file
     * name, which maybe NULL if failed.
     *
     * This function will also open any external referenced files.
     */
    std::vector<Document*> openDocuments(const std::vector<std::string> &filenames,
            const std::vector<std::string> *paths=0,
            const std::vector<std::string> *labels=0,
            std::vector<std::string> *errs=0,
            bool createView = true);
    /// Retrieve the active document
    App::Document* getActiveDocument(void) const;
    /// Retrieve a named document
    App::Document* getDocument(const char *Name) const;
    /// gets the (internal) name of the document
    const char * getDocumentName(const App::Document* ) const;
    /// get a list of all documents in the application
    std::vector<App::Document*> getDocuments() const;
    /// Set the active document
    void setActiveDocument(App::Document* pDoc);
    void setActiveDocument(const char *Name);
    /// close all documents (without saving)
    void closeAllDocuments(void);
    /// Add pending document to open together with the current opening document
    int addPendingDocument(const char *FileName, const char *objName, bool allowPartial);
    /// Indicate whether the application is opening (restoring) some document
    bool isRestoring() const;
    /// Indicate the application is closing all document
    bool isClosingAll() const;
    //@}

    /** @name Application-wide trandaction setting */
    //@{
    /** Setup a pending application-wide active transaction
     *
     * @param name: new transaction name
     * @param persist: by default, if the calling code is inside any invocation
     * of a command, it will be auto closed once all command within the current
     * stack exists. To disable auto closing, set persist=true
     *
     * @return The new transaction ID.
     *
     * Call this function to setup an application-wide transaction. All current
     * pending transactions of opening documents will be committed first.
     * However, no new transaction is created by this call. Any subsequent
     * changes in any current opening document will auto create a transaction
     * with the given name and ID. If more than one document is changed, the
     * transactions will share the same ID, and will be undo/redo together.
     */
    int setActiveTransaction(const char *name, bool persist=false);
    /// Return the current active transaction name and ID
    const char *getActiveTransaction(int *tid=0) const;
    /** Commit/abort current active transactions
     *
     * @param abort: whether to abort or commit the transactions
     *
     * Bsides calling this function directly, it will be called by automatically
     * if 1) any new transaction is created with a different ID, or 2) any
     * transaction with the current active transaction ID is either committed or
     * aborted
     */
    void closeActiveTransaction(bool abort=false, int id=0);
    //@}

#pragma region FreeCAD19_Update
    int GetDocumentVersion(const char* fileName = 0l);
    int GetRobManVersion();

    std::string GetProgramInfo();
    std::string GetAuthorInfo();
    std::string GetDocVersionInfo();
    std::string GetTimeInfo();
    std::string GetLicenseInfo();
    std::string GetMachineInfo();

    void AddTypeOfObjMustExist(const Base::Type& tp)
    {
        _typeOfObjMustExist.insert(tp);
    }
    const std::set<Base::Type>& GetTypeOfObjMustExist()
    {
        return _typeOfObjMustExist;
    }

    static void RunAutoProcessScript();

    bool IsOpenningTransaction() { return _isOpenningTransaction; }
    void UpdateActiveTransaction(int id);
    boost::signals2::signal<void(const Document&)> signalPreSaveDocument;
    boost::signals2::signal<void(const Document&, int, int)> signalUpgradeDocument;
    /// signal on close MDIView
    boost::signals2::signal<void()> signalCloseMDIView;
    boost::signals2::signal<void(const Document&)> signalCreateBasicObj;

    /// signal on application start open document
    boost::signals2::signal<bool()> signalBeforeOpenDocument;
    boost::signals2::signal<bool()> signalCheckDocumentValid;

#pragma endregion

    /** @name Signals of the Application */
    //@{
    /// signal on new Document
    boost::signals2::signal<void (const Document&, bool)> signalNewDocument;
    /// signal on document getting deleted
    boost::signals2::signal<void (const Document&)> signalDeleteDocument;
    /// signal on already deleted Document
    boost::signals2::signal<void ()> signalDeletedDocument;
    /// signal on relabeling Document (user name)
    boost::signals2::signal<void (const Document&)> signalRelabelDocument;
    /// signal on renaming Document (internal name)
    boost::signals2::signal<void (const Document&)> signalRenameDocument;
    /// signal on activating Document
    boost::signals2::signal<void (const Document&)> signalActiveDocument;
    /// signal on saving Document
    boost::signals2::signal<void (const Document&)> signalSaveDocument;
    /// signal on starting to restore Document
    boost::signals2::signal<void (const Document&)> signalStartRestoreDocument;
    /// signal on restoring Document
    boost::signals2::signal<void (const Document&)> signalFinishRestoreDocument;
    /// signal on starting to save Document
    boost::signals2::signal<void (const Document&, const std::string&)> signalStartSaveDocument;
    /// signal on saved Document
    boost::signals2::signal<void (const Document&, const std::string&)> signalFinishSaveDocument;
    /// signal on undo in document
    boost::signals2::signal<void (const Document&)> signalUndoDocument;
    /// signal on application wide undo
    boost::signals2::signal<void ()> signalUndo;
    /// signal on redo in document
    boost::signals2::signal<void (const Document&)> signalRedoDocument;
    /// signal on application wide redo
    boost::signals2::signal<void ()> signalRedo;
    /// signal before close/abort active transaction
    boost::signals2::signal<void (bool)> signalBeforeCloseTransaction;
    /// signal after close/abort active transaction
    boost::signals2::signal<void (bool)> signalCloseTransaction;
    /// signal on show hidden items
    boost::signals2::signal<void (const Document&)> signalShowHidden;
    /// signal on start opening document(s)
    boost::signals2::signal<void ()> signalStartOpenDocument;
    /// signal on finished opening document(s)
    boost::signals2::signal<void ()> signalFinishOpenDocument;
    //@}


    /** @name Signals of the document
     * This signals are an aggregation of all document. If you only
     * the signal of a special document connect to the document itself
     */
    //@{
    /// signal before change of doc property
    boost::signals2::signal<void (const App::Document&, const App::Property&)> signalBeforeChangeDocument;
    /// signal on changed doc property
    boost::signals2::signal<void (const App::Document&, const App::Property&)> signalChangedDocument;
    /// signal on new Object
    boost::signals2::signal<void (const App::DocumentObject&)> signalNewObject;
    //boost::signals2::signal<void (const App::DocumentObject&)>     m_sig;
    /// signal on deleted Object
    boost::signals2::signal<void (const App::DocumentObject&)> signalDeletedObject;
    /// signal on changed Object
    boost::signals2::signal<void (const App::DocumentObject&, const App::Property&)> signalBeforeChangeObject;
    /// signal on changed Object
    boost::signals2::signal<void (const App::DocumentObject&, const App::Property&)> signalChangedObject;
    /// signal on relabeled Object
    boost::signals2::signal<void (const App::DocumentObject&)> signalRelabelObject;
    /// signal on activated Object
    boost::signals2::signal<void (const App::DocumentObject&)> signalActivatedObject;
    /// signal before recomputed document
    boost::signals2::signal<void (const App::Document&)> signalBeforeRecomputeDocument;
    /// signal on recomputed document
    boost::signals2::signal<void (const App::Document&)> signalRecomputed;
    /// signal on recomputed document object
    boost::signals2::signal<void (const App::DocumentObject&)> signalObjectRecomputed;
    // signal on opened transaction
    boost::signals2::signal<void (const App::Document&, std::string)> signalOpenTransaction;
    // signal a committed transaction
    boost::signals2::signal<void (const App::Document&)> signalCommitTransaction;
    // signal an aborted transaction
    boost::signals2::signal<void (const App::Document&)> signalAbortTransaction;
    //@}

    /** @name Signals of property changes
     * These signals are emitted on property additions or removal.
     * The changed object can be any sub-class of PropertyContainer.
     */
    //@{
    /// signal on adding a dynamic property
    boost::signals2::signal<void (const App::Property&)> signalAppendDynamicProperty;
    /// signal on about removing a dynamic property
    boost::signals2::signal<void (const App::Property&)> signalRemoveDynamicProperty;
    /// signal on about changing the editor mode of a property
    boost::signals2::signal<void (const App::Document&, const App::Property&)> signalChangePropertyEditor;
    //@}

    /** @name Signals of extension changes
     * These signals are emitted on dynamic extension addition. Dynamic extensions are the ones added by python (c++ ones are part
     * of the class definition, hence not dynamic)
     * The extension in question is provided as parameter.
     */
    //@{
    /// signal before adding the extension
    boost::signals2::signal<void (const App::ExtensionContainer&, std::string extension)> signalBeforeAddingDynamicExtension;
    /// signal after the extension was added
    boost::signals2::signal<void (const App::ExtensionContainer&, std::string extension)> signalAddedDynamicExtension;
     //@}

    boost::signals2::signal<void()> signalStarted;
    /** @name methods for parameter handling */
    //@{
    /// returns the system parameter
    ParameterManager &                                GetSystemParameter(void) ;
    /// returns the user parameter
    ParameterManager &                                GetUserParameter(void) ;
    /** Gets a parameter group by a full qualified path
     * It's an easy method to get a group:
     * \code
     * // getting standard parameter
     * ParameterGrp::handle hGrp = App::GetApplication().GetParameterGroupByPath("User parameter:BaseApp/Preferences/Mod/Raytracing");
     * std::string cDir             = hGrp->GetASCII("ProjectPath", "");
     * std::string cCameraName      = hGrp->GetASCII("CameraName", "TempCamera.inc");
     * \endcode
     */
    Base::Reference<ParameterGrp>                     GetParameterGroupByPath(const char* sName);

    ParameterManager *                                GetParameterSet(const char* sName) const;
    const std::map<std::string,ParameterManager *> &  GetParameterSetList(void) const;
    void AddParameterSet(const char* sName);
    void RemoveParameterSet(const char* sName);
    //@}

    /** @name methods for the open handler
     *  With this facility a Application module can register
     *  a ending (filetype) which he can handle to open.
     *  The ending and the module name are stored and if the file
     *  type is opened the module get loaded and need to register a
     *  OpenHandler class in the OpenHandlerFactorySingleton.
     *  After the module is loaded a OpenHandler of this type is created
     *  and the file get loaded.
     *  @see OpenHandler
     *  @see OpenHandlerFactorySingleton
     */
    //@{
    /// Register an import filetype and a module name
    void addImportType(const char* Type, const char* ModuleName);
    /// Change the module name of a registered filetype
    void changeImportModule(const char* Type, const char* OldModuleName, const char* NewModuleName);
    /// Return a list of modules that support the given filetype.
    std::vector<std::string> getImportModules(const char* Type) const;
    /// Return a list of all modules.
    std::vector<std::string> getImportModules() const;
    /// Return a list of filetypes that are supported by a module.
    std::vector<std::string> getImportTypes(const char* Module) const;
    /// Return a list of all filetypes.
    std::vector<std::string> getImportTypes(void) const;
    /// Return the import filters with modules of a given filetype.
    std::map<std::string, std::string> getImportFilters(const char* Type) const;
    /// Return a list of all import filters.
    std::map<std::string, std::string> getImportFilters(void) const;
    //@}
    //@{
    /// Register an export filetype and a module name
    void addExportType(const char* Type, const char* ModuleName);
    /// Change the module name of a registered filetype
    void changeExportModule(const char* Type, const char* OldModuleName, const char* NewModuleName);
    /// Return a list of modules that support the given filetype.
    std::vector<std::string> getExportModules(const char* Type) const;
    /// Return a list of all modules.
    std::vector<std::string> getExportModules() const;
    /// Return a list of filetypes that are supported by a module.
    std::vector<std::string> getExportTypes(const char* Module) const;
    /// Return a list of all filetypes.
    std::vector<std::string> getExportTypes(void) const;
    /// Return the export filters with modules of a given filetype.
    std::map<std::string, std::string> getExportFilters(const char* Type) const;
    /// Return a list of all export filters.
    std::map<std::string, std::string> getExportFilters(void) const;
    //@}

    /** @name Init, Destruct an Access methods */
    //@{
    static void init(int argc, char ** argv);
    static void initTypes(void);
    static void destruct(void);
    static void destructObserver(void);
    static void processCmdLineFiles(void);
    static std::list<std::string> getCmdLineFiles();
    static std::list<std::string> processFiles(const std::list<std::string>&);
    static void runApplication(void);
    friend Application &GetApplication(void);
    static std::map<std::string,std::string> &Config(void){return mConfig;}
    static int GetARGC(void){return _argc;}
    static char** GetARGV(void){return _argv;}
    //@}

    /** @name Application directories */
    //@{
    const char* getHomePath(void) const;
    const char* getExecutableName(void) const;
    /*!
     Returns the temporary directory. By default, this is set to the
     system's temporary directory but can be customized by the user.
     */
    static std::string getTempPath();
    static std::string getTempFileName(const char* FileName=0);
    static std::string getUserAppDataDir();
    static std::string getUserMacroDir();
    static std::string getResourceDir();
    static std::string getHelpDir();
    //@}
    //FreeCAD019_Update
    static std::string GetHiperMOSBinDir();

    static std::string GetHiperMOSThirdLibDir();
    //end
    /** @name Link handling */
    //@{

    /** Check for link recursion depth
     *
     * @param depth: current depth
     * @param no_throw: whether to throw exception
     *
     * @return Return the maximum remaining depth.
     *
     * The function uses an internal count of all objects in all documents as
     * the limit of recursion depth.
     */
    int checkLinkDepth(int depth, bool no_throw=true);

    /** Return the links to a given object
     *
     * @param obj: the linked object. If NULL, then all links are returned.
     * @param option: @sa App::GetLinkOption
     * @param maxCount: limit the number of links returned, 0 means no limit
     */
    std::set<DocumentObject*> getLinksTo(
            const DocumentObject *, int options, int maxCount=0) const;

    /// Check if there is any link to the given object
    bool hasLinksTo(const DocumentObject *obj) const;
    //@}

    friend class App::Document;

protected:
    /// get called by the document when the name is changing
    void renameDocument(const char *OldName, const char *NewName);

    /** @name I/O of the document
     * This slot get connected to all App::Documents created
     */
    //@{
    void slotBeforeChangeDocument(const App::Document&, const App::Property&);
    void slotChangedDocument(const App::Document&, const App::Property&);
    void slotNewObject(const App::DocumentObject&);
    void slotDeletedObject(const App::DocumentObject&);
    void slotBeforeChangeObject(const App::DocumentObject&, const App::Property& Prop);
    void slotChangedObject(const App::DocumentObject&, const App::Property& Prop);
    void slotRelabelObject(const App::DocumentObject&);
    void slotActivatedObject(const App::DocumentObject&);
    void slotUndoDocument(const App::Document&);
    void slotRedoDocument(const App::Document&);
    void slotRecomputedObject(const App::DocumentObject&);
    void slotRecomputed(const App::Document&);
    void slotBeforeRecompute(const App::Document&);
    void slotOpenTransaction(const App::Document&, std::string);
    void slotCommitTransaction(const App::Document&);
    void slotAbortTransaction(const App::Document&);
    void slotStartSaveDocument(const App::Document&, const std::string&);
    void slotFinishSaveDocument(const App::Document&, const std::string&);
    void slotChangePropertyEditor(const App::Document&, const App::Property &);
    //@}

    /// open single document only
    App::Document* openDocumentPrivate(const char * FileName, const char *propFileName,
            const char *label, bool isMainDoc, bool createView, const std::set<std::string> &objNames);

    /// Helper class for App::Document to signal on close/abort transaction
    class AppExport TransactionSignaller {
    public:
        TransactionSignaller(bool abort,bool signal);
        ~TransactionSignaller();
    private:
        bool abort;
    };

private:
    /// Constructor
    Application(std::map<std::string,std::string> &mConfig);
    /// Destructor
    virtual ~Application();

    /** @name member for parameter */
    //@{
    static ParameterManager *_pcSysParamMngr;
    static ParameterManager *_pcUserParamMngr;
    //@}

    //---------------------------------------------------------------------
    // python exports goes here +++++++++++++++++++++++++++++++++++++++++++
    //---------------------------------------------------------------------

    // static python wrapper of the exported functions
    static PyObject* sGetParam          (PyObject *self,PyObject *args);
    static PyObject* sSaveParameter     (PyObject *self,PyObject *args);
    static PyObject* sGetVersion        (PyObject *self,PyObject *args);
    static PyObject* sGetConfig         (PyObject *self,PyObject *args);
    static PyObject* sSetConfig         (PyObject *self,PyObject *args);
    static PyObject* sDumpConfig        (PyObject *self,PyObject *args);
    static PyObject* sAddImportType     (PyObject *self,PyObject *args);
    static PyObject* sChangeImportModule(PyObject *self,PyObject *args);
    static PyObject* sGetImportType     (PyObject *self,PyObject *args);
    static PyObject* sAddExportType     (PyObject *self,PyObject *args);
    static PyObject* sChangeExportModule(PyObject *self,PyObject *args);
    static PyObject* sGetExportType     (PyObject *self,PyObject *args);
    static PyObject* sGetResourceDir    (PyObject *self,PyObject *args);
    static PyObject* sGetUserAppDataDir (PyObject *self,PyObject *args);
    static PyObject* sGetUserMacroDir   (PyObject *self,PyObject *args);
    static PyObject* sGetHelpDir        (PyObject *self,PyObject *args);
    static PyObject* sGetHomePath       (PyObject *self,PyObject *args);

    static PyObject* sLoadFile          (PyObject *self,PyObject *args);
    static PyObject* sOpenDocument      (PyObject *self,PyObject *args, PyObject *kwd);
    static PyObject* sSaveDocument      (PyObject *self,PyObject *args);
    static PyObject* sSaveDocumentAs    (PyObject *self,PyObject *args);
    static PyObject* sNewDocument       (PyObject *self,PyObject *args, PyObject *kwd);
    static PyObject* sCloseDocument     (PyObject *self,PyObject *args);
    static PyObject* sActiveDocument    (PyObject *self,PyObject *args);
    static PyObject* sSetActiveDocument (PyObject *self,PyObject *args);
    static PyObject* sGetDocument       (PyObject *self,PyObject *args);
    static PyObject* sListDocuments     (PyObject *self,PyObject *args);
    static PyObject* sAddDocObserver    (PyObject *self,PyObject *args);
    static PyObject* sRemoveDocObserver (PyObject *self,PyObject *args);
    static PyObject *sIsRestoring       (PyObject *self,PyObject *args);

    static PyObject *sSetLogLevel       (PyObject *self,PyObject *args);
    static PyObject *sGetLogLevel       (PyObject *self,PyObject *args);

    static PyObject *sCheckLinkDepth    (PyObject *self,PyObject *args);
    static PyObject *sGetLinksTo        (PyObject *self,PyObject *args);

    static PyObject *sGetDependentObjects(PyObject *self,PyObject *args);

    static PyObject *sSetActiveTransaction  (PyObject *self,PyObject *args);
    static PyObject *sGetActiveTransaction  (PyObject *self,PyObject *args);
    static PyObject *sCloseActiveTransaction(PyObject *self,PyObject *args);
    static PyObject *sCheckAbort(PyObject *self,PyObject *args);

#pragma region FreeCAD19_Update
    static PyObject* sLog(PyObject* self, PyObject* args, PyObject* kwd);

    std::set<Base::Type> _typeOfObjMustExist;
#pragma endregion


    static PyMethodDef    Methods[];

    friend class ApplicationObserver;

    /** @name  Private Init, Destruct an Access methods */
    //@{
    static void initConfig(int argc, char ** argv);
    static void initApplication(void);
    static void logStatus(void);
    // the one and only pointer to the application object
    static Application *_pcSingleton;
    /// argument helper function
    static void ParseOptions(int argc, char ** argv);
    /// checks if the environment is alright
    //static void CheckEnv(void);
    /// Search for the FreeCAD home path based on argv[0]
    /*!
     * There are multiple implementations of this method per-OS
     */
    static std::string FindHomePath(const char* sCall);
    /// Print the help message
    static void PrintInitHelp(void);
    /// figure out some things
    static void ExtractUserPath();
    /// load the user and system parameter set
    static void LoadParameters(void);
    /// puts the given env variable in the config
    static void SaveEnv(const char *);
    /// startup configuration container
    static std::map<std::string,std::string> mConfig;
    static int _argc;
    static char ** _argv;
    //@}

    struct FileTypeItem {
        std::string filter;
        std::string module;
        std::vector<std::string> types;
    };

    /// open ending information
    std::vector<FileTypeItem> _mImportTypes;
    std::vector<FileTypeItem> _mExportTypes;
    std::map<std::string,Document*> DocMap;
    std::map<std::string,ParameterManager *> mpcPramManager;
    std::map<std::string,std::string> &_mConfig;
    App::Document* _pActiveDoc;

    std::deque<const char *> _pendingDocs;
    std::deque<const char *> _pendingDocsReopen;
    std::map<std::string,std::set<std::string> > _pendingDocMap;
    bool _isRestoring;
    bool _allowPartial;
    bool _isClosingAll;

    // for estimate max link depth
    int _objCount;

    friend class AutoTransaction;

    std::string _activeTransactionName;
    int _activeTransactionID;
    int _activeTransactionGuard;
    bool _activeTransactionTmpName;
    bool _isOpenningTransaction;

    static Base::ConsoleObserverStd  *_pConsoleObserverStd;
    static Base::ConsoleObserverFile *_pConsoleObserverFile;
};

/// Singleton getter of the Application
inline App::Application &GetApplication(void){
    return *App::Application::_pcSingleton;
}

} // namespace App


#endif // APP_APPLICATION_H
