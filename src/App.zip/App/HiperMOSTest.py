#***************************************************************************
#*   Copyright (c) 2002 Jürgen Riegel <juergen.riegel@web.de>              *
#*                                                                         *
#*   This file is part of the HiperMOS CAx development system.             *
#*                                                                         *
#*   This program is free software; you can redistribute it and/or modify  *
#*   it under the terms of the GNU Lesser General Public License (LGPL)    *
#*   as published by the Free Software Foundation; either version 2 of     *
#*   the License, or (at your option) any later version.                   *
#*   for detail see the LICENCE text file.                                 *
#*                                                                         *
#*   HiperMOS is distributed in the hope that it will be useful,           *
#*   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
#*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
#*   GNU Lesser General Public License for more details.                   *
#*                                                                         *
#*   You should have received a copy of the GNU Library General Public     *
#*   License along with HiperMOS; if not, write to the Free Software       *
#*   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  *
#*   USA                                                                   *
#*                                                                         *
#***************************************************************************/

# 2021/09/01    ZJF     Set HiperMOS style

# HiperMOS test module
#
# Testing the function of the base system and run
# (if existing) the test function of the modules



Log ("HiperMOS test running...\n\n")

import sys

import HiperMOS
import TestApp

testCase = HiperMOS.ConfigGet("TestCase")

testResult = TestApp.TestText(testCase)

Log ("HiperMOS test done\n")

sys.exit(0 if testResult.wasSuccessful() else 1)
