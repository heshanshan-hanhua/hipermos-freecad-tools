/*===================================================================
Copyright (c) 2019
Unpublished - All rights reserved

=====================================================================
File description:
the class for version information management

=====================================================================
Date            Name            Description of Change
2018/07/25      MZG        Written
2021/08/18      JHQ        upgrade to 0.19

HISTORY
====================================================================*/


#ifndef VERSION_OBJECTHH_H
#define VERSION_OBJECTHH_H

#include "DocumentObject.h"
#include "PropertyStandard.h"

namespace App
{

    struct VersionRecord
    {
        std::string ver;
        std::string time;
        std::string mach;
        std::string auth;
        std::string prog;
        std::string lic;
    };

    class AppExport VersionObjectHH : public DocumentObject
    {
        PROPERTY_HEADER(App::VersionObjectHH);

    public:
        /// Constructor
        VersionObjectHH(void);
        virtual ~VersionObjectHH();

        App::PropertyStringList Versions;
        App::PropertyStringList Times;
        App::PropertyStringList Machines;
        App::PropertyStringList Authors;
        App::PropertyStringList Programs;
        App::PropertyStringList Licenses;

        void AppendSaveRecord(std::string ver, std::string time,
            std::string mach, std::string author, std::string prog, std::string lic);
        void SetOpenRecord(std::string ver, std::string time,
            std::string mach, std::string author, std::string prog, std::string lic);

        VersionRecord GetOpenRecord();
        std::vector<VersionRecord> GetSaveRecord();

        bool IsValid();
    private:
        VersionRecord _openRecord;
    };
} //namespace App


#endif // VERSION_OBJECTHH_H
