﻿/*========================================================================
Copyright (c) 2018 MIRC, Wit
Unpublished - All rights reserved

==========================================================================
File description:

==========================================================================
Date              Name                 Description of Change
21-July-2017      MZG                  Written
2019/01/10        LL                   Add LOG_ERRORTIP without output stack information
2021/06/30        ZJF                  change Logger to LoggerHH
2024/08/23        LJ                   Add time information to the log information
==========================================================================*/
#ifndef BASE_LOGGERHH_H
#define BASE_LOGGERHH_H

#define BOOST_LOG_DYN_LINK 1

#include <string>
#include <boost/log/sources/severity_logger.hpp>
#include <boost/log/sources/severity_feature.hpp>
#include <boost/log/sources/record_ostream.hpp>
#include "StackWalker.h"

namespace Base
{
    enum SeverityLevel
    {
        SeverityLevel_Debug = 0,
        SeverityLevel_Info,
        SeverityLevel_Warning,
        SeverityLevel_Error,
        SeverityLevel_Fatal
    };

    template< typename CharT, typename TraitsT >
    inline std::basic_ostream< CharT, TraitsT >& operator<< (std::basic_ostream< CharT, TraitsT >& strm, SeverityLevel lvl)
    {
        static const char* const str[] =
        {
            "DEBUG",
            "INFO",
            "WARNING",
            "ERROR",
            "FATAL"
        };
        if (static_cast< std::size_t >(lvl) < (sizeof(str) / sizeof(*str)))
            strm << str[lvl];
        else
            strm << static_cast< int >(lvl);
        return strm;
    }

    typedef boost::log::sources::severity_logger_mt<Base::SeverityLevel> LogType;

    class BaseExport LoggerHH
    {
    public:
        /// Construction
        static LoggerHH* GetLogger();
        /// Destruction
        virtual ~LoggerHH();

        std::string GetLogFile() const;

        LogType& GetBoostLogger();

        void SetOutputTime(bool isOutput);
        bool IsOutputTime();
    private:
        LoggerHH();
        void Init();

        LogType _boostLogger;
        std::string _logFile;
        int _outputTime;
    };

    class BaseExport MyStackWalker : public StackWalker
    {
    public:
        MyStackWalker();
        static std::string GetStackMsg();

    protected:
        virtual void OnOutput(LPCSTR szText);
        virtual void OnSymInit(LPCSTR szSearchPath, DWORD symOptions, LPCSTR szUserName);
        virtual void OnLoadModule(LPCSTR img, LPCSTR mod, DWORD64 baseAddr, DWORD size, DWORD result, LPCSTR symType, LPCSTR pdbName, ULONGLONG fileVersion);
        virtual void OnCallstackEntry(CallstackEntryType eType, CallstackEntry &entry);
        virtual void OnDbgHelpErr(LPCSTR szFuncName, DWORD gle, DWORD64 addr);

    private:
        std::string _stackMsg;
        int _index;
    };

} //namespace Base

#define LOG(severity) BOOST_LOG_SEV(Base::LoggerHH::GetLogger()->GetBoostLogger(),severity)

#define LOG_DEBUG   LOG(Base::SeverityLevel_Debug)
#define LOG_INFO    LOG(Base::SeverityLevel_Info)
#define LOG_WARNING LOG(Base::SeverityLevel_Warning)
#define LOG_ERRORTIP LOG(Base::SeverityLevel_Error) << "(File: " << __FILE__ << ",  Line: " << __LINE__ << ", Func: " << __FUNCTION__ << ")" \
                                                   << std::endl
#define LOG_ERROR   LOG(Base::SeverityLevel_Error) << "(File: " << __FILE__ << ",  Line: " << __LINE__ << ", Func: " << __FUNCTION__ << ")" \
                                                   << std::endl << Base::MyStackWalker::GetStackMsg()
#define LOG_FATAL   LOG(Base::SeverityLevel_Fatal) << "(File: " << __FILE__ << ",  Line: " << __LINE__ << ", Func: " << __FUNCTION__ << ")" \
                                                   << std::endl << Base::MyStackWalker::GetStackMsg()


#endif // BASE_LOGGERHH_H

