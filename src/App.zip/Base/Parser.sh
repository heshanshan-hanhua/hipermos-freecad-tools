flex -oQuantityLexer.c < QuantityParser.l
bison -oQuantityParser.c QuantityParser.y
