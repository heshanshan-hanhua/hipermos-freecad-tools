﻿/*========================================================================
Copyright (c) 2018 MIRC, Wit
Unpublished - All rights reserved

==========================================================================
File description:

==========================================================================
Date              Name                 Description of Change
21-July-2017      MZG                  Written
28-Dec.-2018      WJZ                  change log file name to HH_YYYYMMDDTHHMMSS.rmlog
2021/06/30        ZJF                  change Logger to LoggerHH
2021/08/25        JHQ                  fix path error: tempHH_YYYYMMDDTHHMMSS
==========================================================================*/
#include "PreCompiled.h"
#include "LoggerHH.h"
#include <boost/filesystem.hpp>
#include "FileInfo.h"
#include <fstream>
#include <iomanip>

#include <boost/log/core.hpp>
#include <boost/log/trivial.hpp>
#include <boost/log/expressions.hpp>
#include <boost/log/sinks/text_file_backend.hpp>
#include <boost/log/sinks/text_ostream_backend.hpp>
#include <boost/log/sinks/async_frontend.hpp>
#include <boost/log/sinks/syslog_backend.hpp>
#include <boost/log/sinks/syslog_constants.hpp>
#include <boost/log/utility/setup/file.hpp>
#include <boost/log/utility/setup/common_attributes.hpp>
#include <boost/log/sources/severity_logger.hpp>
#include <boost/log/sources/record_ostream.hpp>
#include <boost/log/sources/severity_logger.hpp>
#include <boost/log/sources/severity_feature.hpp>
#include <boost/locale.hpp>
#include <boost/phoenix/bind.hpp>
#include <boost/date_time.hpp>
#include <stdlib.h>

using namespace Base;
using namespace std;

namespace logging = boost::log;
namespace sinks = boost::log::sinks;
namespace src = boost::log::sources;
namespace expr = boost::log::expressions;
namespace attrs = boost::log::attributes;
namespace keywords = boost::log::keywords;

BOOST_LOG_ATTRIBUTE_KEYWORD(Severity, "Severity", Base::SeverityLevel)
namespace Base
{
    static LoggerHH* theLogger = NULL;
}
namespace
{
    std::string GetTimeStr()
    {
        time_t curTime;
        time(&curTime);
        tm p;
        localtime_s(&p, &curTime);
        //char tmp[10];
        //strftime(tmp, sizeof(tmp), "%H:%M:%S", localtime(&curTime));
        std::stringstream ss;
        ss <<p.tm_year << "-" << p.tm_mon << "-" << p.tm_mday << " " << p.tm_hour << ":" << p.tm_min << ":" << p.tm_sec << " ";
        return ss.str();
    }

    void my_formatter(logging::record_view const& rec, logging::formatting_ostream& strm)
    {
        /*SeverityLevel level = rec[Severity].get();

        if (level >= SeverityLevel_Warning)
        {
            strm << "[" << rec[Severity] << "]" <<std::endl;
        }*/
        if (Base::theLogger&& Base::theLogger->IsOutputTime())
        {
            strm << GetTimeStr();
        }
        strm <<"[" << rec[Severity] << "]: ";


        // Finally, put the record message to the stream
        strm << rec[expr::smessage];
    }

    bool my_filter(logging::value_ref< SeverityLevel, tag::Severity> const& level)
    {
#ifdef _DEBUG
        return level >= SeverityLevel_Debug;
#else
        return level >= SeverityLevel_Info;
#endif
    }
}

LoggerHH* LoggerHH::GetLogger()
{
    if (!theLogger)
    {
        theLogger = new LoggerHH();
    }

    return theLogger;
}

LoggerHH::~LoggerHH()
{

}

LoggerHH::LoggerHH() : _boostLogger(keywords::severity = Base::SeverityLevel_Info), _outputTime(false)
{
    Init();
}

std::string LoggerHH::GetLogFile() const
{
    return _logFile;
}

void LoggerHH::Init()
{
    boost::filesystem::path tmppath = boost::filesystem::temp_directory_path();
    //boost::filesystem::path name = boost::filesystem::unique_path("%%%%_%%%%.rmlog");
    boost::posix_time::ptime timelocal = boost::posix_time::second_clock::local_time();
    std::string strTime = boost::posix_time::to_iso_string(timelocal);//time format is YYYYMMDDTHHMMSS

    //log file path example in windows: C:\Users\UserName\AppData\Local\Temp\HH_YYYYMMDDTHHMMSS.rmlog
    _logFile = tmppath.string() + "\\HH_" + strTime + ".rmlog";

    typedef sinks::synchronous_sink<sinks::text_ostream_backend> sink_t;
    boost::shared_ptr<sink_t> sink = boost::make_shared<sink_t>();

    sink->locked_backend()->add_stream(boost::make_shared<std::ofstream>(_logFile.c_str()));

    sink->locked_backend()->auto_flush(true);

    sink->set_formatter(&my_formatter);
    sink->set_filter(boost::phoenix::bind(&my_filter, Severity.or_none()));

    std::locale loc = boost::locale::generator()("en_US.UTF-8");
    sink->imbue(loc);

    logging::add_common_attributes();
    logging::core::get()->add_sink(sink);

    BOOST_LOG_SEV(_boostLogger, SeverityLevel_Info) << "Log File: " << _logFile;


    //boost::posix_time::ptime timelocal = boost::posix_time::second_clock::local_time();
    BOOST_LOG_SEV(_boostLogger, SeverityLevel_Info) << "Time Stamp: " << timelocal.date().year() << "-"
                                                                      << timelocal.date().month() << "-"
                                                                      << timelocal.date().day() << "  "
                                                                      << timelocal.time_of_day().hours() << ":"
                                                                      << timelocal.time_of_day().minutes() << ":"
                                                                      << timelocal.time_of_day().seconds();

    std::string envs = "Environment Variables\n";

    int idx = 1;
    for (char *item = *environ; item; idx++)
    {
        envs += std::string("    ") + item + "\n";
        item = *(environ + idx);
    }

    BOOST_LOG_SEV(_boostLogger, SeverityLevel_Info) <<  envs;
}


LogType& LoggerHH::GetBoostLogger()
{
    return _boostLogger;
}

void LoggerHH::SetOutputTime(bool isOutput)
{
    _outputTime = isOutput;
}

bool LoggerHH::IsOutputTime()
{
    return _outputTime;
}


MyStackWalker::MyStackWalker() : StackWalker(StackWalker::RetrieveSymbol | StackWalker::RetrieveLine), _index(0)
{}

std::string MyStackWalker::GetStackMsg()
{
    MyStackWalker walker;
    walker.ShowCallstack();
    return walker._stackMsg;
}

void MyStackWalker::OnOutput(LPCSTR szText)
{
    _index++;

    if (_index > 2)
        _stackMsg += "    " + std::string(szText);
}

void MyStackWalker::OnSymInit(LPCSTR szSearchPath, DWORD symOptions, LPCSTR szUserName)
{
    return;
}

void MyStackWalker::OnLoadModule(LPCSTR img, LPCSTR mod, DWORD64 baseAddr, DWORD size, DWORD result, LPCSTR symType, LPCSTR pdbName, ULONGLONG fileVersion)
{
    return;
}

void MyStackWalker::OnCallstackEntry(CallstackEntryType eType, CallstackEntry &entry)
{
    return StackWalker::OnCallstackEntry(eType, entry);
}

void MyStackWalker::OnDbgHelpErr(LPCSTR szFuncName, DWORD gle, DWORD64 addr)
{
    return;
}
