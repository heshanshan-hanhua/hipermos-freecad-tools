﻿/*===================================================================
Copyright (c) 2023 HHintech
Unpublished - All rights reserved

=====================================================================
File description:
SiemensNXNavigationStyle used to view in 3D mode.

=====================================================================
Date            Name            Description of Change
2023/04/19      LJ              Written
2023/04/27      LJ          Refactoring 3D View Operation Mode Code
2023/05/07      LL              Fixed bugs of key and mouse click at same time
2023/05/09      LL              Fixed bug of popmenu while navi event is not finished
2023/05/10      LL              Fixed view flush while panning 
HISTORY
====================================================================*/
#include "PreCompiled.h"
#ifndef _PreComp_
# include <cfloat>
# include "InventorAll.h"
# include <QAction>
# include <QActionGroup>
# include <QApplication>
# include <QByteArray>
# include <QCursor>
# include <QList>
# include <QMenu>
# include <QMetaObject>
# include <QRegExp>
#endif

#include <App/Application.h>
#include "NavigationStyle.h"
#include "View3DInventorViewer.h"
#include "Application.h"
#include "MenuManager.h"
#include "MouseSelection.h"

using namespace Gui;

// ----------------------------------------------------------------------------------

/* TRANSLATOR Gui::SiemensNXNavigationStyle */

TYPESYSTEM_SOURCE(Gui::SiemensNXNavigationStyle, Gui::UserNavigationStyleHH)

SiemensNXNavigationStyle::SiemensNXNavigationStyle()
{
}

SiemensNXNavigationStyle::~SiemensNXNavigationStyle()
{
}

const char* SiemensNXNavigationStyle::mouseButtons(ViewerMode mode)
{
    switch (mode) {
    case NavigationStyle::SELECTION:
        return QT_TR_NOOP("Press left mouse button");
    case NavigationStyle::PANNING:
        return QT_TR_NOOP("Press middle + right mouse button");
    case NavigationStyle::DRAGGING:
        return QT_TR_NOOP("Press middle mouse button");
    case NavigationStyle::ZOOMING:
        return QT_TR_NOOP("Scroll middle mouse button");
    default:
        return "No description";
    }
}

void SiemensNXNavigationStyle::rightMouseButtonHandling(const SoEvent* const ev, const SbBool& press, ViewerMode& newmode, SbBool& processed)
{
    const SoMouseButtonEvent* const event = (const SoMouseButtonEvent*)ev;
    // If we are in edit mode then simply ignore the RMB events
// to pass the event to the base class.
    this->lockrecenter = true;
    if (!viewer->isEditing()) {
        //Distinguish between right mouse click and long mouse press events
        if (press) {
            saveCursorPosition(ev);
            this->centerTime = ev->getTime();
            //processed = true;
        }
        else if (!press&&!_eventInProcessing)
        {
            SbTime tmp = (ev->getTime() - this->centerTime);
            float dci = (float)QApplication::doubleClickInterval() / 1000.0f;
            if (tmp.getValue() < dci)
            {
                if (this->isPopupMenuEnabled())
                {
                    this->openPopupMenu(event->getPosition());
                }
            }
        }
        else if (!press && (this->currentmode == NavigationStyle::PANNING ||
            this->currentmode == NavigationStyle::ZOOMING)) 
        {
            saveCursorPosition(ev);
        }
    }

    this->button2down = press;
}

void SiemensNXNavigationStyle::buttonComboHandling(const SoEvent* const ev, const ViewerMode& curmode, ButtonActionCombo combo, ViewerMode& newmode, SbBool& processed)
{
    unsigned int refactorCombo = (combo & BUTTON1DOWN ? BUTTON1DOWN : 0) |
        (combo & BUTTON2DOWN ? BUTTON2DOWN : 0) |
        (combo & BUTTON3DOWN ? BUTTON3DOWN : 0);

    if (!(combo & BUTTON1DOWN || combo & BUTTON2DOWN || combo & BUTTON3DOWN))
    {
        _eventInProcessing = false;
    }
    switch (refactorCombo) {
    case 0:
        if (curmode == NavigationStyle::SPINNING) { break; }
        newmode = NavigationStyle::IDLE;
        // The left mouse button has been released right now but
        // we want to avoid that the event is processed elsewhere
        if (this->lockButton1) {
            this->lockButton1 = false;
            processed = true;
        }
        break;
    case BUTTON1DOWN:
        // make sure not to change the selection when stopping spinning
        if (curmode == NavigationStyle::SPINNING || this->lockButton1)
            newmode = NavigationStyle::IDLE;
        else
            newmode = NavigationStyle::SELECTION;
        break;
    case BUTTON2DOWN | BUTTON3DOWN:
        saveCursorPosition(ev);
        newmode = NavigationStyle::PANNING;
        _eventInProcessing = true;
        break;
    case BUTTON3DOWN:
        saveCursorPosition(ev);
        newmode = NavigationStyle::DRAGGING;
        break;
    case BUTTON3DOWN | BUTTON1DOWN:
        newmode = NavigationStyle::IDLE;
        break;
    default:
        newmode = NavigationStyle::IDLE;
        break;
    }
}
