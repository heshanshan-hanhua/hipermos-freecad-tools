/***************************************************************************
 *   Copyright (c) 2005 Jürgen Riegel <juergen.riegel@web.de>              *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/
/*===================================================================
 Copyright (c) 2021 HHintech
 Unpublished - All rights reserved

=====================================================================
 File description: 

=====================================================================
 Date           Name            Description of Change
 2021/08/13     WangSong        support render selection highlight
 2021/08/17     Liulei          Upgrade
 2021/08/27     Liulei          Fixed bug of document is null
 2021/09/16       LL            fixed tips message
 2021/09/19       LL            Support select source type
 2021/09/26        LL           update select color while init
 2021/12/03     WS              fix highlight all bug
 2021/12/09     ZJF             add double click event
 2021/12/17     ZJF             increase double click interval
 2022/01/07     JHQ             do not set action handled after selection when left button click up
 2022/01/15      LL             Add SetMultiSelectEnable()
 2022/01/18      LL             Fixed bug of list select
 2022/04/07      ZJF            delete "action->setHandled()" in SelectObject
 2022/07/14      LL             Fixed display error of both subelement and wholeelement is allowed for select in the same time
 2022/07/21      LL             Do not interrupt handle while stay select
 2022/09/13      LL             Do not use emissive color for the moment which will make the display color different with configure color
 2022/09/22      LL             Fixed getPickedList to return objs allows in filter
 2023/07/19      LL             Add ignoreSheltered for getPickedList , donot select sheltered obj while select object
 2023/07/21      LL             Do not use shelter for getPickedList,for testers respound that capture edge is hard in some view direction
 2023/07/24      LL             Fixed bug of deselect obj by shift key
 2023/07/24      LL             Use shelter for getPickedList
 2023/07/26      LL             Fix concave edge of two face could not be selected
 2023/09/20      LL             Support select solid/shell
 2023/10/15      LL             Fix bug of select shelter obj in singlePick mode
 2023/11/08      HX             add getPntWidth/setPntWidth in SoHighlightElementAction
 2023/12/26      HX             add UserDefine_MODE in handleEvent
 2024/03/26      LL             Add SetLock
 2024/07/31      JHQ            Add UpdateSelection for selecting an already selected object
 2025/03/13       HX            add SelectionChanges::SelType para into UpdateSelection
 2025/03/17       HX            sent isIgnoreShelt para into getPickedList when selection mode
 2025/05/16       SHQ           fix double-clicking the arrow does not respond due to long time between the two events

 HISTORY
====================================================================*/
#include "PreCompiled.h"

#ifndef _PreComp_
# include <qstatusbar.h>
# include <qstring.h>
# include <Inventor/details/SoFaceDetail.h>
# include <Inventor/details/SoLineDetail.h>
#endif

#include <Inventor/elements/SoOverrideElement.h>
#include <Inventor/elements/SoLazyElement.h>
#include <Inventor/elements/SoCacheElement.h>
#include <Inventor/elements/SoWindowElement.h>

#include <Inventor/SoFullPath.h>
#include <Inventor/actions/SoGLRenderAction.h>
#include <Inventor/actions/SoHandleEventAction.h>
#include <Inventor/events/SoKeyboardEvent.h>
#include <Inventor/elements/SoComplexityElement.h>
#include <Inventor/elements/SoComplexityTypeElement.h>
#include <Inventor/elements/SoCoordinateElement.h>
#include <Inventor/elements/SoElements.h>
#include <Inventor/elements/SoFontNameElement.h>
#include <Inventor/elements/SoFontSizeElement.h>
#include <Inventor/elements/SoLineWidthElement.h>
#include <Inventor/elements/SoMaterialBindingElement.h>
#include <Inventor/elements/SoModelMatrixElement.h>
#include <Inventor/elements/SoShapeStyleElement.h>
#include <Inventor/elements/SoProfileCoordinateElement.h>
#include <Inventor/elements/SoProfileElement.h>
#include <Inventor/elements/SoSwitchElement.h>
#include <Inventor/elements/SoUnitsElement.h>
#include <Inventor/elements/SoViewVolumeElement.h>
#include <Inventor/elements/SoViewingMatrixElement.h>
#include <Inventor/elements/SoViewportRegionElement.h>
#include <Inventor/elements/SoGLCacheContextElement.h>
#include <Inventor/events/SoMouseButtonEvent.h>
#include <Inventor/misc/SoState.h>
#include <Inventor/misc/SoChildList.h>
#include <Inventor/nodes/SoMaterial.h>
#include <Inventor/nodes/SoMaterialBinding.h>
#include <Inventor/nodes/SoNormalBinding.h>
#include <Inventor/events/SoLocation2Event.h>
#include <Inventor/SoPickedPoint.h>
#include <Inventor/threads/SbStorage.h>

#ifdef FC_OS_MACOSX
# include <OpenGL/gl.h>
#else
# ifdef FC_OS_WIN32
#  include <windows.h>
# endif
# include <GL/gl.h>
#endif

#include <QtOpenGL.h>

#include <Base/Console.h>
#include <Base/Tools.h>
#include <App/Application.h>
#include <App/Document.h>
#include <Gui/Document.h>
#include <App/DocumentObject.h>
#include <App/ComplexGeoData.h>

#include "SoFCUnifiedSelection.h"
#include "Application.h"
#include "MainWindow.h"
#include "Selection.h"
#include "ViewProvider.h"
#include "SoFCInteractiveElement.h"
#include "SoFCSelectionAction.h"
#include "ViewProviderDocumentObject.h"
#include "ViewProviderGeometryObject.h"
#include "ViewParams.h"

//FreeCAD19_update
#include <Gui/Command.h>
#include <Gui/View3DInventor.h>
#include <Gui/ViewProvider.h>
#include "DlgObjectSelectionListHH.h"
namespace
{
    QElapsedTimer stayTimer;
    QPoint stayPoint;
    SoHandleEventAction* curAction = NULL;
    Gui::Dialog::DlgObjectSelectionList* segSelDlg = NULL;
    std::vector<SbTime> eventStartTime;
    std::vector<SbVec2s> eventPos;
    QElapsedTimer selectionCostTime;

    bool IgnoreRenderHidedObj = true;
}
//
FC_LOG_LEVEL_INIT("SoFCUnifiedSelection",false,true,true)

using namespace Gui;

namespace Gui {
std::array<std::pair<double, std::string>,3 > schemaTranslatePoint(double x, double y, double z, double precision);
}

SoFullPath * Gui::SoFCUnifiedSelection::currenthighlight = NULL;

// *************************************************************************

SO_NODE_SOURCE(SoFCUnifiedSelection)

/*!
  Constructor.
*/
SoFCUnifiedSelection::SoFCUnifiedSelection() : pcDocument(0), _allowListSelection(true),
_navigationMode(NavigationMode::OBSERVE_MODE), _allowMultiSelection(true)
{
    SO_NODE_CONSTRUCTOR(SoFCUnifiedSelection);

    SO_NODE_ADD_FIELD(colorHighlight, (SbColor(1.0f, 0.6f, 0.0f)));
    SO_NODE_ADD_FIELD(colorSelection, (SbColor(1.0f, 0.6f, 0.0f)));
    SO_NODE_ADD_FIELD(highlightMode,  (AUTO));
    SO_NODE_ADD_FIELD(selectionMode,  (ON));
    SO_NODE_ADD_FIELD(selectionRole, (true));
    SO_NODE_ADD_FIELD(isUDEHandled,  (false));
    SO_NODE_ADD_FIELD(useNewSelection, (true));
    SO_NODE_ADD_FIELD(isIgnoreShelt, (true));

    SO_NODE_DEFINE_ENUM_VALUE(HighlightModes, AUTO);
    SO_NODE_DEFINE_ENUM_VALUE(HighlightModes, ON);
    SO_NODE_DEFINE_ENUM_VALUE(HighlightModes, OFF);
    SO_NODE_SET_SF_ENUM_TYPE (highlightMode, HighlightModes);

    // Documentation of SoFullPath:
    // Since the SoFullPath is derived from SoPath and contains no private data, you can cast SoPath instances to the SoFullPath type.
    // This will allow you to examine hidden children. Actually, you are not supposed to allocate instances of this class at all.
    // It is only available as an "extended interface" into the superclass SoPath.
    detailPath = static_cast<SoFullPath*>(new SoPath(20));
    detailPath->ref();

    setPreSelection = false;
    preSelection = -1;
    useNewSelection = ViewParams::instance()->getUseNewSelection();
}

/*!
  Destructor.
*/
SoFCUnifiedSelection::~SoFCUnifiedSelection()
{
    // If we're being deleted and we're the current highlight,
    // NULL out that variable
    if (currenthighlight != NULL) {
        currenthighlight->unref();
        currenthighlight = NULL;
    }
    if (detailPath) {
        detailPath->unref();
        detailPath = NULL;
    }
}

// doc from parent
void
SoFCUnifiedSelection::initClass(void)
{
    SO_NODE_INIT_CLASS(SoFCUnifiedSelection,SoSeparator,"Separator");
}

void SoFCUnifiedSelection::finish()
{
    atexit_cleanup();
}

bool SoFCUnifiedSelection::hasHighlight() {
    return currenthighlight != NULL;
}

void SoFCUnifiedSelection::applySettings()
{
    float transparency;
    ParameterGrp::handle hGrp = Gui::WindowParameter::getDefaultParameter()->GetGroup("View");
    bool enablePre = hGrp->GetBool("EnablePreselection", true);
    bool enableSel = hGrp->GetBool("EnableSelection", true);
    if (!enablePre) 
    {
        this->highlightMode = SoFCUnifiedSelection::OFF;
    }

    // Search for a user defined value with the current color as default
    SbColor highlightColor = this->colorHighlight.getValue();
    unsigned long highlight = (unsigned long)(highlightColor.getPackedValue());
    highlight = hGrp->GetUnsigned("HighlightedObjColor", highlight);
    highlightColor.setPackedValue((uint32_t)highlight, transparency);
    this->colorHighlight.setValue(highlightColor);

    if (!enableSel) 
    {
        this->selectionMode = SoFCUnifiedSelection::OFF;
    }

    // Do the same with the selection color
    SbColor selectionColor = this->colorSelection.getValue();
    unsigned long selection = (unsigned long)(selectionColor.getPackedValue());
    selection = hGrp->GetUnsigned("SelectionColor", selection);
    selectionColor.setPackedValue((uint32_t)selection, transparency);
    this->colorSelection.setValue(selectionColor);
}

const char* SoFCUnifiedSelection::getFileFormatName(void) const
{
    return "Separator";
}

void SoFCUnifiedSelection::write(SoWriteAction * action)
{
    SoOutput * out = action->getOutput();
    if (out->getStage() == SoOutput::WRITE) {
        // Do not write out the fields of this class
        if (this->writeHeader(out, true, false)) return;
        SoGroup::doAction((SoAction *)action);
        this->writeFooter(out);
    }
    else {
        inherited::write(action);
    }
}

int SoFCUnifiedSelection::getPriority(const SoPickedPoint* p)
{
    const SoDetail* detail = p->getDetail();
    if (!detail)                                           return 0;
    if (detail->isOfType(SoFaceDetail::getClassTypeId()))  return 1;
    if (detail->isOfType(SoLineDetail::getClassTypeId()))  return 2;
    if (detail->isOfType(SoPointDetail::getClassTypeId())) return 3;
    return 0;
}

std::vector<SoFCUnifiedSelection::PickedInfo>
SoFCUnifiedSelection::getPickedList(SoHandleEventAction* action, bool singlePick, bool checkAllow, bool ignoreSheltered) const
{
    //checkAllow = false;
    ViewProvider *last_vp = 0;
    std::vector<PickedInfo> ret;

    const SoPickedPointList & points = action->getPickedPointList();
    //Max allowed shelter objs for the target obj could be selected
    //for concave edge of to face,the first picked obj is face,which make the edge sheltered
    int maxAllowShelterObjNum = 1;
    int curShelterObjNum = 0;
    //
    for(int i=0,count=points.getLength();i<count;++i) {
        PickedInfo info;
        info.pp = points[i];
        info.vpd = 0;
        ViewProvider *vp = 0;
        SoFullPath *path = static_cast<SoFullPath *>(info.pp->getPath());
        if (this->pcDocument && path && path->containsPath(action->getCurPath())) {
            vp = this->pcDocument->getViewProviderByPathFromHead(path);
            if(singlePick && last_vp && last_vp!=vp)
                return ret;
        }
        if(!vp || !vp->isDerivedFrom(ViewProviderDocumentObject::getClassTypeId())) {
            if(!singlePick) continue;
            if(ret.empty())
                ret.push_back(info);
            break;
        }
        info.vpd = static_cast<ViewProviderDocumentObject*>(vp);
        if(!(useNewSelection.getValue()||info.vpd->useNewSelectionModel()) || !info.vpd->isSelectable()) {
            if(!singlePick) continue;
            if(ret.empty()) {
                info.vpd = 0;
                ret.push_back(info);
            }
            break;
        }
        if(!info.vpd->getElementPicked(info.pp,info.element))
            continue;

        bool canBeSelected = true;
        if (checkAllow && this->pcDocument && info.vpd)
        {
            App::DocumentObject* obj = info.vpd->getObject();
            if (obj)
            {
                std::string docName = pcDocument->getDocument()->getName();
                std::string objName = obj->getNameInDocument();
                std::string subEleName = info.element;
                bool checkedSelectable = Gui::Selection().getTargetSelection(docName.c_str(), objName.c_str(),
                    subEleName.c_str(), objName, subEleName);
                if (!checkedSelectable && !Gui::Selection().IsSelectable(docName.c_str(), objName.c_str(), subEleName.c_str()))
                {
                    canBeSelected = false;
                }
            }
        }

        if (canBeSelected)
        {
            if (singlePick)
                last_vp = vp;
            ret.push_back(info);
        }
        else
        {
            if (ignoreSheltered&& curShelterObjNum >= maxAllowShelterObjNum)
            {
                return ret;
            }
            else
            {
                ++curShelterObjNum;
            }
        }
    }

    if(ret.size()<=1) return ret;

    // To identify the picking of lines in a concave area we have to
    // get all intersection points. If we have two or more intersection
    // points where the first is of a face and the second of a line with
    // almost similar coordinates we use the second point, instead.

    int picked_prio = getPriority(ret[0].pp);
    auto last_vpd = ret[0].vpd;
    const SbVec3f& picked_pt = ret.front().pp->getPoint();
    auto itPicked = ret.begin();
    for(auto it=ret.begin()+1;it!=ret.end();++it) {
        auto &info = *it;
        if(last_vpd != info.vpd)
            break;

        int cur_prio = getPriority(info.pp);
        const SbVec3f& cur_pt = info.pp->getPoint();

        if ((cur_prio > picked_prio) && picked_pt.equals(cur_pt, 0.01f)) {
            itPicked = it;
            picked_prio = cur_prio;
        }
    }

    if(singlePick) {
        std::vector<PickedInfo> sret(itPicked,itPicked+1);
        return sret;
    }
    if(itPicked != ret.begin())
        std::swap(*itPicked, *ret.begin());
    return ret;
}

void SoFCUnifiedSelection::doAction(SoAction *action)
{
    if (action->getTypeId() == SoFCEnableHighlightAction::getClassTypeId()) {
        SoFCEnableHighlightAction *preaction = (SoFCEnableHighlightAction*)action;
        if (preaction->highlight) {
            this->highlightMode = SoFCUnifiedSelection::AUTO;
        }
        else {
            this->highlightMode = SoFCUnifiedSelection::OFF;
        }
    }

    if (action->getTypeId() == SoFCEnableSelectionAction::getClassTypeId()) {
        SoFCEnableSelectionAction *selaction = (SoFCEnableSelectionAction*)action;
        if (selaction->selection) {
            this->selectionMode = SoFCUnifiedSelection::ON;
        }
        else {
            this->selectionMode = SoFCUnifiedSelection::OFF;
        }
    }

    //if (action->getTypeId() == SoFCSelectionColorAction::getClassTypeId()) {
    //    SoFCSelectionColorAction *colaction = (SoFCSelectionColorAction*)action;
    //    this->colorSelection = colaction->selectionColor;
    //}

    if (action->getTypeId() == SoFCHighlightColorAction::getClassTypeId()) {
        SoFCHighlightColorAction *colaction = (SoFCHighlightColorAction*)action;
        this->colorHighlight = colaction->highlightColor;
        this->colorSelection = colaction->highlightColor;
    }

    if (action->getTypeId() == SoFCHighlightAction::getClassTypeId()) {
        SoFCHighlightAction *hilaction = static_cast<SoFCHighlightAction*>(action);
        // Do not clear currently highlighted object when setting new pre-selection
        if (!setPreSelection && hilaction->SelChange.Type == SelectionChanges::RmvPreselect) {
            if (currenthighlight) {
                SoHighlightElementAction hlAction;
                hlAction.apply(currenthighlight);
                currenthighlight->unref();
                currenthighlight = 0;
            }
        }
        else if (highlightMode.getValue() != OFF
                    && hilaction->SelChange.Type == SelectionChanges::SetPreselect) {
            if (currenthighlight) {
                SoHighlightElementAction hlAction;
                hlAction.apply(currenthighlight);
                currenthighlight->unref();
                currenthighlight = 0;
            }

            App::Document* doc = App::GetApplication().getDocument(hilaction->SelChange.pDocName);
            App::DocumentObject* obj = doc->getObject(hilaction->SelChange.pObjectName);
            ViewProvider*vp = Application::Instance->getViewProvider(obj);
            SoDetail* detail = vp->getDetail(hilaction->SelChange.pSubName);

            SoHighlightElementAction hlAction;
            hlAction.setHighlighted(true);
            hlAction.setColor(this->colorHighlight.getValue());
            hlAction.setElement(detail);
            hlAction.apply(vp->getRoot());
            delete detail;

            SoSearchAction sa;
            sa.setNode(vp->getRoot());
            sa.apply(vp->getRoot());
            currenthighlight = static_cast<SoFullPath*>(sa.getPath()->copy());
            currenthighlight->ref();
        }

        if (useNewSelection.getValue())
            return;
    }

    if (action->getTypeId() == SoFCSelectionAction::getClassTypeId()) {
        SoFCSelectionAction *selaction = static_cast<SoFCSelectionAction*>(action);
        Gui::Document* changeGuiDoc = Gui::Application::Instance->activeDocument();
        if(_navigationMode != NavigationMode::OBSERVE_MODE || changeGuiDoc != this->pcDocument)
        {
            return;
        }
        if(selectionMode.getValue() == ON
            && (selaction->SelChange.Type == SelectionChanges::AddSelection
                || selaction->SelChange.Type == SelectionChanges::RmvSelection))
        {
            // selection changes inside the 3d view are handled in handleEvent()
            App::Document* doc = App::GetApplication().getDocument(selaction->SelChange.pDocName);
            if(!doc)
            {
                return;
            }
            App::DocumentObject* obj = doc->getObject(selaction->SelChange.pObjectName);
            ViewProvider* vp = Application::Instance->getViewProvider(obj);
            if(vp && (useNewSelection.getValue() || vp->useNewSelectionModel()) && vp->isSelectable())
            {
                SoDetail* detail = nullptr;
                detailPath->truncate(0);
                if(!selaction->SelChange.pSubName || !selaction->SelChange.pSubName[0] ||
                    vp->getDetailPath(selaction->SelChange.pSubName, detailPath, true, detail))
                {
                    SoSelectionElementAction::Type type = SoSelectionElementAction::None;
                    if(selaction->SelChange.Type == SelectionChanges::AddSelection) {
                        if(detail)
                            type = SoSelectionElementAction::Append;
                        else
                            type = SoSelectionElementAction::All;
                    }
                    else {
                        if(detail)
                            type = SoSelectionElementAction::Remove;
                        else
                            type = SoSelectionElementAction::None;
                    }

                    SoSelectionElementAction selectionAction(type);
                    selectionAction.setColor(this->colorSelection.getValue());
                    selectionAction.setElement(detail);
                    if(detailPath->getLength())
                        selectionAction.apply(detailPath);
                    else
                        selectionAction.apply(vp->getRoot());
                }
                detailPath->truncate(0);
                delete detail;
            }
        }
        else if(selaction->SelChange.Type == SelectionChanges::ClrSelection) 
        {
            SoSelectionElementAction selectionAction(SoSelectionElementAction::None);
            for(int i = 0; i < this->getNumChildren(); ++i)
                selectionAction.apply(this->getChild(i));
        }
        else if(selectionMode.getValue() == ON
            && selaction->SelChange.Type == SelectionChanges::SetSelection) 
        {
            std::vector<ViewProvider*> vps;
            if(this->pcDocument)
                vps = this->pcDocument->getViewProvidersOfType(ViewProviderDocumentObject::getClassTypeId());
            std::vector<ViewProviderDocumentObject*> selVpd;

            for(std::vector<ViewProvider*>::iterator it = vps.begin(); it != vps.end(); ++it) 
            {
                ViewProviderDocumentObject* vpd = static_cast<ViewProviderDocumentObject*>(*it);
                if(Selection().isSelected(vpd->getObject()) && vpd->isSelectable())
                {
                    selVpd.push_back(vpd);
                }
                else
                {
                    if(/*useNewSelection.getValue() ||*/ vpd->useNewSelectionModel())
                    {
                        SoSelectionElementAction action(SoSelectionElementAction::None);
                        action.setColor(this->colorSelection.getValue());
                        SoDetail* det = vpd->getDetail(selaction->SelChange.pSubName);
                        action.setElement(det);
                        action.apply(vpd->getRoot());
                    }
                    // <YJ> 30-Jun-2017
                    // Add the case of mesh feature's highlight when selected or not selected. Because the useNewSelectionModel()
                    // return value is false, and mesh feature(stl) can not highlight as the other type.
                    else
                    {
                        Gui::SelectionChanges chng;
                        chng.pDocName = vpd->getObject()->getDocument()->getName();
                        chng.pObjectName = vpd->getObject()->getNameInDocument();
                        chng.pSubName = 0;
                        chng.Type = SelectionChanges::ClrSelection;
                        vpd->updateSelectionDisplay(chng);
                    }
                }
            }
            for(auto& it : selVpd)
            {
                if(it->useNewSelectionModel())
                {
                    SoSelectionElementAction action(SoSelectionElementAction::All);
                    action.setColor(this->colorSelection.getValue());
                    SoDetail* det = it->getDetail(selaction->SelChange.pSubName);
                    action.setElement(det);
                    action.apply(it->getRoot());
                }
                else
                {
                    SbColor hColor = this->colorHighlight.getValue();
                    it->HighlightVpColor.setValue(hColor[0], hColor[1], hColor[2]);
                    if(_navigationMode == NavigationMode::SELECTION_MODE)
                    {
                        SbColor sColor = this->colorSelection.getValue();
                        it->SelectionVpColor.setValue(sColor[0], sColor[1], sColor[2]);
                    }
                    else
                    {
                        it->SelectionVpColor.setValue(hColor[0], hColor[1], hColor[2]);
                    }
                    Gui::SelectionChanges chng;
                    chng.pDocName = it->getObject()->getDocument()->getName();
                    chng.pObjectName = it->getObject()->getNameInDocument();
                    chng.pSubName = selaction->SelChange.pSubName;
                    chng.Type = SelectionChanges::SetSelection;
                    it->updateSelectionDisplay(chng);
                }
            }
        }
        else if(selaction->SelChange.Type == SelectionChanges::SetPreselectSignal) {
            // selection changes inside the 3d view are handled in handleEvent()
            App::Document* doc = App::GetApplication().getDocument(selaction->SelChange.pDocName);
            App::DocumentObject* obj = doc->getObject(selaction->SelChange.pObjectName);
            ViewProvider* vp = Application::Instance->getViewProvider(obj);
            if(vp && vp->isDerivedFrom(ViewProviderDocumentObject::getClassTypeId()) &&
                (useNewSelection.getValue() || vp->useNewSelectionModel()) && vp->isSelectable())
            {
                detailPath->truncate(0);
                SoDetail* det = 0;
                if(vp->getDetailPath(selaction->SelChange.pSubName, detailPath, true, det)) {
                    setHighlight(detailPath, det, static_cast<ViewProviderDocumentObject*>(vp),
                        selaction->SelChange.pSubName,
                        selaction->SelChange.x,
                        selaction->SelChange.y,
                        selaction->SelChange.z);
                }
                delete det;
            }
        }

        if(useNewSelection.getValue())
            return;
    }

    inherited::doAction( action );
}

bool SoFCUnifiedSelection::setHighlight(const PickedInfo &info) {
    if(!info.pp)
        return setHighlight(0,0,0,0,0.0,0.0,0.0);
    const auto &pt = info.pp->getPoint();
    return setHighlight(static_cast<SoFullPath*>(info.pp->getPath()),
            info.pp->getDetail(), info.vpd, info.element.c_str(), pt[0],pt[1],pt[2]);
}

bool SoFCUnifiedSelection::setHighlight(SoFullPath *path, const SoDetail *det,
        ViewProviderDocumentObject *vpd, const char *element, float x, float y, float z)
{
    Base::FlagToggler<SbBool> flag(setPreSelection);

    bool highlighted = false;
    std::string subElementName;
    if(path && path->getLength() &&
       vpd && vpd->getObject() && vpd->getObject()->getNameInDocument())
    {
        std::string docname = vpd->getObject()->getDocument()->getName();
        std::string objname = vpd->getObject()->getNameInDocument();
        subElementName = element;
        Gui::Selection().getTargetSelection(docname.c_str(), objname.c_str(),
            subElementName.c_str(), objname, subElementName);
        ViewProvider* vp = this->pcDocument->getViewProvider
        (vpd->getObject()->getDocument()->getObject(objname.c_str()));
        if(vp && vp->isDerivedFrom(ViewProviderDocumentObject::getClassTypeId()))
        {
            vpd = static_cast<ViewProviderDocumentObject*>(vp);
        }
        else
        {
            return false;
        }
        det = vpd->getDetail(subElementName.c_str());
        SbColor hColor = this->colorHighlight.getValue();
        vpd->HighlightVpColor.setValue(hColor[0], hColor[1], hColor[2]);

        this->preSelection = 1;
        static char buf[513];
        std::string docLblName = vpd->getObject()->getDocument()->Label.getValue();
        std::string objLblName = vpd->getObject()->Label.getValue();
        auto pts = schemaTranslatePoint(x, y, z, 1e-7);
        snprintf(buf,512,"Preselected: %s.%s.%s (%f %s, %f %s, %f %s)"
                , docLblName.c_str(), objLblName.c_str(),element
                ,pts[0].first,pts[0].second.c_str()
                ,pts[1].first,pts[1].second.c_str()
                ,pts[2].first,pts[2].second.c_str());

        getMainWindow()->showMessage(QString::fromUtf8(buf));

        int ret = Gui::Selection().setPreselect(docname.c_str(),objname.c_str(), subElementName.c_str(),SelectionChanges::SelType_View,x,y,z);
        if(ret<0 && currenthighlight)
            return true;

        if(ret) {
            SoSearchAction sa;
            sa.setNode(vpd->getRoot());
            sa.apply(vpd->getRoot());

            if(sa.getPath())
            {
                if(currenthighlight && currenthighlight->getTail() != sa.getPath()->getTail()) {
                    SoHighlightElementAction action;
                    action.setHighlighted(false);
                    action.apply(currenthighlight);
                    currenthighlight->unref();
                    currenthighlight = 0;
                }
                highlighted = true;
                //currenthighlight = static_cast<SoFullPath*>(path->copy());
                currenthighlight = static_cast<SoFullPath*>(sa.getPath()->copy());
                currenthighlight->ref();
            }
        }
    }

    if(currenthighlight) {
        if (det || subElementName.empty())
        {
            SoHighlightElementAction action;
            action.setHighlighted(highlighted);
            action.setColor(this->colorHighlight.getValue());
            action.setElement(det);
            action.apply(currenthighlight);
        }
        if(!highlighted) {
            currenthighlight->unref();
            currenthighlight = 0;
            Selection().rmvPreselect(false,Gui::SelectionChanges::SelType_View);
        }
        this->touch();
    }
    return highlighted;
}

bool SoFCUnifiedSelection::setSelection(const std::vector<PickedInfo> &infos, bool ctrlDown) {
    if(infos.empty() || !infos[0].vpd)
    {
        if(!ctrlDown)
        {
            Gui::Selection().clearSelection(this->pcDocument->getDocument()->getName(), true, SelectionChanges::SelType_View);
        }
        return false;
    }

    std::vector<SelectionSingleton::SelObj> sels;
    if(infos.size()>1) {
        for(auto &info : infos) {
            if(!info.vpd) continue;

            SelectionSingleton::SelObj sel;
            sel.pResolvedObject = nullptr;
            sel.pObject = info.vpd->getObject();
            sel.pDoc = sel.pObject->getDocument();
            sel.DocName = sel.pDoc->getName();
            sel.FeatName = sel.pObject->getNameInDocument();
            sel.TypeName = sel.pObject->getTypeId().getName();
            sel.SubName = info.element.c_str();
            const auto &pt = info.pp->getPoint();
            sel.x = pt[0];
            sel.y = pt[1];
            sel.z = pt[2];
            sels.push_back(sel);
        }
    }

    const auto &info = infos[0];
    auto vpd = info.vpd;
    std::string objname = vpd->getObject()->getNameInDocument();
    if(objname.empty()) return false;
    std::string docname = vpd->getObject()->getDocument()->getName();

    std::string subElementName = info.element;
    Gui::Selection().getTargetSelection(docname.c_str(), objname.c_str(),
        subElementName.c_str(), objname, subElementName);
    ViewProvider* vp = this->pcDocument->getViewProvider
    (vpd->getObject()->getDocument()->getObject(objname.c_str()));
    if(vp && vp->isDerivedFrom(ViewProviderDocumentObject::getClassTypeId()))
    {
        vpd = static_cast<ViewProviderDocumentObject*>(vp);
    }
    else
    {
        if(!ctrlDown)
        {
            Gui::Selection().clearSelection(this->pcDocument->getDocument()->getName(), true, SelectionChanges::SelType_View);
        }
        return false;
    }
    bool hasNext = false;
    const SoPickedPoint * pp = info.pp;
    const SoDetail *det = pp->getDetail();
    det = vpd->getDetail(subElementName.c_str());

    SbColor sColor = this->colorHighlight.getValue();
    //SbColor sColor = this->colorSelection.getValue();
    vpd->SelectionVpColor.setValue(sColor[0], sColor[1], sColor[2]);

    SoDetail *detNext = 0;
    SoFullPath *pPath = static_cast<SoFullPath*>(pp->getPath());
    const auto &pt = pp->getPoint();
    SoSelectionElementAction::Type type = SoSelectionElementAction::None;
    HighlightModes mymode = (HighlightModes) this->highlightMode.getValue();
    static char buf[513];

    if(vpd && vpd->isSelectable())
    {
        if(ctrlDown)
        {
            if(Gui::Selection().IsSelectable(docname.c_str(), objname.c_str(), subElementName.c_str()))
            {
                if(Gui::Selection().isSelected(docname.c_str(), objname.c_str(), subElementName.c_str(), 0))
                {
                    Gui::Selection().rmvSelection(docname.c_str(), objname.c_str(), subElementName.c_str(), SelectionChanges::SelType_View, &sels);
                    type = SoSelectionElementAction::Remove;
                }
                else if(Gui::Selection().isSelected(docname.c_str(), objname.c_str(), "", 0))
                {
                    Gui::Selection().rmvSelection(docname.c_str(), objname.c_str(), "", SelectionChanges::SelType_View, &sels);
                    type = SoSelectionElementAction::None;
                }
                else
                {
                    bool ok = Gui::Selection().addSelection(docname.c_str(), objname.c_str(),
                        subElementName.c_str(), SelectionChanges::SelType_View, pt[0], pt[1], pt[2], &sels);
                    if(ok)
                    {
                        type = SoSelectionElementAction::Append;
                    }
                    if(ok && mymode == OFF) {
                        std::string docLblName = vpd->getObject()->getDocument()->Label.getValue();
                        std::string objLblName = vpd->getObject()->Label.getValue();

                        snprintf(buf, 512, "Selected: %s.%s.%s (%g, %g, %g)",
                            docLblName.c_str(), objLblName.c_str(), subElementName.c_str()
                            , fabs(pt[0]) > 1e-7 ? pt[0] : 0.0
                            , fabs(pt[1]) > 1e-7 ? pt[1] : 0.0
                            , fabs(pt[2]) > 1e-7 ? pt[2] : 0.0);

                        getMainWindow()->showMessage(QString::fromUtf8(buf));
                    }
                }
            }
        }
        else
        {
            Gui::Selection().clearSelection(docname.c_str(),true,SelectionChanges::SelType_View);
            if(!Gui::Selection().isSelected(docname.c_str(), objname.c_str(), subElementName.c_str()))
            {
                //Gui::Selection().clearSelection(documentName.c_str());
                bool ok = Gui::Selection().addSelection(docname.c_str(), objname.c_str(), subElementName.c_str(), SelectionChanges::SelType_View,
                    pp->getPoint()[0], pp->getPoint()[1], pp->getPoint()[2]);
                if(ok)
                {
                    if(currenthighlight && subElementName.empty())
                    {
                        type = SoSelectionElementAction::All;
                    }
                    else
                    {
                        type = SoSelectionElementAction::Append;
                    }
                }
            }
            else
            {
                if(currenthighlight && subElementName.empty())
                {
                    type = SoSelectionElementAction::All;
                }
                else
                    type = SoSelectionElementAction::Append;
            }
            //else {
            //    Gui::Selection().clearSelection(documentName.c_str());
            //    bool ok = Gui::Selection().addSelection(documentName.c_str()
            //                          ,objectName.c_str()
            //                          ,0
            //                          ,pp->getPoint()[0]
            //                          ,pp->getPoint()[1]
            //                          ,pp->getPoint()[2]);
            //    if (ok)
            //        type = SoSelectionElementAction::All;
            //}

            if(mymode == OFF)
            {
                snprintf(buf, 512, "Selected: %s.%s.%s (%f,%f,%f)", docname.c_str()
                    , objname.c_str()
                    , subElementName.c_str()
                    , pp->getPoint()[0]
                    , pp->getPoint()[1]
                    , pp->getPoint()[2]);

                getMainWindow()->showMessage(QString::fromLatin1(buf), 3000);
            }
        }
        //action->setHandled();
        if(pPath)
        {
            if (det || subElementName.empty())
            {
                SoSelectionElementAction action(type);
                action.setColor(this->colorHighlight.getValue());
                action.setElement(det);
                action.apply(pPath);
            }
            this->touch();

        }
    }
    return true;

    // Hierarchy ascending
    //
    // If the clicked subelement is already selected, check if there is an
    // upper hierarchy, and select that hierarchy instead.
    //
    // For example, let's suppose PickedInfo above reports
    // 'link.link2.box.Face1', and below Selection().getSelectedElement returns
    // 'link.link2.box.', meaning that 'box' is the current selected hierarchy,
    // and the user is clicking the box again.  So we shall go up one level,
    // and select 'link.link2.'
    //

    std::string objectName = objname;

    const char *subSelected = Gui::Selection().getSelectedElement(
                                vpd->getObject(), subElementName.c_str());

    FC_TRACE("select " << (subSelected?subSelected:"'null'") << ", " <<
            objectName << ", " << subElementName);
    std::string newElement;
    if(subSelected) {
        newElement = Data::ComplexGeoData::newElementName(subSelected);
        subSelected = newElement.c_str();
        std::string nextsub;
        const char *next = strrchr(subSelected,'.');
        if(next && next!=subSelected) {
            if(next[1]==0) {
                // The convention of dot separated SubName demands a mandatory
                // ending dot for every object name reference inside SubName.
                // The non-object sub-element, however, must not end with a dot.
                // So, next[1]==0 here means current selection is a whole object
                // selection (because no sub-element), so we shall search
                // upwards for the second last dot, which is the end of the
                // parent name of the current selected object
                for(--next;next!=subSelected;--next) {
                    if(*next == '.') break;
                }
            }
            if(*next == '.')
                nextsub = std::string(subSelected,next-subSelected+1);
        }
        if(nextsub.length() || *subSelected!=0) {
            hasNext = true;
            subElementName = nextsub;
            detailPath->truncate(0);
            if(vpd->getDetailPath(subElementName.c_str(),detailPath,true,detNext) &&
               detailPath->getLength())
            {
                pPath = detailPath;
                det = detNext;
                FC_TRACE("select next " << objectName << ", " << subElementName);
            }
        }
    }

#if 0 // ViewProviderDocumentObject now has default implementation of getElementPicked

    // If no next hierarchy is found, do another try on view provider hierarchies,
    // which is used by geo feature group.
    if(!hasNext) {
        bool found = false;
        auto vps = this->pcDocument->getViewProvidersByPath(pPath);
        for(auto it=vps.begin();it!=vps.end();++it) {
            auto vpdNext = it->first;
            if(Gui::Selection().isSelected(vpdNext->getObject(),"")) {
                found = true;
                continue;
            }
            if(!found || !vpdNext->useNewSelectionModel() || !vpdNext->isSelectable())
                continue;
            hasNext = true;
            vpd = vpdNext;
            det = 0;
            pPath->truncate(it->second+1);
            objectName = vpd->getObject()->getNameInDocument();
            subName = "";
            break;
        }
    }
#endif

    FC_TRACE("clearing selection");
    Gui::Selection().clearSelection(0,true, SelectionChanges::SelType_View);
    FC_TRACE("add selection");
    bool ok = Gui::Selection().addSelection(docname.c_str(), objectName.c_str() , subElementName.c_str(), SelectionChanges::SelType_View,
            pt[0] ,pt[1] ,pt[2], &sels);
    if (ok)
        type = hasNext?SoSelectionElementAction::All:SoSelectionElementAction::Append;

    if (mymode == OFF) {
        std::string docLblName = vpd->getObject()->getDocument()->Label.getValue();
        std::string objLblName = vpd->getObject()->Label.getValue();

        snprintf(buf,512,"Selected: %s.%s.%s (%g, %g, %g)",
            docLblName.c_str(), objLblName.c_str() , subElementName.c_str()
                ,fabs(pt[0])>1e-7?pt[0]:0.0
                ,fabs(pt[1])>1e-7?pt[1]:0.0
                ,fabs(pt[2])>1e-7?pt[2]:0.0);

        getMainWindow()->showMessage(QString::fromUtf8(buf));
    }

    if (pPath) {
        FC_TRACE("applying action");
        SoSelectionElementAction action(type);
        action.setColor(this->colorHighlight.getValue());
        action.setElement(det);
        action.apply(pPath);
        FC_TRACE("applied action");
        this->touch();
    }

    if(detNext) delete detNext;
    return true;
}

// doc from parent
void
SoFCUnifiedSelection::handleEvent(SoHandleEventAction * action)
{
    if (_navigationMode == NavigationMode::UserDefine_MODE)
    {
        inherited::handleEvent(action);
        // If event has been handled in others,doesn't handle it in this
        if (isUDEHandled.getValue()) 
        {
            isUDEHandled.setValue(false);
            return;
        }
    }

    // If off then don't handle this event
    if (!selectionRole.getValue()) {
        inherited::handleEvent(action);
        return;
    }

    if(segSelDlg != NULL)
    {
        return;
    }

    if(_navigationMode == NavigationMode::NavigationMode_None)
    {
        return;
    }

    if(_navigationMode == NavigationMode::SELECTION_MODE)
    {
        HandleEventWithSelectionMode(action);
        inherited::handleEvent(action);
        return;
    }

    HighlightModes mymode = (HighlightModes) this->highlightMode.getValue();
    const SoEvent * event = action->getEvent();

    // If we don't need to pick for locate highlighting,
    // then just behave as separator and return.
    // NOTE: we still have to pick for ON even though we don't have
    // to re-render, because the app needs to be notified as the mouse
    // goes over locate highlight nodes.
    //if (highlightMode.getValue() == OFF) {
    //    inherited::handleEvent( action );
    //    return;
    //}

    //
    // If this is a mouseMotion event, then check for locate highlighting
    //
    if (event->isOfType(SoLocation2Event::getClassTypeId())) {
        // NOTE: If preselection is off then we do not check for a picked point because otherwise this search may slow
        // down extremely the system on really big data sets. In this case we just check for a picked point if the data
        // set has been selected.
        if (mymode == AUTO || mymode == ON) {
            // check to see if the mouse is over our geometry...
            auto infos = this->getPickedList(action,true);
            if(infos.size())
                setHighlight(infos[0]);
            else {
                setHighlight(PickedInfo());
                if (this->preSelection > 0) {
                    this->preSelection = 0;
                    // touch() makes sure to call GLRenderBelowPath so that the cursor can be updated
                    // because only from there the SoGLWidgetElement delivers the OpenGL window
                    this->touch();
                }
            }
        }
    }
    // mouse press events for (de)selection
    else if (event->isOfType(SoMouseButtonEvent::getClassTypeId()) &&
             selectionMode.getValue() == SoFCUnifiedSelection::ON) {

        const SoMouseButtonEvent* e = static_cast<const SoMouseButtonEvent *>(event);
        if (SoMouseButtonEvent::isButtonReleaseEvent(e,SoMouseButtonEvent::BUTTON1)) {

            bool isStayType = false;
            if(stayTimer.isValid())
            {
                long msec = (long)stayTimer.elapsed();
                stayTimer.invalidate();
                long stayTime = 400;
                if(msec > stayTime)
                {
                    SbVec2s loc = e->getPosition();
                    short x, y;
                    loc.getValue(x, y);
                    if(QPoint(x, y) == stayPoint)
                    {
                        isStayType = true;
                    }
                }
            }

            if(isStayType)
            {
                //const SoPickedPoint* pp = this->getPickedPoint(action);
                SelectObjectInList(action);
                inherited::handleEvent(action);
                return;
            }

            HandleDoubleClickEvent(action);

            // check to see if the mouse is over a geometry...
            auto infos = this->getPickedList(action,!Selection().needPickedList());
            setSelection(infos, event->wasCtrlDown() && _allowMultiSelection);
            //if(setSelection(infos,event->wasCtrlDown()))
            //    action->setHandled();
        } // mouse release
        else if(SoMouseButtonEvent::isButtonPressEvent(e, SoMouseButtonEvent::BUTTON1))
        {
            stayTimer.start();
            SbVec2s loc = e->getPosition();
            short x, y;
            loc.getValue(x, y);
            stayPoint = QPoint(x, y);
        }
    }
    else if(event->isOfType(SoKeyboardEvent::getClassTypeId()))
    {
        const SoKeyboardEvent* e = static_cast<const SoKeyboardEvent*>(event);
        if(SoKeyboardEvent::isKeyPressEvent(e, SoKeyboardEvent::ESCAPE))
        {
            App::Document* docObj = App::GetApplication().getActiveDocument();
            if(docObj)
            {
                std::string documentName = docObj->getName();
                Gui::Selection().clearSelection(documentName.c_str(),true, SelectionChanges::SelType_View);
            }
        }
    }
    inherited::handleEvent(action);
}
//FreeCAD19_update
void Gui::SoFCUnifiedSelection::SetNavigationMode(NavigationMode mode /*= View3DInventorViewer::OBSERVE_MODE*/)
{
    _navigationMode = mode;
}

void Gui::SoFCUnifiedSelection::HandleEventWithSelectionMode(SoHandleEventAction* action)
{
    HighlightModes mymode = (HighlightModes)this->highlightMode.getValue();
    const SoEvent* event = action->getEvent();
    if(event->isOfType(SoLocation2Event::getClassTypeId()))
    {
        // NOTE: If preselection is off then we do not check for a picked point because otherwise this search may slow
        // down extremely the system on really big data sets. In this case we just check for a picked point if the data
        // set has been selected.
        if(mymode == AUTO || mymode == ON)
        {
            // check to see if the mouse is over our geometry...
            auto infos = this->getPickedList(action, false,true, isIgnoreShelt.getValue());
            const SoPickedPoint* pp = NULL;
            if(!infos.empty())
            {
                pp = infos.begin()->pp;
            }
            PreSelectObject(action, pp);
        }
    }
    // mouse press events for (de)selection
    else if(event->isOfType(SoMouseButtonEvent::getClassTypeId()) &&
        selectionMode.getValue() == SoFCUnifiedSelection::ON)
    {
        const SoMouseButtonEvent* e = static_cast<const SoMouseButtonEvent*>(event);
        if(SoMouseButtonEvent::isButtonReleaseEvent(e, SoMouseButtonEvent::BUTTON1))
        {
            if(GetMouseSelectionType() == MouseSelectionType_Single)
            {
                selectionCostTime.start();
                // check to see if the mouse is over a geometry...
                const SoPickedPoint* pp = NULL;
                auto infos = this->getPickedList(action, false,true, isIgnoreShelt.getValue());
                if (!infos.empty())
                {
                    pp = infos.begin()->pp;

                    //support deselect object while multi obj overlap 
                    if (event->wasShiftDown() && _allowMultiSelection)
                    {
                        for (auto& pItm : infos)
                        {
                            if (pItm.vpd && pItm.vpd->isSelectable())
                            {
                                std::string documentName = pItm.vpd->getObject()->getDocument()->getName();
                                std::string objectName = pItm.vpd->getObject()->getNameInDocument();
                                std::string subElementName = pItm.vpd->getElement(pItm.pp ? pItm.pp->getDetail() : 0);
                                if (Gui::Selection().isSelected(documentName.c_str()
                                    , objectName.c_str()
                                    , subElementName.c_str()))
                                {
                                    pp = pItm.pp;
                                    break;
                                }
                            }
                        }

                    }
                }
                SelectObject(action, pp);
                HandleDoubleClickEvent(action);
            }
            else if(GetMouseSelectionType() == MouseSelectionType_Polygon)
            {
                if(this->pcDocument)
                {
                    Gui::MDIView* view = this->pcDocument->getActiveView();
                    if(view->getTypeId().isDerivedFrom(Gui::View3DInventor::getClassTypeId()))
                    {
                        Gui::View3DInventorViewer* viewer = ((Gui::View3DInventor*)view)->getViewer();
                        if(viewer)
                        {
                            //Select object by boundarybox
                            Gui::Selection().signalMultipleSelectionSwitch(true);
                            std::map<ViewProvider*, std::set<std::string> > mapOfViewProviderAndSubSlement = viewer->GetViewProviderByBox();
                            SelectObject(action, mapOfViewProviderAndSubSlement);
                            Gui::Selection().signalMultipleSelectionSwitch(false);
                        }
                    }
                }

            }
            else if(GetMouseSelectionType() == MouseSelectionType_Stay)
            {
                //const SoPickedPoint* pp = this->getPickedPoint(action);
                SelectObjectInList(action);
            }
        } // mouse release
    }
}

void Gui::SoFCUnifiedSelection::PreSelectObject(SoHandleEventAction* action, const SoPickedPoint* pickPoint)
{
    SoFullPath* pPath = (pickPoint != NULL) ? static_cast<SoFullPath*>(pickPoint->getPath()) : NULL;
    ViewProvider* vp = 0;
    ViewProviderDocumentObject* vpd = 0;
    if(this->pcDocument && pPath && pPath->containsPath(action->getCurPath()))
        vp = this->pcDocument->getViewProviderByPathFromTail(pPath);
    if(vp && vp->isDerivedFrom(ViewProviderDocumentObject::getClassTypeId()))
        vpd = static_cast<ViewProviderDocumentObject*>(vp);

    const SoDetail* det = pickPoint ? pickPoint->getDetail() : 0;
    std::string documentName;
    std::string objectName;
    std::string subElementName;
    if(vpd)
    {
        documentName = vpd->getObject()->getDocument()->getName();
        objectName = vpd->getObject()->getNameInDocument();
        subElementName = vpd->getElement(pickPoint ? pickPoint->getDetail() : 0);
        Gui::Selection().getTargetSelection(documentName.c_str(), objectName.c_str(),
            subElementName.c_str(), objectName, subElementName);
        vp = this->pcDocument->getViewProvider
        (vpd->getObject()->getDocument()->getObject(objectName.c_str()));
        if(vp && vp->isDerivedFrom(ViewProviderDocumentObject::getClassTypeId()))
        {
            vpd = static_cast<ViewProviderDocumentObject*>(vp);
        }
    }
    //SbBool old_state = highlighted;
    bool highlighted = false;
    if(vpd && vpd->useNewSelectionModel() && vpd->isSelectable()) {
        det = vpd->getDetail(subElementName.c_str());
        this->preSelection = 1;
        static char buf[513];
        std::string docLblName = vpd->getObject()->getDocument()->Label.getValue();
        std::string objLblName = vpd->getObject()->Label.getValue();
        snprintf(buf, 512, "Preselected: %s.%s.%s (%f,%f,%f)", docLblName.c_str()
            , objLblName.c_str()
            , subElementName.c_str()
            , pickPoint->getPoint()[0]
            , pickPoint->getPoint()[1]
            , pickPoint->getPoint()[2]);

        getMainWindow()->showMessage(QString::fromUtf8(buf), 3000);

        if(Gui::Selection().setPreselect(documentName.c_str()
            , objectName.c_str()
            , subElementName.c_str(), SelectionChanges::SelType_View
            , pickPoint->getPoint()[0]
            , pickPoint->getPoint()[1]
            , pickPoint->getPoint()[2])){

            SoSearchAction sa;
            sa.setNode(vp->getRoot());
            sa.apply(vp->getRoot());
            if(sa.getPath()) {
                highlighted = true;
                if(currenthighlight && currenthighlight->getTail() != sa.getPath()->getTail()) {
                    SoHighlightElementAction action;
                    action.setHighlighted(false);
                    action.apply(currenthighlight);
                    currenthighlight->unref();
                    currenthighlight = 0;
                    //old_state = !highlighted;
                }

                currenthighlight = static_cast<SoFullPath*>(sa.getPath()->copy());
                currenthighlight->ref();
            }
        }
    }
    else if(vpd && vpd->isSelectable())
    {
        SbColor hColor = this->colorHighlight.getValue();
        vpd->HighlightVpColor.setValue(hColor[0], hColor[1], hColor[2]);

        this->preSelection = 1;
        static char buf[513];
        std::string docLblName = vpd->getObject()->getDocument()->Label.getValue();
        std::string objLblName = vpd->getObject()->Label.getValue();
        snprintf(buf, 512, "Preselected: %s.%s.%s (%f,%f,%f)", docLblName.c_str()
            , objLblName.c_str()
            , subElementName.c_str()
            , pickPoint->getPoint()[0]
            , pickPoint->getPoint()[1]
            , pickPoint->getPoint()[2]);

        getMainWindow()->showMessage(QString::fromUtf8(buf), 3000);

        Gui::Selection().setPreselect(documentName.c_str()
            , objectName.c_str()
            , subElementName.c_str(), SelectionChanges::SelType_View
            , pickPoint->getPoint()[0]
            , pickPoint->getPoint()[1]
            , pickPoint->getPoint()[2]);
    }
    // nothing picked
    else if(!pickPoint) {
        if(this->preSelection > 0) {
            this->preSelection = 0;
            // touch() makes sure to call GLRenderBelowPath so that the cursor can be updated
            // because only from there the SoGLWidgetElement delivers the OpenGL window
            this->touch();
        }
        Gui::Selection().rmvPreselect(false, Gui::SelectionChanges::SelType_View);
    }

    if(currenthighlight/* && old_state != highlighted*/) {
        if (det || subElementName.empty())
        {
            SoHighlightElementAction action;
            action.setHighlighted(highlighted);
            action.setColor(this->colorHighlight.getValue());
            action.setElement(det);
            if (vpd && subElementName.empty())
            {
                SoHighlightElementAction::Type type = SoHighlightElementAction::All;
                action.setElement(0);
                action.setType(type);
            }

            action.apply(currenthighlight);
        }

        if(!highlighted) {
            currenthighlight->unref();
            currenthighlight = 0;
        }
        this->touch();
    }
}

void Gui::SoFCUnifiedSelection::SelectObject(SoHandleEventAction* action, const SoPickedPoint* pickPoint)
{
    SoFullPath* pPath = (pickPoint != NULL) ? static_cast<SoFullPath*>(pickPoint->getPath()) : NULL;
    ViewProvider* vp = 0;
    if(this->pcDocument && pPath && pPath->containsPath(action->getCurPath()))
        vp = this->pcDocument->getViewProviderByPathFromTail(pPath);
    if(vp)
    {
        std::string subElementName = vp->getElement(pickPoint ? pickPoint->getDetail() : 0);
        SelectObject(action, vp, subElementName);
    }
}


void Gui::SoFCUnifiedSelection::SelectObjectInList(SoHandleEventAction* action)
{
    //const SoPickedPointList& points = action->getPickedPointList();
    auto infos = this->getPickedList(action, false);
    if(infos.size()== 0)
        return;

    const SoPickedPoint* curPicked = infos.begin()->pp;
    if(!_allowListSelection)
    {
        if (_navigationMode == NavigationMode::SELECTION_MODE)
        {
            SelectObject(action, curPicked);
        }
        else
        {
            setSelection(infos, action->getEvent()->wasCtrlDown() && _allowMultiSelection);
        }

        return;
    }

    std::vector<const SoPickedPoint*> pickedPoints;
    const SoPickedPoint* picked = (infos.begin()->pp );
    pickedPoints.push_back(picked);
    const SbVec3f& picked_pt = picked->getPoint();

    for(int i = 1; i < infos.size(); i++) {
        const SoPickedPoint* cur = infos[i].pp;
        const SbVec3f& cur_pt = cur->getPoint();

        if(cur == curPicked)
        {
            pickedPoints.insert(pickedPoints.begin(), cur);
        }
        else
        {
            pickedPoints.push_back(cur);
        }
    }

    std::vector<std::pair<ViewProviderDocumentObject*, std::string> > allowVpds;

    for(auto it : pickedPoints)
    {
        SoFullPath* pPath = (it != NULL) ? static_cast<SoFullPath*>(it->getPath()) : NULL;
        ViewProvider* vp = 0;
        if(this->pcDocument && pPath && pPath->containsPath(action->getCurPath()))
            vp = this->pcDocument->getViewProviderByPathFromTail(pPath);
        ViewProviderDocumentObject* vpd = 0;
        if(vp && vp->isDerivedFrom(ViewProviderDocumentObject::getClassTypeId()))
            vpd = static_cast<ViewProviderDocumentObject*>(vp);
        if(vpd /*&& vpd->useNewSelectionModel()*/ && vpd->isSelectable())
        {
            std::string documentName = vpd->getObject()->getDocument()->getName();
            std::string objectName = vpd->getObject()->getNameInDocument();
            std::string subElementName = vpd->getElement(it ? it->getDetail() : 0);
            Gui::Selection().getTargetSelection(documentName.c_str(), objectName.c_str(),
                subElementName.c_str(), objectName, subElementName);
            if(Gui::Selection().IsSelectable(documentName.c_str(), objectName.c_str(), subElementName.c_str()))
            {
                if(std::string(vpd->getObject()->getNameInDocument()) != objectName)
                {
                    vp = this->pcDocument->getViewProvider
                    (vpd->getObject()->getDocument()->getObject(objectName.c_str()));
                    if(vp && vp->isDerivedFrom(ViewProviderDocumentObject::getClassTypeId()))
                    {
                        vpd = static_cast<ViewProviderDocumentObject*>(vp);
                    }
                }

                if(vpd->isSelectable())
                {
                    std::pair<ViewProviderDocumentObject*, std::string> tmp = make_pair(vpd, subElementName);
                    if(std::find(allowVpds.begin(), allowVpds.end(), tmp) == allowVpds.end())
                    {
                        allowVpds.push_back(make_pair(vpd, subElementName));
                        SbColor hColor = this->colorHighlight.getValue();
                        vpd->HighlightVpColor.setValue(hColor[0], hColor[1], hColor[2]);
                    }
                }
            }
        }
    }

    if(allowVpds.empty())
    {
        return;
    }

    curAction = action;
    //visit list selection dialog
    segSelDlg = new Dialog::DlgObjectSelectionList(getMainWindow()->activeWindow());
    segSelDlg->move(QCursor::pos());
    segSelDlg->SetSegmentsForSelection(allowVpds);
    segSelDlg->signalSelectSegment.connect(boost::bind(&Gui::SoFCUnifiedSelection::slotSelectSegment, this, _1));
    segSelDlg->signalCancelSelect.connect(boost::bind(&Gui::SoFCUnifiedSelection::slotCancelSelect, this));
    //if (segSelDlg->exec())
    //{
    //    std::pair<ViewProviderDocumentObject*, std::string> sel = segSelDlg->GetSelSegment();
    //    SelectObject(action, sel.first, sel.second);
    //}
    segSelDlg->show();
}


void Gui::SoFCUnifiedSelection::SetAllowListSelection(bool val)
{
    _allowListSelection = val;
}

void Gui::SoFCUnifiedSelection::slotSelectSegment(const std::pair<ViewProviderDocumentObject*, std::string>& seg)
{
    SelectObject(curAction, seg.first, seg.second);
    slotCancelSelect();
}


void Gui::SoFCUnifiedSelection::slotCancelSelect()
{
    segSelDlg->signalSelectSegment.disconnect(boost::bind(&Gui::SoFCUnifiedSelection::slotSelectSegment, this, _1));
    segSelDlg->signalCancelSelect.disconnect(boost::bind(&Gui::SoFCUnifiedSelection::slotCancelSelect, this));
    segSelDlg->deleteLater();
    segSelDlg = NULL;
}

void Gui::SoFCUnifiedSelection::SelectObject(SoHandleEventAction* action, ViewProvider* vp, std::string subElement/* = ""*/)
{
    ViewProviderDocumentObject* vpd = 0;
    HighlightModes mymode = (HighlightModes)this->highlightMode.getValue();
    if(vp && vp->isDerivedFrom(ViewProviderDocumentObject::getClassTypeId()))
        vpd = static_cast<ViewProviderDocumentObject*>(vp);

    if(vpd /*&& vpd->useNewSelectionModel()*/ && vpd->isSelectable())
    {
        SoSelectionElementAction::Type type = SoSelectionElementAction::None;
        std::string documentName = vpd->getObject()->getDocument()->getName();
        std::string objectName = vpd->getObject()->getNameInDocument();
        std::string subElementName = subElement;
        Gui::Selection().getTargetSelection(documentName.c_str(), objectName.c_str(),
            subElementName.c_str(), objectName, subElementName);
        vp = this->pcDocument->getViewProvider
        (vpd->getObject()->getDocument()->getObject(objectName.c_str()));
        if(vp && vp->isDerivedFrom(ViewProviderDocumentObject::getClassTypeId()))
        {
            vpd = static_cast<ViewProviderDocumentObject*>(vp);
        }

        SbColor hColor = this->colorSelection.getValue();
        if(_navigationMode == NavigationMode::OBSERVE_MODE)
        {
            hColor = this->colorHighlight.getValue();
        }

        if(!vpd->useNewSelectionModel())
        {
            ViewProvider* vb = this->pcDocument->getViewProvider
            (this->pcDocument->getDocument()->getObject(objectName.c_str()));
            ViewProviderDocumentObject* vbd = NULL;
            if(vb && vb->isDerivedFrom(ViewProviderDocumentObject::getClassTypeId()))
            {
                vbd = static_cast<ViewProviderDocumentObject*>(vb);
                vbd->SelectionVpColor.setValue(hColor[0], hColor[1], hColor[2]);
            }
        }

        const SoEvent* event = action->getEvent();

        if (!_allowMultiSelection)
        {
            Gui::Selection().clearSelection(documentName.c_str(), true, SelectionChanges::SelType_View);
        }
        
        if(event->wasShiftDown()&& _allowMultiSelection)
        {
            if(Gui::Selection().isSelected(documentName.c_str()
                , objectName.c_str()
                , subElementName.c_str()))
            {
                std::string objSign = Gui::Selection().GetSelectedObjSign(documentName.c_str(),
                    objectName.c_str(),
                    subElementName.c_str());
                std::string objSelectedSignType = Gui::Selection().GetSelectedSignType();
                if(objSign != objSelectedSignType)
                {
                    Gui::Selection().rmvSelection(documentName.c_str()
                        , objectName.c_str()
                        , subElementName.c_str(),SelectionChanges::SelType_View);
                    type = SoSelectionElementAction::Remove;
                }
            }
            else
            {
                std::string parNm;
                vpd->GetParentElement(subElementName, parNm);
                if (Gui::Selection().isSelected(documentName.c_str()
                    , objectName.c_str(), parNm.c_str()))
                {
                    if (Gui::Selection().IsSelectable(documentName.c_str(), objectName.c_str(), parNm.c_str()) == true)
                    {
                        std::string objSign = Gui::Selection().GetSelectedObjSign(documentName.c_str(),
                            objectName.c_str(),
                            parNm.c_str());
                        std::string objSelectedSignType = Gui::Selection().GetSelectedSignType();
                        if (objSign != objSelectedSignType)
                        {
                            Gui::Selection().rmvSelection(documentName.c_str()
                                , objectName.c_str(), parNm.c_str(), SelectionChanges::SelType_View);
                            type = SoSelectionElementAction::None;
                        }
                    }

                }
            }
        }
        else
        { // no Shift
            if(!Gui::Selection().isSelected(documentName.c_str()
                , objectName.c_str()
                , subElementName.c_str())) {
                //Gui::Selection().clearSelection(documentName.c_str());
                bool ok = Gui::Selection().addSelection(documentName.c_str()
                    , objectName.c_str()
                    , subElementName.c_str(), SelectionChanges::SelType_View
                );
                if(ok)
                    type = SoSelectionElementAction::Append;
            }
            else
            {
                Gui::Selection().UpdateSelection(documentName.c_str()
                    , objectName.c_str()
                    , subElementName.c_str(), SelectionChanges::SelType_View);
            }

            if(mymode == OFF)
            {
                static char buf[513];
                std::string docLblName = documentName;
                std::string objLblName = objectName;
                if(vpd)
                {
                    docLblName = vpd->getObject()->getDocument()->Label.getValue();
                    objLblName = vpd->getObject()->Label.getValue();
                }
                snprintf(buf, 512, "Selected: %s.%s.%s", docLblName.c_str()
                    , objLblName.c_str()
                    , subElementName.c_str());

                getMainWindow()->showMessage(QString::fromUtf8(buf), 3000);
            }
        }

        //action->setHandled();  //This code will cause the drag process to fail in "SELECTION_MODE".
        if(vpd && _navigationMode == OBSERVE_MODE)
        {
            SoDetail* detail = vpd->getDetail(subElement.c_str());
            SoSelectionElementAction action(type);
            action.setColor(hColor);
            action.setElement(detail);
            action.apply(vp->getRoot());
            this->touch();
        }
    }
}

void Gui::SoFCUnifiedSelection::SelectObject(SoHandleEventAction* action, std::map<ViewProvider*, std::set<std::string> > vp)
{
    for(std::map<ViewProvider*, std::set<std::string> >::iterator it = vp.begin(); it != vp.end(); ++it)
    {
        if(it->second.empty())
        {
            SelectObject(action, it->first);
        }
        else
        {
            for(std::set<std::string>::iterator subIte = it->second.begin(); subIte != it->second.end(); ++subIte)
            {
                SelectObject(action, it->first, *subIte);
            }
        }

    }
}

MouseSelectionType Gui::SoFCUnifiedSelection::GetMouseSelectionType() const
{
    if(this->pcDocument)
    {
        Gui::MDIView* view = this->pcDocument->getActiveView();
        if(view->getTypeId().isDerivedFrom(Gui::View3DInventor::getClassTypeId()))
        {
            Gui::View3DInventorViewer* viewer = ((Gui::View3DInventor*)view)->getViewer();
            if(viewer)
            {
                return viewer->GetMouseSelectionType();
            }
        }
    }
    return Gui::MouseSelectionType::MouseSelectionType_Single;
}
//end
void SoFCUnifiedSelection::GLRenderBelowPath(SoGLRenderAction * action)
{
    inherited::GLRenderBelowPath(action);

    // nothing picked, so restore the arrow cursor if needed
    if (this->preSelection == 0) {
        // this is called when a selection gate forbade to select an object
        // and the user moved the mouse to an empty area
        this->preSelection = -1;
        QtGLWidget* window;
        SoState *state = action->getState();
        SoGLWidgetElement::get(state, window);
        QWidget* parent = window ? window->parentWidget() : 0;
        if (parent) {
            QCursor c = parent->cursor();
            if (c.shape() == Qt::ForbiddenCursor) {
                c.setShape(Qt::ArrowCursor);
                parent->setCursor(c);
            }
        }
    }
}

//if the two clicks are short apart,judge to be double-click
void SoFCUnifiedSelection::HandleDoubleClickEvent(
    SoHandleEventAction* action)
{
    const SoEvent* event = action->getEvent();
    float sec = 0.0;
    if (selectionCostTime.isValid())
    {
        sec = selectionCostTime.elapsed()/1000.0;
        selectionCostTime.invalidate();
    }
    if (eventStartTime.empty() && eventPos.empty())
    {
        eventStartTime.push_back(event->getTime());
        eventPos.push_back(event->getPosition());
    }

    else if (eventStartTime.size() == 1 && eventPos.size() == 1)
    {
        auto infos = this->getPickedList(action, false,false);
        SbTime timeDiff = event->getTime() - eventStartTime.front();
        float dci = (float)QApplication::doubleClickInterval()*1.5f / 1000.0f + sec;
        if (timeDiff.getValue() < dci && event->getPosition() == eventPos.front())
        {
            eventStartTime.clear();
            eventPos.clear();

            if (!infos.empty())
            {
                Gui::ViewProvider* vp = infos.begin()->vpd;
                vp->DoubleClickViewObject();
            }
            return;
        }
        else
        {
            eventStartTime.pop_back();
            eventStartTime.push_back(event->getTime());
            eventPos.pop_back();
            eventPos.push_back(event->getPosition());
        }
    }
}

void  SoFCUnifiedSelection::SetMultiSelectEnable(bool val)
{
    _allowMultiSelection = val;
}

bool SoFCUnifiedSelection::IsMultiSelectEnabled()
{
    return _allowMultiSelection;
}
// ---------------------------------------------------------------

SO_ACTION_SOURCE(SoHighlightElementAction)

void SoHighlightElementAction::initClass()
{
    SO_ACTION_INIT_CLASS(SoHighlightElementAction,SoAction);

    SO_ENABLE(SoHighlightElementAction, SoSwitchElement);

    SO_ACTION_ADD_METHOD(SoNode,nullAction);

    SO_ENABLE(SoHighlightElementAction, SoCoordinateElement);

    SO_ACTION_ADD_METHOD(SoGroup,callDoAction);
    SO_ACTION_ADD_METHOD(SoIndexedLineSet,callDoAction);
    SO_ACTION_ADD_METHOD(SoIndexedFaceSet,callDoAction);
    SO_ACTION_ADD_METHOD(SoPointSet,callDoAction);

    //SO_ACTION_ADD_METHOD(SoCamera, callDoAction);

    //SO_ACTION_ADD_METHOD(SoCoordinate3, callDoAction);
}

SoHighlightElementAction::SoHighlightElementAction () : _highlight(false), _det(0), _type(SINGLE)
{
    SO_ACTION_CONSTRUCTOR(SoHighlightElementAction);
}

SoHighlightElementAction::~SoHighlightElementAction()
{
}

void SoHighlightElementAction::beginTraversal(SoNode *node)
{
    traverse(node);
}

void SoHighlightElementAction::callDoAction(SoAction *action,SoNode *node)
{
    node->doAction(action);
}

void SoHighlightElementAction::setHighlighted(SbBool ok)
{
    this->_highlight = ok;
}

SbBool SoHighlightElementAction::isHighlighted() const
{
    return this->_highlight;
}

void SoHighlightElementAction::setColor(const SbColor& c)
{
    this->_color = c;
}

const SbColor& SoHighlightElementAction::getColor() const
{
    return this->_color;
}

void SoHighlightElementAction::setElement(const SoDetail* det)
{
    this->_det = det;
}

const SoDetail* SoHighlightElementAction::getElement() const
{
    return this->_det;
}

//FreeCAD19_update


void Gui::SoHighlightElementAction::setType(Type t)
{
    _type = t;
}

Gui::SoHighlightElementAction::Type Gui::SoHighlightElementAction::getType() const
{
    return _type;
}
// ---------------------------------------------------------------

SO_ACTION_SOURCE(SoSelectionElementAction)

void SoSelectionElementAction::initClass()
{
    SO_ACTION_INIT_CLASS(SoSelectionElementAction,SoAction);

    SO_ENABLE(SoSelectionElementAction, SoSwitchElement);

    SO_ACTION_ADD_METHOD(SoNode,nullAction);

    SO_ENABLE(SoSelectionElementAction, SoCoordinateElement);

    SO_ACTION_ADD_METHOD(SoCoordinate3,callDoAction);
    SO_ACTION_ADD_METHOD(SoGroup,callDoAction);
    SO_ACTION_ADD_METHOD(SoIndexedLineSet,callDoAction);
    SO_ACTION_ADD_METHOD(SoIndexedFaceSet,callDoAction);
    SO_ACTION_ADD_METHOD(SoPointSet,callDoAction);
}

SoSelectionElementAction::SoSelectionElementAction(Type t, bool secondary)
    : _type(t), _det(0), _secondary(secondary), _selectionType(Selected)
{
    SO_ACTION_CONSTRUCTOR(SoSelectionElementAction);
}

SoSelectionElementAction::~SoSelectionElementAction()
{
}

void SoSelectionElementAction::beginTraversal(SoNode *node)
{
    traverse(node);
}

void SoSelectionElementAction::callDoAction(SoAction *action,SoNode *node)
{
    node->doAction(action);
}

SoSelectionElementAction::Type
SoSelectionElementAction::getType() const
{
    return this->_type;
}

void SoSelectionElementAction::setColor(const SbColor& c)
{
    this->_color = c;
}

const SbColor& SoSelectionElementAction::getColor() const
{
    return this->_color;
}

void SoSelectionElementAction::setElement(const SoDetail* det)
{
    this->_det = det;
}

const SoDetail* SoSelectionElementAction::getElement() const
{
    return this->_det;
}

//FreeCAD19_update

void Gui::SoSelectionElementAction::SetSelectionType(SelectionType sType)
{
    _selectionType = sType;
}

Gui::SoSelectionElementAction::SelectionType Gui::SoSelectionElementAction::GetSelectionType() const
{
    return _selectionType;
}
// ---------------------------------------------------------------

SO_ACTION_SOURCE(SoVRMLAction)

void SoVRMLAction::initClass()
{
    SO_ACTION_INIT_CLASS(SoVRMLAction,SoAction);

    SO_ENABLE(SoVRMLAction, SoSwitchElement);

    SO_ACTION_ADD_METHOD(SoNode,nullAction);

    SO_ENABLE(SoVRMLAction, SoCoordinateElement);
    SO_ENABLE(SoVRMLAction, SoMaterialBindingElement);
    SO_ENABLE(SoVRMLAction, SoLazyElement);
    SO_ENABLE(SoVRMLAction, SoShapeStyleElement);

    SO_ACTION_ADD_METHOD(SoCoordinate3,callDoAction);
    SO_ACTION_ADD_METHOD(SoMaterialBinding,callDoAction);
    SO_ACTION_ADD_METHOD(SoMaterial,callDoAction);
    SO_ACTION_ADD_METHOD(SoNormalBinding,callDoAction);
    SO_ACTION_ADD_METHOD(SoGroup,callDoAction);
    SO_ACTION_ADD_METHOD(SoIndexedLineSet,callDoAction);
    SO_ACTION_ADD_METHOD(SoIndexedFaceSet,callDoAction);
    SO_ACTION_ADD_METHOD(SoPointSet,callDoAction);
}

SoVRMLAction::SoVRMLAction() : overrideMode(true)
{
    SO_ACTION_CONSTRUCTOR(SoVRMLAction);
}

SoVRMLAction::~SoVRMLAction()
{
}

void SoVRMLAction::setOverrideMode(SbBool on)
{
    overrideMode = on;
}

SbBool SoVRMLAction::isOverrideMode() const
{
    return overrideMode;
}

void SoVRMLAction::callDoAction(SoAction *action, SoNode *node)
{
    if (node->getTypeId().isDerivedFrom(SoNormalBinding::getClassTypeId()) && action->isOfType(SoVRMLAction::getClassTypeId())) {
        SoVRMLAction* vrmlAction = static_cast<SoVRMLAction*>(action);
        if (vrmlAction->overrideMode) {
            SoNormalBinding* bind = static_cast<SoNormalBinding*>(node);
            vrmlAction->bindList.push_back(bind->value.getValue());
            // this normal binding causes some problems for the part view provider
            // See also #0002222: Number of normals in exported VRML is wrong
            if (bind->value.getValue() == static_cast<int>(SoNormalBinding::PER_VERTEX_INDEXED))
                bind->value = SoNormalBinding::OVERALL;
        }
        else if (!vrmlAction->bindList.empty()) {
            static_cast<SoNormalBinding*>(node)->value = static_cast<SoNormalBinding::Binding>(vrmlAction->bindList.front());
            vrmlAction->bindList.pop_front();
        }
    }

    node->doAction(action);
}
// ---------------------------------------------------------------
// FreeCAD19_Update
SO_ACTION_SOURCE(SoChangeElementColorAction);

void SoChangeElementColorAction::initClass()
{
    SO_ACTION_INIT_CLASS(SoChangeElementColorAction, SoAction);

    SO_ENABLE(SoChangeElementColorAction, SoSwitchElement);

    SO_ACTION_ADD_METHOD(SoNode, nullAction);

    SO_ENABLE(SoChangeElementColorAction, SoCoordinateElement);

    SO_ACTION_ADD_METHOD(SoCoordinate3, callDoAction);
    SO_ACTION_ADD_METHOD(SoGroup, callDoAction);
    SO_ACTION_ADD_METHOD(SoIndexedLineSet, callDoAction);
    SO_ACTION_ADD_METHOD(SoIndexedFaceSet, callDoAction);
    SO_ACTION_ADD_METHOD(SoPointSet, callDoAction);
}

SoChangeElementColorAction::SoChangeElementColorAction(Type t) : _type(t), lineWidth(1.0), pntWidth(2.0)
{
    SO_ACTION_CONSTRUCTOR(SoChangeElementColorAction);
}

SoChangeElementColorAction::~SoChangeElementColorAction()
{
}

void SoChangeElementColorAction::beginTraversal(SoNode* node)
{
    traverse(node);
}

void SoChangeElementColorAction::callDoAction(SoAction* action, SoNode* node)
{
    node->doAction(action);
}

SoChangeElementColorAction::Type
SoChangeElementColorAction::getType() const
{
    return this->_type;
}

void SoChangeElementColorAction::setColor(const SbColor& c)
{
    this->_color = c;
}

const SbColor& SoChangeElementColorAction::getColor() const
{
    return this->_color;
}

void SoChangeElementColorAction::setElements(const std::vector<SoDetail*>& dets)
{
    this->_dets = dets;
}

std::vector<SoDetail*> SoChangeElementColorAction::getElements() const
{
    return this->_dets;
}

// ---------------------------------------------------------------
// ---------------------------------------------------------------------------------

bool SoFCSelectionRoot::StackComp::operator()(const Stack &a, const Stack &b) const {
    if(a.size()-a.offset < b.size()-b.offset)
        return true;
    if(a.size()-a.offset > b.size()-b.offset)
        return false;
    auto it1=a.rbegin(), end1=a.rend()-a.offset;
    auto it2=b.rbegin();
    for(;it1!=end1;++it1,++it2) {
        if(*it1 < *it2)
            return true;
        if(*it1 > *it2)
            return false;
    }
    return false;
}
// ---------------------------------------------------------------------------------
SoSeparator::CacheEnabled SoFCSeparator::CacheMode = SoSeparator::AUTO;
SO_NODE_SOURCE(SoFCSeparator)

SoFCSeparator::SoFCSeparator(bool trackCacheMode)
    :trackCacheMode(trackCacheMode)
{
    SO_NODE_CONSTRUCTOR(SoFCSeparator);
    if(!trackCacheMode) {
        renderCaching = SoSeparator::OFF;
        boundingBoxCaching = SoSeparator::OFF;
    }
}

void SoFCSeparator::GLRenderBelowPath(SoGLRenderAction * action) {
    if(trackCacheMode && renderCaching.getValue()!=CacheMode) {
        renderCaching = CacheMode;
        boundingBoxCaching = CacheMode;
    }
    inherited::GLRenderBelowPath(action);
}

void SoFCSeparator::initClass(void)
{
    SO_NODE_INIT_CLASS(SoFCSeparator,SoSeparator,"FCSeparator");
}

void SoFCSeparator::finish()
{
    atexit_cleanup();
}

// ---------------------------------------------------------------------------------
// Thread local data for bounding box rendering
//
// The code is inspred by Coin SoLevelOfDetails.cpp.
typedef struct {
    SoGetBoundingBoxAction * bboxaction;
    SoCube *cube;
    SoColorPacker *packer;
} SoFCBBoxRenderInfo;

static void so_bbox_construct_data(void * closure)
{
    SoFCBBoxRenderInfo * data = (SoFCBBoxRenderInfo*) closure;
    data->bboxaction = NULL;
    data->cube = NULL;
    data->packer = NULL;
}

static void so_bbox_destruct_data(void * closure)
{
    SoFCBBoxRenderInfo * data = (SoFCBBoxRenderInfo*) closure;
    delete data->bboxaction;
    if(data->cube)
        data->cube->unref();
    delete data->packer;
}

static SbStorage * so_bbox_storage = NULL;

// called from atexit
static void so_bbox_cleanup(void)
{
    delete so_bbox_storage;
}

// ---------------------------------------------------------------------------------

SoFCSelectionRoot::Stack SoFCSelectionRoot::SelStack;
std::unordered_map<SoAction*,SoFCSelectionRoot::Stack> SoFCSelectionRoot::ActionStacks;
SoFCSelectionRoot::ColorStack SoFCSelectionRoot::SelColorStack;
SoFCSelectionRoot::ColorStack SoFCSelectionRoot::HlColorStack;
SoFCSelectionRoot::ColorStack SoFCSelectionRoot::SelHlColorStack;// FreeCAD19_Update
SoFCSelectionRoot* SoFCSelectionRoot::ShapeColorNode;

SO_NODE_SOURCE(SoFCSelectionRoot)

SoFCSelectionRoot::SoFCSelectionRoot(bool trackCacheMode)
    :SoFCSeparator(trackCacheMode), lock(false)
{
    SO_NODE_CONSTRUCTOR(SoFCSelectionRoot);
    SO_NODE_ADD_FIELD(selectionStyle,(Full));
    SO_NODE_DEFINE_ENUM_VALUE(SelectStyles, Full);
    SO_NODE_DEFINE_ENUM_VALUE(SelectStyles, Box);
    SO_NODE_DEFINE_ENUM_VALUE(SelectStyles, PassThrough);
    SO_NODE_SET_SF_ENUM_TYPE(selectionStyle, SelectStyles);
}

SoFCSelectionRoot::~SoFCSelectionRoot()
{
}

void SoFCSelectionRoot::initClass(void)
{
    SO_NODE_INIT_CLASS(SoFCSelectionRoot,SoFCSeparator,"FCSelectionRoot");

    so_bbox_storage = new SbStorage(sizeof(SoFCBBoxRenderInfo),
            so_bbox_construct_data, so_bbox_destruct_data);

    // cc_coin_atexit((coin_atexit_f*) so_bbox_cleanup);
}

void SoFCSelectionRoot::finish()
{
    so_bbox_cleanup();
    atexit_cleanup();
}

SoNode *SoFCSelectionRoot::getCurrentRoot(bool front, SoNode *def) {
    if(SelStack.size())
        return front?SelStack.front():SelStack.back();
    return def;
}

SoFCSelectionContextBasePtr SoFCSelectionRoot::getNodeContext(
        Stack &stack, SoNode *node, SoFCSelectionContextBasePtr def)
{
    if(stack.empty())
        return def;

    SoFCSelectionRoot *front = stack.front();

    // NOTE: _node is not necessary of type SoFCSelectionRoot, but it is safe
    // here since we only use it as searching key, although it is probably not
    // a best practice.
    stack.front() = static_cast<SoFCSelectionRoot*>(node);

    auto it = front->contextMap.find(stack);
    stack.front() = front;
    if(it!=front->contextMap.end())
        return it->second;
    return SoFCSelectionContextBasePtr();
}

SoFCSelectionContextBasePtr
SoFCSelectionRoot::getNodeContext2(Stack &stack, SoNode *node, SoFCSelectionContextBase::MergeFunc *merge)
{
    SoFCSelectionContextBasePtr ret;
    if(stack.empty() || stack.back()->contextMap2.empty())
        return ret;

    int status = 0;
    auto *back = stack.back();
    auto &map = back->contextMap2;
    stack.back() = static_cast<SoFCSelectionRoot*>(node);
    for(stack.offset=0;stack.offset<stack.size();++stack.offset) {
        auto it = map.find(stack);
        SoFCSelectionContextBasePtr ctx;
        if(it!=map.end())
            ctx = it->second;
        status = merge(status,ret,ctx,stack.offset==stack.size()-1?0:stack[stack.offset]);
        if(status<0)
            break;
    }
    stack.offset = 0;
    stack.back() = back;
    return ret;
}

std::pair<bool,SoFCSelectionContextBasePtr*> SoFCSelectionRoot::findActionContext(
        SoAction *action, SoNode *_node, bool create, bool erase)
{
    std::pair<bool,SoFCSelectionContextBasePtr*> res(false,0);
    if(action->isOfType(SoSelectionElementAction::getClassTypeId()))
        res.first = static_cast<SoSelectionElementAction*>(action)->isSecondary();

    auto it = ActionStacks.find(action);
    if(it==ActionStacks.end() || it->second.empty())
        return res;

    auto &stack = it->second;

    auto node = static_cast<SoFCSelectionRoot*>(_node);

    if(res.first) {
        auto back = stack.back();
        stack.back() = node;
        if(create)
            res.second = &back->contextMap2[stack];
        else {
            auto it = back->contextMap2.find(stack);
            if(it!=back->contextMap2.end()) {
                res.second = &it->second;
                if(erase)
                    back->contextMap2.erase(it);
            }
        }
        stack.back() = back;
    }else{
        auto front = stack.front();
        stack.front() = node;
        if(create)
            res.second = &front->contextMap[stack];
        else {
            auto it = front->contextMap.find(stack);
            if(it!=front->contextMap.end()) {
                res.second = &it->second;
                if(erase)
                    front->contextMap.erase(it);
            }
        }
        stack.front() = front;
    }
    return res;
}

bool SoFCSelectionRoot::renderBBox(SoGLRenderAction *action, SoNode *node, SbColor color)
{
    auto data = (SoFCBBoxRenderInfo*) so_bbox_storage->get();
    if (data->bboxaction == NULL) {
        // The viewport region will be replaced every time the action is
        // used, so we can just feed it a dummy here.
        data->bboxaction = new SoGetBoundingBoxAction(SbViewportRegion());
        data->cube = new SoCube;
        data->cube->ref();
        data->packer = new SoColorPacker;
    }

    SbBox3f bbox;
    data->bboxaction->setViewportRegion(action->getViewportRegion());
    data->bboxaction->apply(node);
    bbox = data->bboxaction->getBoundingBox();
    if(bbox.isEmpty())
        return false;

    auto state = action->getState();

    state->push();

    SoMaterialBindingElement::set(state,SoMaterialBindingElement::OVERALL);
    SoLazyElement::setEmissive(state, &color);
    SoLazyElement::setDiffuse(state, node,1, &color, data->packer);
    SoDrawStyleElement::set(state, node, SoDrawStyleElement::LINES);
    SoLineWidthElement::set(state, node, 1.0f);

    const static float trans = 0.0;
    SoLazyElement::setTransparency(state, node, 1, &trans, data->packer);

    float x, y, z;
    bbox.getSize(x, y, z);
    data->cube->width  = x+0.001;
    data->cube->height  = y+0.001;
    data->cube->depth = z+0.001;

    SoModelMatrixElement::translateBy(state,node,bbox.getCenter());

    SoMaterialBundle mb(action);
    mb.sendFirst();

    data->cube->GLRender(action);

    state->pop();
    return true;
}

static std::time_t _CyclicLastReported;

void SoFCSelectionRoot::renderPrivate(SoGLRenderAction * action, bool inPath) {
    if(ViewParams::instance()->getCoinCycleCheck()
            && !SelStack.nodeSet.insert(this).second)
    {
        std::time_t t = std::time(0);
        if(_CyclicLastReported < t) {
            _CyclicLastReported = t+5;
            FC_ERR("Cyclic scene graph: " << getName());
        }
        return;
    }
    SelStack.push_back(this);
    if(_renderPrivate(action,inPath)) {
        if(inPath)
            SoSeparator::GLRenderInPath(action);
        else
            SoSeparator::GLRenderBelowPath(action);
    }
    SelStack.pop_back();
    SelStack.nodeSet.erase(this);
}

bool SoFCSelectionRoot::_renderPrivate(SoGLRenderAction * action, bool inPath) {
    auto ctx2 = std::static_pointer_cast<SelContext>(getNodeContext2(SelStack,this,SelContext::merge));
    if(ctx2 && ctx2->hideAll)
        return false;

    auto state = action->getState();
    SelContextPtr ctx = getRenderContext<SelContext>(this);
    int style = selectionStyle.getValue();
    if((style==SoFCSelectionRoot::Box || ViewParams::instance()->getShowSelectionBoundingBox())
       && ctx && !ctx->hideAll && (ctx->selAll || ctx->hlAll))
    {
        if (style==SoFCSelectionRoot::PassThrough) {
            style = SoFCSelectionRoot::Box;
        }
        else {
            renderBBox(action,this,ctx->hlAll?ctx->hlColor:ctx->selColor);
            return true;
        }
    }

    // Here, we are not setting (pre)selection color override here.
    // Instead, we are checking and setting up for any secondary context
    // color override.
    //
    // When the current selection style is full highlight, we should ignore any
    // secondary override. If the style is bounding box, however, we should
    // honour the secondary color override.

    bool colorPushed = false;
    if(!ShapeColorNode && overrideColor &&
        !SoOverrideElement::getDiffuseColorOverride(state) &&
        (style==SoFCSelectionRoot::Box || !ctx || (!ctx->selAll && !ctx->hideAll)))
    {
        ShapeColorNode = this;
        colorPushed = true;
        state->push();
        auto &packer = ShapeColorNode->shapeColorPacker;
        auto &trans = ShapeColorNode->transOverride;
        auto &color = ShapeColorNode->colorOverride;
        if(!SoOverrideElement::getTransparencyOverride(state) && trans) {
            SoLazyElement::setTransparency(state, ShapeColorNode, 1, &trans, &packer);
            SoOverrideElement::setTransparencyOverride(state,ShapeColorNode,true);
        }
        SoLazyElement::setDiffuse(state, ShapeColorNode, 1, &color, &packer);
        SoOverrideElement::setDiffuseColorOverride(state,ShapeColorNode,true);
        SoMaterialBindingElement::set(state, ShapeColorNode, SoMaterialBindingElement::OVERALL);
        SoOverrideElement::setMaterialBindingOverride(state,ShapeColorNode,true);

        SoTextureEnabledElement::set(state,ShapeColorNode,false);
    }

    if(!ctx) {
        if(inPath)
            SoSeparator::GLRenderInPath(action);
        else
            SoSeparator::GLRenderBelowPath(action);
    } else {
        bool selPushed;
        bool hlPushed;
        bool selHlPushed;// FreeCAD19_Update
        if((selPushed = ctx->selAll)) {
            SelColorStack.push_back(ctx->selColor);

            if(style != SoFCSelectionRoot::Box) {
                state->push();
                auto &color = SelColorStack.back();
                //SoLazyElement::setEmissive(state, &color);
                //SoLazyElement::setColorMaterial(state, false);
                //SoOverrideElement::setEmissiveColorOverride(state,this,true);
                //SoOverrideElement::setMaterialBindingOverride(state, this, true);
                //if (SoLazyElement::getLightModel(state) == SoLazyElement::BASE_COLOR) 
                {
                    auto &packer = shapeColorPacker;
                    SoLazyElement::setDiffuse(state, this, 1, &color, &packer);
                    SoOverrideElement::setDiffuseColorOverride(state,this,true);
                    SoMaterialBindingElement::set(state, this, SoMaterialBindingElement::OVERALL);
                    SoOverrideElement::setMaterialBindingOverride(state,this,true);
                }
            }
        }

        if((hlPushed = ctx->hlAll))
            HlColorStack.push_back(ctx->hlColor);

        // FreeCAD19_Update
        if ((selHlPushed = ctx->setHlAll))
        {
            SelHlColorStack.push_back(ctx->selHlColor);
            if (style != SoFCSelectionRoot::Box) {
                state->push();
                auto& color = SelHlColorStack.back();
                SoLazyElement::setEmissive(state, &color);
                SoOverrideElement::setEmissiveColorOverride(state, this, true);
                if (SoLazyElement::getLightModel(state) == SoLazyElement::BASE_COLOR) {
                    auto& packer = shapeColorPacker;
                    SoLazyElement::setDiffuse(state, this, 1, &color, &packer);
                    SoOverrideElement::setDiffuseColorOverride(state, this, true);
                    SoMaterialBindingElement::set(state, this, SoMaterialBindingElement::OVERALL);
                    SoOverrideElement::setMaterialBindingOverride(state, this, true);
                }
            }
        }
        //**************

        if(inPath)
            SoSeparator::GLRenderInPath(action);
        else
            SoSeparator::GLRenderBelowPath(action);

        if(selPushed) {
            SelColorStack.pop_back();

            if(style != SoFCSelectionRoot::Box)
                state->pop();
        }
        if(hlPushed)
            HlColorStack.pop_back();

        // FreeCAD19_Update
        if (selHlPushed)
        {
            SelHlColorStack.pop_back();
            if (style != SoFCSelectionRoot::Box)
                state->pop();
        }
    }

    if(colorPushed) {
        ShapeColorNode = 0;
        state->pop();
    }

    return false;
}

void SoFCSelectionRoot::GLRenderBelowPath(SoGLRenderAction * action) {
    Gui::Document* guiDoc = Gui::Application::Instance->activeDocument();
    if (guiDoc)
    {
        Gui::ViewProviderDocumentObject* vp = guiDoc->getViewProvider(this);
        if (vp && !vp->Visibility.getValue())
        {
            if (IgnoreRenderHidedObj)
            {
                return;
            }
        }
        
    }

    renderPrivate(action,false);
}

void SoFCSelectionRoot::GLRenderInPath(SoGLRenderAction * action) {
    if(action->getCurPathCode() == SoAction::BELOW_PATH)
        return GLRenderBelowPath(action);
    renderPrivate(action,true);
}

bool SoFCSelectionRoot::checkColorOverride(SoState *state) {
    if(ShapeColorNode) {
        if(!SoOverrideElement::getDiffuseColorOverride(state)) {
            state->push();
            auto &packer = ShapeColorNode->shapeColorPacker;
            auto &trans = ShapeColorNode->transOverride;
            auto &color = ShapeColorNode->colorOverride;
            if(!SoOverrideElement::getTransparencyOverride(state) && trans) {
                SoLazyElement::setTransparency(state, ShapeColorNode, 1, &trans, &packer);
                SoOverrideElement::setTransparencyOverride(state,ShapeColorNode,true);
            }
            SoLazyElement::setDiffuse(state, ShapeColorNode, 1, &color, &packer);
            SoOverrideElement::setDiffuseColorOverride(state,ShapeColorNode,true);
            SoMaterialBindingElement::set(state, ShapeColorNode, SoMaterialBindingElement::OVERALL);
            SoOverrideElement::setMaterialBindingOverride(state,ShapeColorNode,true);

            SoTextureEnabledElement::set(state,ShapeColorNode,false);
            return true;
        }
    }
    return false;
}

void SoFCSelectionRoot::checkSelection(bool &sel, SbColor &selColor, bool &hl, SbColor &hlColor, bool& selHl, SbColor& selHlColor) {
    sel = false;
    hl = false;
    selHl = false;// FreeCAD19_Update
    if((sel = !SelColorStack.empty()))
        selColor = SelColorStack.back();
    if((hl = !HlColorStack.empty()))
        hlColor = HlColorStack.back();

    // FreeCAD19_Update
    if (selHl = !SelHlColorStack.empty())
    {
        selHlColor = SelHlColorStack.back();
    }
}

void SoFCSelectionRoot::resetContext() {
    contextMap.clear();
}

void SoFCSelectionRoot::moveActionStack(SoAction *from, SoAction *to, bool erase) {
    auto it = ActionStacks.find(from);
    if(it == ActionStacks.end())
        return;
    auto &stack = ActionStacks[to];
    assert(stack.empty());
    stack.swap(it->second);
    if(erase)
        ActionStacks.erase(it);
}

#define BEGIN_ACTION \
    auto &stack = ActionStacks[action];\
    if(ViewParams::instance()->getCoinCycleCheck() \
        && !stack.nodeSet.insert(this).second) \
    {\
        std::time_t t = std::time(0);\
        if(_CyclicLastReported < t) {\
            _CyclicLastReported = t+5;\
            FC_ERR("Cyclic scene graph: " << getName());\
        }\
        return;\
    }\
    stack.push_back(this);\
    auto size = stack.size();

#define END_ACTION \
    if(stack.size()!=size || stack.back()!=this)\
        FC_ERR("action stack fault");\
    else {\
        stack.nodeSet.erase(this);\
        stack.pop_back();\
        if(stack.empty())\
            ActionStacks.erase(action);\
    }

void SoFCSelectionRoot::pick(SoPickAction * action) {
    BEGIN_ACTION;
    if(doActionPrivate(stack,action))
        inherited::pick(action);
    END_ACTION;
}

void SoFCSelectionRoot::rayPick(SoRayPickAction * action) {
    BEGIN_ACTION;
    if(doActionPrivate(stack,action))
        inherited::rayPick(action);
    END_ACTION;
}

void SoFCSelectionRoot::handleEvent(SoHandleEventAction * action) {
    BEGIN_ACTION;
    inherited::handleEvent(action);
    END_ACTION;
}

void SoFCSelectionRoot::search(SoSearchAction * action) {
    BEGIN_ACTION;
    inherited::search(action);
    END_ACTION;
}

void SoFCSelectionRoot::getPrimitiveCount(SoGetPrimitiveCountAction * action) {
    BEGIN_ACTION;
    inherited::getPrimitiveCount(action);
    END_ACTION;
}

void SoFCSelectionRoot::getBoundingBox(SoGetBoundingBoxAction * action)
{
    if (lock)
    {
        return;
    }
    BEGIN_ACTION;
    if(doActionPrivate(stack,action))
        inherited::getBoundingBox(action);
    END_ACTION;
}

void SoFCSelectionRoot::getMatrix(SoGetMatrixAction * action) {
    BEGIN_ACTION;
    if(doActionPrivate(stack,action))
        inherited::getMatrix(action);
    END_ACTION;
}

void SoFCSelectionRoot::callback(SoCallbackAction *action) {
    BEGIN_ACTION;
    inherited::callback(action);
    END_ACTION;
}

void SoFCSelectionRoot::doAction(SoAction *action) {
    BEGIN_ACTION
    if(doActionPrivate(stack,action))
        inherited::doAction(action);
    END_ACTION
}

bool SoFCSelectionRoot::doActionPrivate(Stack &stack, SoAction *action) {
    // Selection action short-circuit optimization. In case of whole object
    // selection/pre-selection, we shall store a SelContext keyed by ourself.
    // And the action traversal can be short-curcuited once the first targeted
    // SoFCSelectionRoot is found here. New function checkSelection() is exposed
    // to check for whole object selection. This greatly improve performance on
    // large group.

    SelContextPtr ctx2;
    bool ctx2Searched = false;
    bool isTail = false;
    if(action->getCurPathCode()==SoAction::IN_PATH) {
        auto path = action->getPathAppliedTo();
        if(path) {
            isTail = path->getTail()==this ||
                     (path->getLength()>1
                      && path->getNodeFromTail(1)==this
                      && path->getTail()->isOfType(SoSwitch::getClassTypeId()));
        }

        if(!action->isOfType(SoSelectionElementAction::getClassTypeId())) {
            ctx2Searched = true;
            ctx2 = std::static_pointer_cast<SelContext>(getNodeContext2(stack,this,SelContext::merge));
            if(ctx2 && ctx2->hideAll)
                return false;
        }
        if(!isTail)
            return true;
    }else if(action->getWhatAppliedTo()!=SoAction::NODE && action->getCurPathCode()!=SoAction::BELOW_PATH)
        return true;

    if(action->isOfType(SoSelectionElementAction::getClassTypeId())) {
        auto selAction = static_cast<SoSelectionElementAction*>(action);
        if(selAction->isSecondary()) {
            if(selAction->getType() == SoSelectionElementAction::Show ||
               (selAction->getType() == SoSelectionElementAction::Color &&
                selAction->getColors().empty() &&
                action->getWhatAppliedTo()==SoAction::NODE))
            {
                auto ctx = getActionContext(action,this,SelContextPtr(),false);
                if(ctx && ctx->hideAll) {
                    ctx->hideAll = false;
                    if(!ctx->hlAll && !ctx->selAll)
                        removeActionContext(action,this);
                    touch();
                }
                // applied to a node means clear all visibility setting, so
                // return true to propgate the action
                return selAction->getType()==SoSelectionElementAction::Color ||
                       action->getWhatAppliedTo()==SoAction::NODE;

            }else if(selAction->getType() == SoSelectionElementAction::Hide) {
                if(action->getCurPathCode()==SoAction::BELOW_PATH || isTail) {
                    auto ctx = getActionContext(action,this,SelContextPtr());
                    if(ctx && !ctx->hideAll) {
                        ctx->hideAll = true;
                        touch();
                    }
                    return false;
                }
            }
            return true;
        }

        if(selAction->getType() == SoSelectionElementAction::None) {
            if(action->getWhatAppliedTo() == SoAction::NODE) {
                // Here the 'select none' action is applied to a node, and we
                // are the first SoFCSelectionRoot encountered (which means all
                // children stores selection context here, both whole object
                // and element selection), then we can simply perform the
                // action by clearing the selection context here, and save the
                // time for traversing a potentially large amount of children
                // nodes.
                resetContext();
                touch();
                return false;
            }

            auto ctx = getActionContext(action,this,SelContextPtr(),false);
            if(ctx && ctx->selAll) {
                ctx->selAll = false;
                touch();
                return false;
            }
        } else if(selAction->getType() == SoSelectionElementAction::All) {
            auto ctx = getActionContext(action,this,SelContextPtr());
            assert(ctx);
            ctx->selAll = true;
            ctx->selColor = selAction->getColor();
            touch();
            return false;
        }
        return true;
    }

    if(action->isOfType(SoHighlightElementAction::getClassTypeId())) {
        auto hlAction = static_cast<SoHighlightElementAction*>(action);
        if(hlAction->isHighlighted()) {
            if(hlAction->getElement()) {
                auto ctx = getActionContext(action,this,SelContextPtr(),false);
                if(ctx && ctx->hlAll) {
                    ctx->hlAll = false;
                    touch();
                }
            } else {
                auto ctx = getActionContext(action,this,SelContextPtr());
                assert(ctx);
                ctx->hlAll = true;
                ctx->hlColor = hlAction->getColor();
                touch();
                return false;
            }
        } else {
            auto ctx = getActionContext(action,this,SelContextPtr(),false);
            if(ctx && ctx->hlAll) {
                ctx->hlAll = false;
                touch();
                //return false;
            }
        }
        return true;
    }

    if(!ctx2Searched) {
        ctx2 = std::static_pointer_cast<SelContext>(getNodeContext2(stack,this,SelContext::merge));
        if(ctx2 && ctx2->hideAll)
            return false;
    }
    return true;
}

int SoFCSelectionRoot::SelContext::merge(int status, SoFCSelectionContextBasePtr &output,
        SoFCSelectionContextBasePtr input, SoFCSelectionRoot *)
{
    auto ctx = std::dynamic_pointer_cast<SelContext>(input);
    if(ctx && ctx->hideAll) {
        output = ctx;
        return -1;
    }
    return status;
}

/////////////////////////////////////////////////////////////////////////////

SO_NODE_SOURCE(SoFCPathAnnotation)

SoFCPathAnnotation::SoFCPathAnnotation()
{
    SO_NODE_CONSTRUCTOR(SoFCPathAnnotation);
    path = 0;
    tmpPath = 0;
    det = 0;
}

SoFCPathAnnotation::~SoFCPathAnnotation()
{
    if(path) path->unref();
    if(tmpPath) tmpPath->unref();
    delete det;
}

void SoFCPathAnnotation::finish()
{
    atexit_cleanup();
}

void SoFCPathAnnotation::initClass(void)
{
    SO_NODE_INIT_CLASS(SoFCPathAnnotation,SoSeparator,"Separator");
}

void SoFCPathAnnotation::GLRender(SoGLRenderAction * action)
{
    switch (action->getCurPathCode()) {
    case SoAction::NO_PATH:
    case SoAction::BELOW_PATH:
        this->GLRenderBelowPath(action);
        break;
    case SoAction::OFF_PATH:
        break;
    case SoAction::IN_PATH:
        this->GLRenderInPath(action);
        break;
    }
}

void SoFCPathAnnotation::GLRenderBelowPath(SoGLRenderAction * action)
{
    if(!path || !path->getLength() || !tmpPath || !tmpPath->getLength())
        return;

    if(path->getLength() != tmpPath->getLength()) {
        // The auditing SoPath may be truncated due to harmless things such as
        // fliping a SoSwitch sibling node. So we keep an unauditing SoTempPath
        // around to try to restore the path.
        for(int i=path->getLength()-1;i<tmpPath->getLength()-1;++i) {
            auto children = path->getNode(i)->getChildren();
            if(children) {
                int idx = children->find(tmpPath->getNode(i+1));
                if(idx >= 0) {
                    path->append(idx);
                    continue;
                }
            }
            tmpPath->unref();
            tmpPath = 0;
            return;
        }
    }

    SoState * state = action->getState();
    SoGLCacheContextElement::shouldAutoCache(state, SoGLCacheContextElement::DONT_AUTO_CACHE);

    if (action->isRenderingDelayedPaths()) {
        SbBool zbenabled = glIsEnabled(GL_DEPTH_TEST);
        if (zbenabled) glDisable(GL_DEPTH_TEST);

        if(det)
            inherited::GLRenderInPath(action);
        else {
            bool bbox = ViewParams::instance()->getShowSelectionBoundingBox();
            if(!bbox) {
                for(int i=0,count=path->getLength();i<count;++i) {
                    if(!path->getNode(i)->isOfType(SoFCSelectionRoot::getClassTypeId()))
                        continue;
                    auto node = static_cast<SoFCSelectionRoot*>(path->getNode(i));
                    if(node->selectionStyle.getValue()==SoFCSelectionRoot::Box) {
                        bbox = true;
                        break;
                    }
                }
            }
            if(!bbox)
                inherited::GLRenderInPath(action);
            else {
                bool sel = false;
                bool hl = false;
                bool selHl = false;// FreeCAD19_Update
                SbColor selColor,hlColor, selHlColor;// FreeCAD19_Update
                SoFCSelectionRoot::checkSelection(sel,selColor,hl,hlColor, selHl, selHlColor);// FreeCAD19_Update
                if(sel || hl)
                    SoFCSelectionRoot::renderBBox(action,this,hl?hlColor:selColor);
                // FreeCAD19_Update
                else if (selHl)
                {
                    SoFCSelectionRoot::renderBBox(action, this, selHlColor);
                }
                else
                    inherited::GLRenderInPath(action);
            }
        }

        if (zbenabled) glEnable(GL_DEPTH_TEST);

    } else {
        SoCacheElement::invalidate(action->getState());
        auto curPath = action->getCurPath();
        SoPath *newPath = new SoPath(curPath->getLength()+path->getLength());
        newPath->append(curPath);
        newPath->append(path);
        action->addDelayedPath(newPath);
    }
}

void SoFCPathAnnotation::GLRenderInPath(SoGLRenderAction * action)
{
    GLRenderBelowPath(action);
}

void SoFCPathAnnotation::setDetail(SoDetail *d) {
    if(d!=det) {
        delete det;
        det = d;
    }
}

void SoFCPathAnnotation::setPath(SoPath *newPath) {
    if(path) {
        path->unref();
        coinRemoveAllChildren(this);
        path = 0;
        if(tmpPath) {
            tmpPath->unref();
            tmpPath = 0;
        }
    }
    if(!newPath || !newPath->getLength())
        return;

    tmpPath = new SoTempPath(newPath->getLength());
    tmpPath->ref();
    for(int i=0;i<newPath->getLength();++i)
        tmpPath->append(newPath->getNode(i));
    path = newPath->copy();
    path->ref();
    addChild(path->getNode(0));
}

void SoFCPathAnnotation::getBoundingBox(SoGetBoundingBoxAction * action)
{
    if(path) {
        SoGetBoundingBoxAction bboxAction(action->getViewportRegion());
        SoFCSelectionRoot::moveActionStack(action,&bboxAction,false);
        bboxAction.apply(path);
        SoFCSelectionRoot::moveActionStack(&bboxAction,action,true);
        auto bbox = bboxAction.getBoundingBox();
        if(!bbox.isEmpty())
            action->extendBy(bbox);
    }
}