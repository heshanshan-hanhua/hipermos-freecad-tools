﻿ /*===================================================================
 Copyright (c) 2023 HHintech
 Unpublished - All rights reserved

 =====================================================================
 File description:
 OpenCascadeNavigationStyleHH used to view in 3D mode.

 =====================================================================
 Date            Name            Description of Change
 2023/04/27      LJ              Written
 2023/05/07      LL              Fixed bugs of key and mouse click at same time
 2023/05/09      LL              Fixed bug of popmenu while navi event is not finished
 HISTORY
 ====================================================================*/
#include "PreCompiled.h"
#ifndef _PreComp_
# include <cfloat>
# include "InventorAll.h"
# include <QAction>
# include <QActionGroup>
# include <QApplication>
# include <QByteArray>
# include <QCursor>
# include <QList>
# include <QMenu>
# include <QMetaObject>
# include <QRegExp>
#endif

#include <App/Application.h>
#include "NavigationStyle.h"
#include "View3DInventorViewer.h"
#include "Application.h"
#include "MenuManager.h"
#include "MouseSelection.h"

using namespace Gui;

// ----------------------------------------------------------------------------------

/* TRANSLATOR Gui::OpenCascadeNavigationStyleHH */

TYPESYSTEM_SOURCE(Gui::OpenCascadeNavigationStyleHH, Gui::UserNavigationStyleHH)

OpenCascadeNavigationStyleHH::OpenCascadeNavigationStyleHH()
{
}

OpenCascadeNavigationStyleHH::~OpenCascadeNavigationStyleHH()
{
}

const char* OpenCascadeNavigationStyleHH::mouseButtons(ViewerMode mode)
{
    switch (mode) {
    case NavigationStyle::SELECTION:
        return QT_TR_NOOP("Press left mouse button");
    case NavigationStyle::PANNING:
        return QT_TR_NOOP("Press middle mouse button");
    case NavigationStyle::DRAGGING:
        return QT_TR_NOOP("Press Ctrl + right mouse button \n"
            "or middle + right mouse button");
    case NavigationStyle::ZOOMING:
        return QT_TR_NOOP("Scroll middle mouse button");
    default:
        return "No description";
    }
}

void OpenCascadeNavigationStyleHH::rightMouseButtonHandling(const SoEvent* const ev, const SbBool& press, ViewerMode& newmode, SbBool& processed)
{
    const SoMouseButtonEvent* const event = (const SoMouseButtonEvent*)ev;
    // If we are in edit mode then simply ignore the RMB events
// to pass the event to the base class.
    this->lockrecenter = true;
    if (!viewer->isEditing()) {
        // If we are in zoom or pan mode ignore RMB events otherwise
        // the canvas doesn't get any release events
        if (this->currentmode != NavigationStyle::ZOOMING &&
            this->currentmode != NavigationStyle::PANNING &&
            this->currentmode != NavigationStyle::DRAGGING) 
        {
            if (this->isPopupMenuEnabled()) 
            {
                if (!press && !_eventInProcessing)
                { // release right mouse button
                   this->openPopupMenu(event->getPosition());
                }
            }
        }
    }
    // Alternative way of rotating & zooming
    if (press && (this->currentmode == NavigationStyle::PANNING ||
        this->currentmode == NavigationStyle::ZOOMING)) {
        newmode = NavigationStyle::DRAGGING;
        saveCursorPosition(ev);
        this->centerTime = ev->getTime();
        processed = true;
    }
    else if (!press && (this->currentmode == NavigationStyle::DRAGGING)) {
        newmode = NavigationStyle::IDLE;
        processed = true;
    }
    this->button2down = press;
}

void OpenCascadeNavigationStyleHH::leftMouseButtonHandling(const SoEvent* const ev, const SbBool& press, const SbVec2s& pos, ViewerMode& newmode, SbBool& processed)
{
    const SoMouseButtonEvent* const event = (const SoMouseButtonEvent*)ev;
    this->lockrecenter = true;
    this->button1down = press;
    if (press && (this->currentmode == NavigationStyle::SEEK_WAIT_MODE)) {
        newmode = NavigationStyle::SEEK_MODE;
        this->seekToPoint(pos); // implicitly calls interactiveCountInc()
        processed = true;
    }
    else if (!press && (this->currentmode == NavigationStyle::ZOOMING)) {
        newmode = NavigationStyle::IDLE;
        processed = true;
    }
    else if (!press && (this->currentmode == NavigationStyle::DRAGGING)) {
        this->setViewing(false);
        processed = true;
    }
    else if (viewer->isEditing() && (this->currentmode == NavigationStyle::SPINNING)) {
        processed = true;
    }
    // issue #0002433: avoid to swallow the UP event if down the
    // scene graph somewhere a dialog gets opened
    else if (press) {
        SbTime tmp = (ev->getTime() - mouseDownConsumedEvent.getTime());
        float dci = (float)QApplication::doubleClickInterval() / 1000.0f;
        // a double-click?
        if (tmp.getValue() < dci) {
            mouseDownConsumedEvent = *event;
            mouseDownConsumedEvent.setTime(ev->getTime());
            processed = true;
        }
        else {
            mouseDownConsumedEvent.setTime(ev->getTime());
            // 'ANY' is used to mark that we don't know yet if it will
            // be a double-click event.
            mouseDownConsumedEvent.setButton(SoMouseButtonEvent::ANY);
        }
    }
    else if (!press) {
        if (mouseDownConsumedEvent.getButton() == SoMouseButtonEvent::BUTTON1) {
            // now handle the postponed event
            inherited::processSoEvent(&mouseDownConsumedEvent);
            mouseDownConsumedEvent.setButton(SoMouseButtonEvent::ANY);
        }
    }
}

void OpenCascadeNavigationStyleHH::middleMouseButtonHandling(const SoEvent* const ev, const SbBool& press, const SbVec2s& pos, const SbVec2f& posn, ViewerMode& newmode, SbBool& processed)
{
    const SbViewportRegion& vp = viewer->getSoRenderManager()->getViewportRegion();
    if (press) {
        this->centerTime = ev->getTime();
        float ratio = vp.getViewportAspectRatio();
        SbViewVolume vv = viewer->getSoRenderManager()->getCamera()->getViewVolume(ratio);
        this->panningplane = vv.getPlane(viewer->getSoRenderManager()->getCamera()->focalDistance.getValue());
        this->lockrecenter = false;
    }
    //else if (this->currentmode == NavigationStyle::PANNING) {
    //    newmode = NavigationStyle::IDLE;
    //    processed = true;
    //}
    this->button3down = press;

}

void OpenCascadeNavigationStyleHH::buttonComboHandling(const SoEvent* const ev, const ViewerMode& curmode, ButtonActionCombo combo, ViewerMode& newmode, SbBool& processed)
{
    unsigned int refactorCombo = (combo & BUTTON1DOWN ? BUTTON1DOWN : 0) |
        (combo & BUTTON2DOWN ? BUTTON2DOWN : 0) |
        (combo & BUTTON3DOWN ? BUTTON3DOWN : 0) |
        (combo & CTRLDOWN ? CTRLDOWN : 0)
        ;
    if (!(combo & BUTTON1DOWN || combo & BUTTON2DOWN || combo & BUTTON3DOWN) )
    {
        _eventInProcessing = false;
    }

    switch (refactorCombo) {
    case 0:
        if (curmode == NavigationStyle::SPINNING) { break; }
        newmode = NavigationStyle::IDLE;
        break;
    case CTRLDOWN | BUTTON1DOWN:
    case BUTTON1DOWN:
        if (newmode != NavigationStyle::ZOOMING)
            newmode = NavigationStyle::SELECTION;
        break;
    case BUTTON3DOWN:
        newmode = NavigationStyle::PANNING;
        break;
    case BUTTON3DOWN | BUTTON1DOWN:
        newmode = NavigationStyle::IDLE;
        break;
    case BUTTON3DOWN | BUTTON2DOWN:
    case CTRLDOWN | BUTTON2DOWN:
    {
        newmode = NavigationStyle::DRAGGING;
        _eventInProcessing = true;
    }
        break;
    case BUTTON2DOWN:
        newmode = NavigationStyle::IDLE;
        break;
    default:
        newmode = IDLE;
        break;
    }
}