﻿/***************************************************************************
 *   Copyright (c) 2007 Werner Mayer <wmayer[at]users.sourceforge.net>     *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/
 /*===================================================================
 Copyright (c) 2021 HHintech
 Unpublished - All rights reserved

 =====================================================================
 File description:

 =====================================================================
 Date            Name            Description of Change
 2018/05/01      Liulei          Active signalCloseMDIView while close the MDI
 2018/07/03      MZG             Check dlg status when close MDI
 2019/03/06      WS              allow show & in title
 2018/08/31      MZG             Use Logger
 2021/08/17      LL              Upgrade
 2021/08/22      LL              Upgrade
 2021/09/01      ZJF             Set HiperMOS style
 2021/09/29      JHQ             fix dock undock bug
 2022/01/13      HX              change "HiPeRMOS" to "HiperMOS"
 2022/05/30      LL              Add punctuation for some tips
 2022/05/18      HSS             modify canClose for review close bug
 2022/09/12      Liulei          Fixed bug of dock/undock edited viewer
 2024/01/12      Liulei          Check can change view before set active view

 HISTORY
 ====================================================================*/

#include "PreCompiled.h"

#ifndef _PreComp_
# include <boost_signals2.hpp>
# include <boost_bind_bind.hpp>
# include <qapplication.h>
# include <qregexp.h>
# include <QEvent>
# include <QCloseEvent>
# include <QMdiSubWindow>
#include <iostream>
#endif


#include "MDIView.h"
#include "MDIViewPy.h"
#include "Command.h"
#include "Document.h"
#include "Application.h"
#include "MainWindow.h"
#include "ViewProviderDocumentObject.h"

#include "Control.h"
#include "StackControlBaseHH.h"
#include <Base/LoggerHH.h>

using namespace Gui;
namespace bp = boost::placeholders;

TYPESYSTEM_SOURCE_ABSTRACT(Gui::MDIView,Gui::BaseView)


MDIView::MDIView(Gui::Document* pcDocument,QWidget* parent, Qt::WindowFlags wflags)
  : QMainWindow(parent, wflags)
  , BaseView(pcDocument)
  , pythonObject(nullptr)
  , currentMode(Child)
  , wstate(Qt::WindowNoState)
  , ActiveObjects(pcDocument)
{
    setAttribute(Qt::WA_DeleteOnClose);

    if (pcDocument)
    {
      connectDelObject = pcDocument->signalDeletedObject.connect
        (boost::bind(&ActiveObjectList::objectDeleted, &ActiveObjects, bp::_1));
      assert(connectDelObject.connected());
    }
}

MDIView::~MDIView()
{
    //This view might be the focus widget of the main window. In this case we must
    //clear the focus and e.g. set the focus directly to the main window, otherwise
    //the application crashes when accessing this deleted view.
    //This effect only occurs if this widget is not in Child mode, because otherwise
    //the focus stuff is done correctly.
    if (getMainWindow()) {
        QWidget* foc = getMainWindow()->focusWidget();
        if (foc) {
            QWidget* par = foc;
            while (par) {
                if (par == this) {
                    getMainWindow()->setFocus();
                    break;
                }
                par = par->parentWidget();
            }
        }
    }
    if (connectDelObject.connected())
      connectDelObject.disconnect();

    if (pythonObject) {
        Base::PyGILStateLocker lock;
        Py_DECREF(pythonObject);
        pythonObject = nullptr;
    }
}

void MDIView::deleteSelf()
{
    // When using QMdiArea make sure to remove the QMdiSubWindow
    // this view is associated with.
    //
    // #0001023: Crash when quitting after using Windows > Tile
    // Use deleteLater() instead of delete operator.
    QWidget* parent = this->parentWidget();
    if (qobject_cast<QMdiSubWindow*>(parent)) {
        // https://forum.freecadweb.org/viewtopic.php?f=22&t=23070
#if QT_VERSION < 0x050000
        // With Qt5 this would lead to some annoying flickering
        getMainWindow()->removeWindow(this);
#endif
        parent->close();
    }
    else {
        this->close();
    }

    // detach from document
    if (_pcDocument)
        onClose();
    _pcDocument = 0;
}

PyObject* MDIView::getPyObject()
{
    if (!pythonObject)
        pythonObject = new MDIViewPy(this);

    Py_INCREF(pythonObject);
    return pythonObject;
}

void MDIView::setOverrideCursor(const QCursor& c)
{
    Q_UNUSED(c);
}

void  MDIView::restoreOverrideCursor()
{
}

void MDIView::onRelabel(Gui::Document *pDoc)
{
    if (!bIsPassive) {
        // Try to separate document name and view number if there is one
        QString cap = windowTitle();
        // Either with dirty flag ...
        QRegExp rx(QLatin1String("(\\s\\:\\s\\d+\\[\\*\\])$"));
        int pos = rx.lastIndexIn(cap);
        if (pos == -1) {
            // ... or not
            rx.setPattern(QLatin1String("(\\s\\:\\s\\d+)$"));
            pos = rx.lastIndexIn(cap);
        }
        if (pos != -1) {
            cap = QString::fromUtf8(pDoc->getDocument()->Label.getValue());
            cap += rx.cap();
            //FreeCAD19_update
            cap = cap.replace(QString::fromUtf8("&"), QString::fromUtf8("&&"));
            //end
            setWindowTitle(cap);
        }
        else {
            cap = QString::fromUtf8(pDoc->getDocument()->Label.getValue());
            cap = QString::fromLatin1("%1[*]").arg(cap);
            //FreeCAD19_update
            cap = cap.replace(QString::fromUtf8("&"), QString::fromUtf8("&&"));
            //end
            setWindowTitle(cap);
        }
    }
}

void MDIView::viewAll()
{
}

/// receive a message
bool MDIView::onMsg(const char* pMsg,const char** ppReturn)
{
    Q_UNUSED(pMsg);
    Q_UNUSED(ppReturn);
    return false;
}

bool MDIView::onHasMsg(const char* pMsg) const
{
    Q_UNUSED(pMsg);
    return false;
}

bool MDIView::canClose(void)
{
    QVariant isInvalid = property("Invalid");
    if (isInvalid.type()== QVariant::Bool &&isInvalid.toBool())
    {
        return true;
    }
    if (getGuiDocument())
    {
        bool canCloseFlag = getGuiDocument()->canClose(true, true);
        if (!canCloseFlag)
        {
            return false;
        }
    }

    if (!bIsPassive && getGuiDocument() && getGuiDocument()->isLastView())
    {
        this->setFocus(); // raises the view to front
    }

    return true;
}

void MDIView::closeEvent(QCloseEvent *e)
{
    //FreeCAD19_update
    if(Gui::Control().activeDialog() != NULL ||
        !Gui::StackControlBase().CanCloseDoc())
    {
        QMessageBox::warning(getMainWindow(), QObject::tr("HiperMOS"), QObject::tr("The active dialog must be closed before the document can be closed!"));
        e->ignore();
        return;
    }
    //end

    if (canClose()) {
        e->accept();
        if (!bIsPassive) {
            // must be detached so that the last view can get asked
            Document* doc = this->getGuiDocument();
            //FreeCAD19_update
            App::GetApplication().signalCloseMDIView();

            if (doc && !doc->isLastView())
                doc->detachView(this);
        }

        // Note: When using QMdiArea we must not use removeWindow()
        // because otherwise the QMdiSubWindow will lose its parent
        // and thus the notification in QMdiSubWindow::closeEvent of
        // other mdi windows to get maximized if this window
        // is maximized will fail.
        // This odd behaviour is caused by the invocation of
        // d->mdiArea->removeSubWindow(parent) which we must let there
        // because otherwise other parts don't work as they should.
        QMainWindow::closeEvent(e);
    }
    else
        e->ignore();
}

void MDIView::windowStateChanged( MDIView* )
{
}

void MDIView::print(QPrinter* printer)
{
    Q_UNUSED(printer);
    LOG_ERROR << "Printing not implemented for " << this->metaObject()->className() << std::endl;
}

void MDIView::print()
{
    LOG_ERROR << "Printing not implemented for " << this->metaObject()->className() << std::endl;
}

void MDIView::printPdf()
{
    LOG_ERROR << "Printing PDF not implemented for " << this->metaObject()->className() << std::endl;
}

void MDIView::printPreview()
{
    LOG_ERROR << "Printing preview not implemented for " << this->metaObject()->className() << std::endl;
}

QSize MDIView::minimumSizeHint () const
{
    return QSize(400, 300);
}

void MDIView::changeEvent(QEvent *e)
{
    switch (e->type()) {
        case QEvent::ActivationChange:
            {
                // Forces this top-level window to be the active view of the main window
                if (isActiveWindow()) 
                {
                    MDIView* actV = getMainWindow()->activeWindow();
                    if (getMainWindow()->CanChangeView(false))
                    {
                        if (actV != this)
                            getMainWindow()->setActiveWindow(this);
                    }
                    else
                    {
                        if (actV)
                        {
                            actV->setFocus();
                        }
                    }
                }
            }   break;
        case QEvent::WindowTitleChange:
        case QEvent::ModifiedChange:
            {
                // sets the appropriate tab of the tabbar
                getMainWindow()->tabChanged(this);
            }   break;
        default:
            {
                QMainWindow::changeEvent(e);
            }   break;
    }
}

#if defined(Q_WS_X11)
// To fix bug #0000345 move function declaration to here
extern void qt_x11_wait_for_window_manager( QWidget* w ); // defined in qwidget_x11.cpp
#endif

void MDIView::setCurrentViewMode(ViewMode mode)
{
    QWidget* parent = this->parentWidget();
    switch (mode) {
        // go to normal mode
        case Child:
            {
                if (this->currentMode == FullScreen) {
                    showNormal();
                    setWindowFlags(windowFlags() & ~Qt::Window);
                }
                else if (this->currentMode == TopLevel) {
                    this->wstate = windowState();
                    setWindowFlags( windowFlags() & ~Qt::Window );
                }

                if (this->currentMode != Child) {
                    this->currentMode = Child;
                    getMainWindow()->addWindow(this);
                    getMainWindow()->activateWindow();
                    update();
                }
            }   break;
        // go to top-level mode
        case TopLevel:
            {
                if (this->currentMode == Child) {
                    if (qobject_cast<QMdiSubWindow*>(this->parentWidget()))
                        getMainWindow()->removeWindow(this,false);
                    //setWindowFlags(windowFlags() | Qt::Window);
                    //setParent(0, Qt::Window | Qt::WindowTitleHint | Qt::WindowSystemMenuHint |
                    //    Qt::WindowMinMaxButtonsHint);
                    if (parent)
                    {
                        parent->setWindowFlags(windowFlags() | Qt::Window | Qt::WindowTitleHint |
                            Qt::WindowSystemMenuHint |Qt::WindowMinMaxButtonsHint);
                    }
                    if (this->wstate & Qt::WindowMaximized)
                        showMaximized();
                    else
                        showNormal();

#if defined(Q_WS_X11)
                    //extern void qt_x11_wait_for_window_manager( QWidget* w ); // defined in qwidget_x11.cpp
                    qt_x11_wait_for_window_manager(this);
#endif
                    activateWindow();
                }
                else if (this->currentMode == FullScreen) {
                    if (this->wstate & Qt::WindowMaximized)
                        showMaximized();
                    else
                        showNormal();
                }

                this->currentMode = TopLevel;
                update();
            }   break;
        // go to fullscreen mode
        case FullScreen:
            {
                if (this->currentMode == Child) {
                    if (qobject_cast<QMdiSubWindow*>(this->parentWidget()))
                        getMainWindow()->removeWindow(this,false);

                    //setWindowFlags(windowFlags() | Qt::Window);
                    //setParent(0, Qt::Window);

                    if (parent)
                    {
                        parent->setWindowFlags(windowFlags() | Qt::Window);
                    }
                    showFullScreen();
                }
                else if (this->currentMode == TopLevel) {
                    this->wstate = windowState();
                    showFullScreen();
                }

                this->currentMode = FullScreen;
                update();
            }   break;
    }
}

#include "moc_MDIView.cpp"
