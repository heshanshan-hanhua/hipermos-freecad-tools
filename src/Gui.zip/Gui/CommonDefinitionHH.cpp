﻿/*===================================================================
 Copyright (c) 2021 HHintech
 Unpublished - All rights reserved

=====================================================================
 File description: 

=====================================================================
 Date           Name            Description of Change
 2021/08/17     Liulei         add some general definition

 HISTORY
====================================================================*/
#include "PreCompiled.h"
#include "CommonDefinitionHH.h"


using namespace Gui;

