﻿/***************************************************************************
 *   Copyright (c) 2002 Jürgen Riegel <juergen.riegel@web.de>              *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/

 /*=====================================================================
 Date              Name            Description of Change
 2018/04/08        MZG                  Support SelectionColor, HighlightColor
 2018/04/16        MZG                  Change status for button in edit mode
 2018/12/28        LL                   Add resetSettings
 2019/01/21        LL                   show backlight check box
 2021/06/10        JHQ                   hide unuse control in option interface
 2021/08/17        LL                   Upgrade
 2021/06/10        JHQ                  save preference bug when no document opened
 2021/09/11        LL                   remove opengl
 2021/09/19        LL                   remove some item
 2021/09/22        LL                   fixed bug of set color
 2021/09/22        LL                   support selection type
 2021/09/30        LL                   set backlightcolor as true by default
 
 HISTORY
 ====================================================================*/


#include "PreCompiled.h"

#ifndef _PreComp_
# include <QApplication>
# include <QDoubleSpinBox>
# include <QRegExp>
# include <QGridLayout>
# include <QMessageBox>
# include <memory>
#endif

#include "DlgSettings3DViewImp.h"
#include "ui_DlgSettings3DView.h"
#include "MainWindow.h"
#include "NavigationStyle.h"
#include "PrefWidgets.h"
#include "View3DInventor.h"
#include "View3DInventorViewer.h"
#include "ui_MouseButtons.h"
#include <App/Application.h>
#include <Base/Console.h>
#include <Base/Parameter.h>
#include <Base/Tools.h>

namespace
{
    //FreeCAD19_update
    QColor GetColor(QFrame* frame)
    {
        if(frame == NULL)
            return QColor();

        return frame->palette().color(QPalette::Background);
    }

    void SetColor(QFrame* frame, QColor color)
    {
        if(frame == NULL)
            return;

        QPalette pal = frame->palette();
        pal.setColor(QPalette::Background, color);
        frame->setAutoFillBackground(true);
        frame->setPalette(pal);
    }

    unsigned long ColorToInt(QColor col)
    {
        unsigned long res = (static_cast<unsigned long> (col.red()) << 24)
            | (static_cast<unsigned long> (col.green()) << 16)
            | (static_cast<unsigned long> (col.blue()) << 8) | 255;

        return res;
    }

    QColor IntToColor(unsigned int col)
    {
        int r = (col >> 24) & 0xff;
        int g = (col >> 16) & 0xff;
        int b = (col >> 8) & 0xff;

        return QColor(r, g, b);
    }

    void SelectColor(QWidget* parent, QFrame* frame)
    {
        if(parent == NULL || frame == NULL)
            return;

        QColorDialog dlg(parent);
        dlg.setOptions(QColorDialog::DontUseNativeDialog);
        dlg.setCurrentColor(GetColor(frame));
        dlg.adjustSize();
        if(dlg.exec() == QDialog::Accepted)
        {
            QColor newColor = dlg.selectedColor();
            //QColor newColor = QColorDialog::getColor(GetColor(frame), parent,QString(),QColorDialog::ColorDialogOption::ShowAlphaChannel);

            if(newColor.isValid())
            {
                SetColor(frame, newColor);
            }
        }
    }
}

using namespace Gui::Dialog;

/* TRANSLATOR Gui::Dialog::DlgSettings3DViewImp */

bool DlgSettings3DViewImp::showMsg = true;

/**
 *  Constructs a DlgSettings3DViewImp which is a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'
 */
DlgSettings3DViewImp::DlgSettings3DViewImp(QWidget* parent)
    : PreferencePage( parent )
    , ui(new Ui_DlgSettings3DView)
{
    ui->setupUi(this);


    ui->CheckBox_ShowAxisCross->setVisible(false);
    ui->CheckBox_ShowFPS->setVisible(false);
    ui->CheckBox_WbByTab->setVisible(false);

    ui->groupBoxCamera->setVisible(false);

    ui->CheckBox_use_SW_OpenGL->hide();
    ui->CheckBox_useVBO->hide();

    ui->renderCacheLabel->hide();
    ui->renderCache->hide();

    ui->transparentRenderLabel->hide();
    ui->comboTransparentRender->hide();
    ui->markerSizeLabel->hide();
    ui->boxMarkerSize->hide();
    ui->FloatSpinBox_EyeDistance->hide();
    ui->textLabel1->hide();
    ui->checkBoxBacklight->hide();
    ui->backlightColor->hide();
    ui->backlightLabel->hide();
    ui->sliderIntensity->hide();

}

/**
 *  Destroys the object and frees any allocated resources
 */
DlgSettings3DViewImp::~DlgSettings3DViewImp()
{
    // no need to delete child widgets, Qt does it all for us
}

void DlgSettings3DViewImp::saveSettings()
{
    // must be done as very first because we create a new instance of NavigatorStyle
    // where we set some attributes afterwards
    ParameterGrp::handle hGrp = App::GetApplication().GetParameterGroupByPath
        ("User parameter:BaseApp/Preferences/View");

    int index = ui->comboAliasing->currentIndex();
    hGrp->SetInt("AntiAliasing", index);

    index = ui->renderCache->currentIndex();
    hGrp->SetInt("RenderCache", index);

    index = this->ui->unfocusedObjStatus->currentIndex();
    hGrp->SetInt("UnfocusedObjStatus", index);

    ui->comboTransparentRender->onSave();

    QVariant const &vBoxMarkerSize = ui->boxMarkerSize->itemData(ui->boxMarkerSize->currentIndex());
    hGrp->SetInt("MarkerSize", vBoxMarkerSize.toInt());

    ui->CheckBox_CornerCoordSystem->onSave();
    ui->CheckBox_ShowAxisCross->onSave();
    ui->CheckBox_WbByTab->onSave();
    ui->CheckBox_ShowFPS->onSave();
    ui->spinPickRadius->onSave();
    ui->CheckBox_use_SW_OpenGL->onSave();
    ui->CheckBox_useVBO->onSave();
    ui->FloatSpinBox_EyeDistance->onSave();
    ui->checkBoxBacklight->onSave();
    ui->backlightColor->onSave();
    ui->sliderIntensity->onSave();
    ui->radioPerspective->onSave();
    ui->radioOrthographic->onSave();

    hGrp->SetUnsigned("SelectionColor", ColorToInt(GetColor(this->ui->selObjColor)));
    hGrp->SetUnsigned("HighlightedObjColor", ColorToInt(GetColor(this->ui->highlightedObjColor)));
    hGrp->SetUnsigned("WrongStatusObjColor", ColorToInt(GetColor(this->ui->wrongStatusObjColor)));

    //reselect to update
    std::vector<Gui::SelectionSingleton::SelObj> selectedObj = Gui::Selection().getSelection();
    Gui::Selection().clearSelection(0,true,Gui::SelectionChanges::SelType_ViewUpdate);
    std::vector<App::DocumentObject*> objs;
    for(auto& item : selectedObj)
    {
        //Gui::Selection().addSelection(item.DocName,item.FeatName,item.SubName, Gui::SelectionChanges::SelType_ViewUpdate);
        objs.push_back(item.pObject);
    }

    if (App::GetApplication().getActiveDocument())
    {
        Gui::Selection().setSelection(App::GetApplication().getActiveDocument()->getName(), objs, Gui::SelectionChanges::SelType_ViewUpdate);
    }
}

void DlgSettings3DViewImp::loadSettings()
{
    ui->CheckBox_CornerCoordSystem->onRestore();
    ui->CheckBox_ShowAxisCross->onRestore();
    ui->CheckBox_WbByTab->onRestore();
    ui->CheckBox_ShowFPS->onRestore();
    ui->spinPickRadius->onRestore();
    ui->CheckBox_use_SW_OpenGL->onRestore();
    ui->CheckBox_useVBO->onRestore();
    ui->FloatSpinBox_EyeDistance->onRestore();
    ui->checkBoxBacklight->onRestore();
    ui->backlightColor->onRestore();
    ui->sliderIntensity->onRestore();
    ui->radioPerspective->onRestore();
    ui->radioOrthographic->onRestore();

    ParameterGrp::handle hGrp = App::GetApplication().GetParameterGroupByPath
        ("User parameter:BaseApp/Preferences/View");

    int index = hGrp->GetInt("AntiAliasing", int(Gui::View3DInventorViewer::None));
    index = Base::clamp(index, 0, ui->comboAliasing->count()-1);
    ui->comboAliasing->setCurrentIndex(index);
    // connect after setting current item of the combo box
    connect(ui->comboAliasing, SIGNAL(currentIndexChanged(int)),
            this, SLOT(onAliasingChanged(int)));

    index = hGrp->GetInt("RenderCache", 0);
    ui->renderCache->setCurrentIndex(index);

    ui->comboTransparentRender->onRestore();

    int const current = hGrp->GetInt("MarkerSize", 9L);
    ui->boxMarkerSize->addItem(tr("5px"), QVariant(5));
    ui->boxMarkerSize->addItem(tr("7px"), QVariant(7));
    ui->boxMarkerSize->addItem(tr("9px"), QVariant(9));
    ui->boxMarkerSize->addItem(tr("11px"), QVariant(11));
    ui->boxMarkerSize->addItem(tr("13px"), QVariant(13));
    ui->boxMarkerSize->addItem(tr("15px"), QVariant(15));
    index = ui->boxMarkerSize->findData(QVariant(current));
    if (index < 0) index = 2;
    ui->boxMarkerSize->setCurrentIndex(index);

    index = hGrp->GetInt("UnfocusedObjStatus", 0);
    index = Base::clamp(index, 0, ui->unfocusedObjStatus->count() - 1);
    ui->unfocusedObjStatus->setCurrentIndex(index);

    unsigned int selColor = hGrp->GetUnsigned("SelectionColor", ColorToInt(QColor(0, 200, 255)));
    unsigned int highlightColor = hGrp->GetUnsigned("HighlightedObjColor", ColorToInt(QColor(255, 155, 55)));
    unsigned int wrongStatusColor = hGrp->GetUnsigned("WrongStatusObjColor", ColorToInt(QColor(255, 0, 0)));

    SetColor(this->ui->selObjColor, IntToColor(selColor));
    SetColor(this->ui->highlightedObjColor, IntToColor(highlightColor));
    SetColor(this->ui->wrongStatusObjColor, IntToColor(wrongStatusColor));

    connect(this->ui->selObjColorButton, SIGNAL(clicked()), this, SLOT(onChangeSelColor()));
    connect(this->ui->highlightedObjColorButton, SIGNAL(clicked()), this, SLOT(onChangeHighlightColor()));
    connect(this->ui->wrongStatusObjColorButton, SIGNAL(clicked()), this, SLOT(onChangeWrongStatusColor()));
}

/**
 * Sets the strings of the subwidgets using the current language.
 */
void DlgSettings3DViewImp::changeEvent(QEvent *e)
{
    if (e->type() == QEvent::LanguageChange) {
        ui->comboAliasing->blockSignals(true);
        int aliasing = ui->comboAliasing->currentIndex();
        ui->retranslateUi(this);
        ui->comboAliasing->setCurrentIndex(aliasing);
        ui->comboAliasing->blockSignals(false);

        int unfocusedStatus = this->ui->unfocusedObjStatus->currentIndex();
        ui->unfocusedObjStatus->setCurrentIndex(unfocusedStatus);

    }
    else {
        QWidget::changeEvent(e);
    }
}

void DlgSettings3DViewImp::onAliasingChanged(int index)
{
    if (index < 0 || !isVisible())
        return;
    // Show this message only once per application session to reduce
    // annoyance when showing it too often.
    if (showMsg) {
        showMsg = false;
        QMessageBox::information(this, tr("Anti-aliasing"),
            tr("Open a new viewer or restart %1 to apply anti-aliasing changes.").arg(qApp->applicationName()));
    }
}
//FreeCAD19_update
void DlgSettings3DViewImp::onChangeSelColor()
{
    this->ui->selObjColorButton->setDisabled(true);
    SelectColor(this, this->ui->selObjColor);
    this->ui->selObjColorButton->setDisabled(false);
}

void DlgSettings3DViewImp::onChangeHighlightColor()
{
    this->ui->highlightedObjColorButton->setDisabled(true);
    SelectColor(this, this->ui->highlightedObjColor);
    this->ui->highlightedObjColorButton->setDisabled(false);
}

void DlgSettings3DViewImp::onChangeWrongStatusColor()
{
    this->ui->wrongStatusObjColorButton->setDisabled(true);
    SelectColor(this, this->ui->wrongStatusObjColor);
    this->ui->wrongStatusObjColorButton->setDisabled(false);
}

void Gui::Dialog::DlgSettings3DViewImp::resetSettings()
{
    ui->CheckBox_CornerCoordSystem->setChecked(true);
    ui->CheckBox_ShowAxisCross->setChecked(false);
    ui->CheckBox_WbByTab->setChecked(false);
    ui->CheckBox_ShowFPS->setChecked(false);
    ui->spinPickRadius->setValue(5.0);
    ui->CheckBox_use_SW_OpenGL->setChecked(false);
    ui->CheckBox_useVBO->setChecked(false);
    ui->FloatSpinBox_EyeDistance->setValue(5.0);
    ui->checkBoxBacklight->setChecked(true);
    ui->backlightColor->setColor(QColor(255, 255, 255));
    ui->sliderIntensity->setValue(100);
    ui->radioPerspective->setChecked(false);
    ui->radioOrthographic->setChecked(true);

    int index = 0;
    index = Base::clamp(index, 0, ui->comboAliasing->count() - 1);
    ui->comboAliasing->setCurrentIndex(index);

    index = 0;
    index = Base::clamp(index, 0, ui->unfocusedObjStatus->count() - 1);
    ui->unfocusedObjStatus->setCurrentIndex(index);

    unsigned int selColor = ColorToInt(QColor(0, 200, 255));
    unsigned int highlightColor = ColorToInt(QColor(255, 155, 55));
    unsigned int wrongStatusColor = ColorToInt(QColor(255, 0, 0));

    SetColor(this->ui->selObjColor, IntToColor(selColor));
    SetColor(this->ui->highlightedObjColor, IntToColor(highlightColor));
    SetColor(this->ui->wrongStatusObjColor, IntToColor(wrongStatusColor));
}
#include "moc_DlgSettings3DViewImp.cpp"

