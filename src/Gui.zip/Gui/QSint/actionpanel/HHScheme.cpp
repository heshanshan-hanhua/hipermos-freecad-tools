﻿/*===================================================================
Copyright (c) 2021 HHintech
Unpublished - All rights reserved

=====================================================================
File description:

========================================================================
Date              Name                 Description of Change
2018/05/09        MZG                  Change style
2018/10/30        MZG                  Change style
2018/10/31        MZG                  Lighter head color
2021/08/17        LL                   Upgrade
2023/06/13        WS                   change fold steps
==========================================================================*/


#include "HHScheme.h"
#include "macpanelscheme.h"
#include "winxppanelscheme.h"
#include "winvistapanelscheme.h"
#include <QApplication>
#include <QImage>
#include <QPainter>
#include <QPalette>


namespace QSint
{


const char* ActionPanelHH =

    //"QFrame[class='panel'] {"
    //    "background-color:qlineargradient(x1:1, y1:0.3, x2:1, y2:0, stop:0 rgb(51,51,101), stop:1 rgb(171,171,193));"
    //"}"

    "QSint--ActionGroup QFrame[class='header'] {"
        "border: 1px solid #ffffff;"
        "border-top-left-radius: 4px;"
        "border-top-right-radius: 4px;"
        "background-color: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 0, stop: 0 #ffffff, stop: 1 #c6d3f7);"
    "}"

    "QSint--ActionGroup QToolButton[class='header'] {"
        "text-align: left;"
        "color: #215dc6;"
        "background-color: transparent;"
        "border: 1px solid transparent;"
        "font-weight: bold;"
    "}"

    "QSint--ActionGroup QToolButton[class='header']:hover {"
        "color: #428eff;"
    "}"

    "QSint--ActionGroup QFrame[class='content'] {"
        "background-color: #d6dff7;"
        "border: 1px solid #ffffff;"
    "}"

    "QSint--ActionGroup QFrame[class='content'][header='true'] {"
        "border-top: none;"
    "}"

    "QSint--ActionGroup QToolButton[class='action'] {"
        "background-color: transparent;"
        "border: 1px solid transparent;"
        "color: #215dc6;"
        "text-align: left;"
    "}"

    "QSint--ActionGroup QToolButton[class='action']:!enabled {"
        "color: #999999;"
    "}"

    "QSint--ActionGroup QToolButton[class='action']:hover {"
        "color: #428eff;"
        "text-decoration: underline;"
    "}"

    "QSint--ActionGroup QToolButton[class='action']:focus {"
        "border: 1px dotted black;"
    "}"

    "QSint--ActionGroup QToolButton[class='action']:on {"
        "background-color: #ddeeff;"
        "color: #006600;"
    "}"
    ;

const char* MinimumActionPanelHH =

    "QSint--ActionGroup QToolButton[class='header'] {"
        "text-align: left;"
        "background-color: transparent;"
        "border: 1px solid transparent;"
        "font-weight: bold;"
    "}"

    "QSint--ActionGroup QToolButton[class='action'] {"
        "background-color: transparent;"
        "border: 1px solid transparent;"
        "text-align: left;"
    "}"

    "QSint--ActionGroup QToolButton[class='action']:hover {"
        "text-decoration: underline;"
    "}"
    ;

// -----------------------------------------------------

HHPanelScheme::HHPanelScheme()
{
    headerSize = 25;
    headerAnimation = true;

    QPalette p = QApplication::palette();
    QPalette p2 = p;
    p2.setColor(QPalette::Highlight,p2.color(QPalette::Highlight).lighter());

    headerButtonFold = drawFoldIcon(p, true);
    headerButtonFoldOver = drawFoldIcon(p2, true);
    headerButtonUnfold = drawFoldIcon(p, false);
    headerButtonUnfoldOver = drawFoldIcon(p2, false);
    headerButtonSize = QSize(17,17);

    groupFoldSteps = 2;
    groupFoldDelay = 15;
    groupFoldEffect = NoFolding;
    groupFoldThaw = true;

    actionStyle = systemStyle(QApplication::palette());

    builtinScheme = actionStyle;
    minimumStyle = QString(MinimumActionPanelHH);
    builtinFold = headerButtonFold;
    builtinFoldOver = headerButtonFoldOver;
    builtinUnfold = headerButtonUnfold;
    builtinUnfoldOver = headerButtonUnfoldOver;
}

/*!
  \code
    QPalette p = QApplication::palette();
    QPalette p2 = p;
    p2.setColor(QPalette::Highlight,p2.color(QPalette::Highlight).lighter());
    headerButtonFold = drawFoldIcon(p, true);
    headerButtonFoldOver = drawFoldIcon(p2, true);
    headerButtonUnfold = drawFoldIcon(p, false);
    headerButtonUnfoldOver = drawFoldIcon(p2, false);
  \endcode
 */
QPixmap HHPanelScheme::drawFoldIcon(const QPalette& p, bool fold) const
{
    QImage img(17,17,QImage::Format_ARGB32_Premultiplied);
    img.fill(0x00000000);
    QPainter painter;
    painter.begin(&img);
    painter.setRenderHint(QPainter::Antialiasing, true);
    painter.setBrush(p.window());
    painter.drawEllipse(1,1,14,14);
    painter.setPen(p.color(QPalette::Base));
    painter.drawEllipse(1,1,14,14);
    QPen pen(QColor(0, 0, 0));
    pen.setWidth(2);
    painter.setPen(pen);
    painter.drawLine(QLine(5,7,8,4));
    painter.drawLine(QLine(8,4,11,7));
    painter.drawLine(QLine(5,11,8,8));
    painter.drawLine(QLine(8,8,11,11));
    painter.end();

    if (!fold) {
        QTransform mat;
        mat.rotate(180.0);
        img = img.transformed(mat);
    }
    return QPixmap::fromImage(img);
}

QString HHPanelScheme::systemStyle(const QPalette& p) const
{
  QColor panelBackground1 = p.color(QPalette::Dark);
  QColor panelBackground2 = p.color(QPalette::Midlight);

  QColor headerBackground1 = QColor(60,60,60);
  QColor headerBackground2 = headerBackground1.lighter(200);

  QColor headerLabelText = p.color(QPalette::HighlightedText);
  QColor headerLabelTextOver = p.color(QPalette::BrightText);

  QColor groupBackground = p.window().color();
  QColor groupBorder = p.color(QPalette::Window);

  QColor taskLabelText = p.color(QPalette::Text);
  QColor taskLabelTextOver = QColor(60, 60, 60);

  QString style = QString::fromLatin1(
    "QFrame[class='panel'] {"
        "background-color:qlineargradient(x1:1, y1:0.3, x2:1, y2:0, stop:0 %1, stop:1 %2);"
    "}"

    "QSint--ActionGroup QFrame[class='header'] {"
        "border: 1px solid #ffffff;"                                // todo
        "border-top-left-radius: 4px;"
        "border-top-right-radius: 4px;"
        "background-color: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 0, stop: 0 %3, stop: 1 %4);"
    "}"

    "QSint--ActionGroup QToolButton[class='header'] {"
        "text-align: left;"
        "color: %5;"
        "background-color: transparent;"
        "border: 1px solid transparent;"
        "font-weight: bold;"
    "}"

    "QSint--ActionGroup QToolButton[class='header']:hover {"
        "color: %6;"
    "}"

    "QSint--ActionGroup QFrame[class='content'] {"
        "background-color: %7;"
        "border: 1px solid %8;"
    "}"

    "QSint--ActionGroup QFrame[class='content'][header='true'] {"
        "border-top: none;"
    "}"

    "QSint--ActionGroup QToolButton[class='action'] {"
        "background-color: transparent;"
        "border: 1px solid transparent;"
        "color: %9;"
        "text-align: left;"
    "}"

    "QSint--ActionGroup QToolButton[class='action']:!enabled {"
        "color: #999999;"                                           // todo
    "}"

    "QSint--ActionGroup QToolButton[class='action']:hover {"
        "color: %10;"
        "text-decoration: underline;"
    "}"

    "QSint--ActionGroup QToolButton[class='action']:focus {"
        "border: 1px dotted black;"
    "}"

    "QSint--ActionGroup QToolButton[class='action']:on {"
        "background-color: #ddeeff;"                                // todo
        "color: #006600;"                                           // todo
    "}"
  )
  .arg(panelBackground1.name())
  .arg(panelBackground2.name())
  .arg(headerBackground1.name())
  .arg(headerBackground2.name())
  .arg(headerLabelText.name())
  .arg(headerLabelTextOver.name())
  .arg(groupBackground.name())
  .arg(groupBorder.name())
  .arg(taskLabelText.name())
  .arg(taskLabelTextOver.name())
  ;

  return style;
}

void HHPanelScheme::clearActionStyle()
{
    headerButtonFold = QPixmap();
    headerButtonFoldOver = QPixmap();
    headerButtonUnfold = QPixmap();
    headerButtonUnfoldOver = QPixmap();

    actionStyle = minimumStyle;
}

void HHPanelScheme::restoreActionStyle()
{
    headerButtonFold = builtinFold;
    headerButtonFoldOver = builtinFoldOver;
    headerButtonUnfold = builtinUnfold;
    headerButtonUnfoldOver = builtinUnfoldOver;

    actionStyle = builtinScheme;
}
}
