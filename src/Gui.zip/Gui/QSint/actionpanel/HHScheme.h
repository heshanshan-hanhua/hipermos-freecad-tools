﻿/*===================================================================
Copyright (c) 2021 HHintech
Unpublished - All rights reserved

=====================================================================
File description:

========================================================================
Date              Name                 Description of Change
2018/05/09        MZG                  Change style
2018/10/30        MZG                  Change style
2018/10/31        MZG                  Lighter head color
2021/08/17        LL                   Upgrade
==========================================================================*/


#ifndef HHTASKPANELSCHEME_H
#define HHTASKPANELSCHEME_H

#include "actionpanelscheme.h"


namespace QSint
{
class QSINT_EXPORT HHPanelScheme : public ActionPanelScheme
{
public:
    explicit HHPanelScheme();

    static ActionPanelScheme* defaultScheme()
    {
        static HHPanelScheme scheme;
        return &scheme;
    }
    void clearActionStyle();
    void restoreActionStyle();
private:
    QPixmap drawFoldIcon(const QPalette& p, bool fold) const;
    QString systemStyle(const QPalette& p) const;

    QString builtinScheme;
    QString minimumStyle;
    QPixmap builtinFold;
    QPixmap builtinFoldOver;
    QPixmap builtinUnfold;
    QPixmap builtinUnfoldOver;
	
};

}

#endif // IISFREECADTASKPANELSCHEME_H
