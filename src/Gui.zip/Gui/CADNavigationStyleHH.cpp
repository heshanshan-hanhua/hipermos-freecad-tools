﻿ /*===================================================================
 Copyright (c) 2023 HHintech
 Unpublished - All rights reserved

 =====================================================================
 File description:
 CADNavigationStyleHH used to view in 3D mode.

 =====================================================================
 Date            Name            Description of Change
 2023/04/27      LJ              Written
 2023/05/07      LL              Fixed bugs of key and mouse click at same time
 2023/05/09      LL              Fixed bug of popmenu while navi event is not finished
 HISTORY
 ====================================================================*/
#include "PreCompiled.h"
#ifndef _PreComp_
# include <cfloat>
# include "InventorAll.h"
# include <QAction>
# include <QActionGroup>
# include <QApplication>
# include <QByteArray>
# include <QCursor>
# include <QList>
# include <QMenu>
# include <QMetaObject>
# include <QRegExp>
#endif

#include <App/Application.h>
#include "NavigationStyle.h"
#include "View3DInventorViewer.h"
#include "Application.h"
#include "MenuManager.h"
#include "MouseSelection.h"

using namespace Gui;

// ----------------------------------------------------------------------------------

/* TRANSLATOR Gui::CADNavigationStyleHH */

TYPESYSTEM_SOURCE(Gui::CADNavigationStyleHH, Gui::UserNavigationStyleHH)

CADNavigationStyleHH::CADNavigationStyleHH()
{
}

CADNavigationStyleHH::~CADNavigationStyleHH()
{
}

const char* CADNavigationStyleHH::mouseButtons(ViewerMode mode)
{
    switch (mode) {
    case NavigationStyle::SELECTION:
        return QT_TR_NOOP("Press left mouse button");
    case NavigationStyle::PANNING:
        return QT_TR_NOOP("Press middle mouse button");
    case NavigationStyle::DRAGGING:
        return QT_TR_NOOP("Press middle + left mouse button \n"
            "or middle + right mouse button");
    case NavigationStyle::ZOOMING:
        return QT_TR_NOOP("Scroll middle mouse button");
    default:
        return "No description";
    }
}

void CADNavigationStyleHH::rightMouseButtonHandling(const SoEvent* const ev, const SbBool& press, ViewerMode& newmode, SbBool& processed)
{
    // If we are in edit mode then simply ignore the RMB events
// to pass the event to the base class.
    const SoMouseButtonEvent* const event = (const SoMouseButtonEvent*)ev;
    this->lockrecenter = true;
    if (!viewer->isEditing()) {
        // If we are in zoom or pan mode ignore RMB events otherwise
        // the canvas doesn't get any release events
        if (this->currentmode != NavigationStyle::ZOOMING &&
            this->currentmode != NavigationStyle::PANNING &&
            this->currentmode != NavigationStyle::DRAGGING) {
            if (this->isPopupMenuEnabled()) {
                if (!press &&!_eventInProcessing)
                { // release right mouse button
                    this->openPopupMenu(event->getPosition());
                }
            }
        }
    }
    // Alternative way of rotating & zooming
    if (press && (this->currentmode == NavigationStyle::PANNING ||
        this->currentmode == NavigationStyle::ZOOMING)) {
        newmode = NavigationStyle::DRAGGING;
        saveCursorPosition(ev);
        this->centerTime = ev->getTime();
        processed = true;
    }
    else if (!press && (this->currentmode == NavigationStyle::DRAGGING)) {
        SbTime tmp = (ev->getTime() - this->centerTime);
        float dci = (float)QApplication::doubleClickInterval() / 1000.0f;
        if (tmp.getValue() < dci) {
            newmode = NavigationStyle::ZOOMING;
        }
        processed = true;
    }
    this->button2down = press;
}

void CADNavigationStyleHH::leftMouseButtonHandling(const SoEvent* const ev, const SbBool& press, const SbVec2s& pos, ViewerMode& newmode, SbBool& processed)
{
    this->lockrecenter = true;
    this->button1down = press;
    const SoMouseButtonEvent* const event = (const SoMouseButtonEvent*)ev;
    if (press && (this->currentmode == NavigationStyle::SEEK_WAIT_MODE)) {
        newmode = NavigationStyle::SEEK_MODE;
        this->seekToPoint(pos); // implicitly calls interactiveCountInc()
        processed = true;
    }
    else if (press && (this->currentmode == NavigationStyle::PANNING ||
        this->currentmode == NavigationStyle::ZOOMING)) {
        newmode = NavigationStyle::DRAGGING;
        saveCursorPosition(ev);
        this->centerTime = ev->getTime();
        processed = true;
    }
    else if (!press && (this->currentmode == NavigationStyle::DRAGGING)) {
        SbTime tmp = (ev->getTime() - this->centerTime);
        float dci = (float)QApplication::doubleClickInterval() / 1000.0f;
        if (tmp.getValue() < dci) {
            newmode = NavigationStyle::ZOOMING;
        }
        processed = true;
    }
    else if (viewer->isEditing() && (this->currentmode == NavigationStyle::SPINNING)) {
        processed = true;
    }
    // issue #0002433: avoid to swallow the UP event if down the
    // scene graph somewhere a dialog gets opened
    else if (press) {
        SbTime tmp = (ev->getTime() - mouseDownConsumedEvent.getTime());
        float dci = (float)QApplication::doubleClickInterval() / 1000.0f;
        // a double-click?
        if (tmp.getValue() < dci) {
            mouseDownConsumedEvent = *event;
            mouseDownConsumedEvent.setTime(ev->getTime());
            processed = true;
        }
        else {
            mouseDownConsumedEvent.setTime(ev->getTime());
            // 'ANY' is used to mark that we don't know yet if it will
            // be a double-click event.
            mouseDownConsumedEvent.setButton(SoMouseButtonEvent::ANY);
        }
    }
    else if (!press) {
        if (mouseDownConsumedEvent.getButton() == SoMouseButtonEvent::BUTTON1) {
            // now handle the postponed event
            inherited::processSoEvent(&mouseDownConsumedEvent);
            mouseDownConsumedEvent.setButton(SoMouseButtonEvent::ANY);
        }
    }
}

void CADNavigationStyleHH::buttonComboHandling(const SoEvent* const ev, const ViewerMode& curmode, ButtonActionCombo combo, ViewerMode& newmode, SbBool& processed)
{
    unsigned int refactorCombo = (combo & BUTTON1DOWN ? BUTTON1DOWN : 0) |
            (combo & BUTTON2DOWN ? BUTTON2DOWN : 0) |
            (combo & BUTTON3DOWN ? BUTTON3DOWN : 0);
    if (!(combo & BUTTON1DOWN || combo & BUTTON2DOWN || combo & BUTTON3DOWN))
    {
        _eventInProcessing = false;
    }
    switch (refactorCombo) {
    case 0:
        if (curmode == NavigationStyle::SPINNING) { break; }
        newmode = NavigationStyle::IDLE;
        // The left mouse button has been released right now but
        // we want to avoid that the event is processed elsewhere
        if (this->lockButton1) {
            this->lockButton1 = false;
            processed = true;
        }
        break;
    case BUTTON1DOWN:
        // make sure not to change the selection when stopping spinning
        if (curmode == NavigationStyle::SPINNING || this->lockButton1)
            newmode = NavigationStyle::IDLE;
        else
            newmode = NavigationStyle::SELECTION;
        break;
    case BUTTON3DOWN:
        if (curmode == NavigationStyle::SPINNING) { break; }
        else if (newmode == NavigationStyle::ZOOMING) { break; }
        newmode = NavigationStyle::PANNING;

        if (curmode == NavigationStyle::DRAGGING) {
            if (doSpin()) {
                newmode = NavigationStyle::SPINNING;
                break;
            }
        }
        break;
    case BUTTON2DOWN | BUTTON3DOWN:
    case BUTTON1DOWN | BUTTON3DOWN:
        if (newmode != NavigationStyle::DRAGGING) {
            saveCursorPosition(ev);
        }
        newmode = NavigationStyle::DRAGGING;
        _eventInProcessing = true;
        break;
    default:
        // The default will make a spin stop and otherwise not do
        // anything.
        newmode = NavigationStyle::IDLE;
        break;
    }
}
