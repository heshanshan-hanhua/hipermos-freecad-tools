﻿/***************************************************************************
 *   Copyright (c) 2008 Werner Mayer <wmayer[at]users.sourceforge.net>     *
 *                                                                         *
 *   This file is part of the FreeCAD CAx development system.              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Library General Public           *
 *   License as published by the Free Software Foundation; either          *
 *   version 2 of the License, or (at your option) any later version.      *
 *                                                                         *
 *   This library  is distributed in the hope that it will be useful,      *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Library General Public License for more details.                  *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this library; see the file COPYING.LIB. If not,    *
 *   write to the Free Software Foundation, Inc., 59 Temple Place,         *
 *   Suite 330, Boston, MA  02111-1307, USA                                *
 *                                                                         *
 ***************************************************************************/
/*===================================================================
 Copyright (c) 2021 HHintech
 Unpublished - All rights reserved

=====================================================================
 File description: 

=====================================================================
 Date           Name            Description of Change
 2021/08/17     Liulei          add export

 HISTORY
====================================================================*/

#ifndef GUI_ASSISTANT_H
#define GUI_ASSISTANT_H

#include <QObject>

class QProcess;

namespace Gui {
//FreeCAD19_Update
class GuiExport Assistant : public QObject
{
    Q_OBJECT

public:
    Assistant();
    ~Assistant();
    void showDocumentation(const QString &file);

private Q_SLOTS:
    void readyReadStandardOutput();
    void readyReadStandardError();

private:
    bool startAssistant();
    QProcess *proc;
};

}

#endif // GUI_ASSISTANT_H
