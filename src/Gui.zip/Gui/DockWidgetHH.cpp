﻿/*===================================================================
Copyright (c) 2018 MIRC, Wit
Unpublished - All rights reserved

=====================================================================
File description:
class DockWidget is derived from class QDockWidget. DockWidget
will send close signal in close event, which can notify controls
located on DockWidget to finish their work before parent is closed.

=====================================================================
Date            Name            Description of Change
2018/3/13        JHQ                Written(defect 54)
2021/08/17       LL             Upgrade
====================================================================*/

#include "PreCompiled.h"
#include "DockWidgetHH.h"

using namespace Gui;

DockWidget::DockWidget(QWidget *parent, Qt::WindowFlags flags) 
    :QDockWidget(parent, flags)
{
}


DockWidget::~DockWidget()
{
}

void Gui::DockWidget::closeEvent(QCloseEvent *event)
{
    CloseDockWidgetSignal();
    QDockWidget::closeEvent(event);
}

#include "moc_DockWidgetHH.cpp"
