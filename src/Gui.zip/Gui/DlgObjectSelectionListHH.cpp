﻿/*===================================================================
Copyright (c) 2019
Unpublished - All rights reserved

=====================================================================
File description:
the dialog for select one object in list

=====================================================================
Date            Name            Description of Change
2019/10/09      WangSong        Written
2019/10/12      WangSong        fix highlight bug
2019/10/14      WangSong        disable active task dialog
2019/10/14      WS              can't change filter type if dialog exists
2021/08/17      LL              Upgrade
2023/07/13      LL              Unhighlight while close
HISTORY
====================================================================*/
#include "PreCompiled.h"
#include "DlgObjectSelectionListHH.h"
#include <Gui/ViewProviderDocumentObject.h>
#include "moc_DlgObjectSelectionListHH.cpp"
#include <Gui/Selection.h>
#include <Gui/SoFCUnifiedSelection.h>
#include <Gui/StackControlBaseHH.h>
#include <QTableWidget>

namespace
{
    int preHoverRow = -1;
    QColor lastRowBkColor = QColor(0x00, 0xff, 0x00, 0x00);
    static SoFullPath * currenthighlight = NULL;
}
namespace Gui
{
    namespace Dialog
    {
        DlgObjectSelectionList::DlgObjectSelectionList(QWidget* parent /*= 0*/, Qt::WindowFlags fl) :
            QDialog(parent, fl)
        {
            QVBoxLayout* mainLay = new QVBoxLayout(this);
            _vpTable = new QTableWidget;
            _vpTable->setSelectionMode(QAbstractItemView::SingleSelection);
            _vpTable->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
            //_vpTable->horizontalHeader()->setResizeMode(QHeaderView::ResizeToContents);
            _vpTable->horizontalHeader()->setStretchLastSection(true);
            _vpTable->horizontalHeader()->setVisible(false);
            _vpTable->verticalHeader()->setStyleSheet(QString::fromUtf8("QHeaderView::section{border:0.5px groove gray;}"));
            _vpTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
            _vpTable->setSelectionBehavior(QAbstractItemView::SelectRows);
            _vpTable->setColumnCount(1);
            _vpTable->setMouseTracking(true);
            connect(_vpTable, SIGNAL(cellEntered(int, int)), this, SLOT(CellEntered(int, int)));
            connect(_vpTable, SIGNAL(itemClicked(QTableWidgetItem *)), this, SLOT(accept()));
            mainLay->addWidget(_vpTable);
            setWindowTitle(tr("Quick pick"));
            preHoverRow = -1;

            if (Gui::StackControlBase().HasActiveDlg())
            {
                Gui::StackControlBase().EnableActiveDlg(false);
            }
            Gui::Selection().SetIsFilterEnabled(false);
        }


        DlgObjectSelectionList::~DlgObjectSelectionList()
        {
            _Close();
        }

        void DlgObjectSelectionList::SetSegmentsForSelection(const std::vector<std::pair<ViewProviderDocumentObject*, std::string> > &seg)
        {
            _segments = seg;
            _vpTable->clearContents();
            _vpTable->setRowCount(0);

            int iRow = 0;
            for (auto &it : seg)
            {
                _vpTable->insertRow(iRow);
                std::string str = it.first->getObject()->Label.getValue();
                if (!it.second.empty())
                {
                    str += "." + it.second;
                }
                QTableWidgetItem* item = new QTableWidgetItem(QString::fromUtf8(str.c_str()));
                _vpTable->setItem(iRow, 0, item);
                ++iRow;
            }
        }

        std::pair<ViewProviderDocumentObject*, std::string> DlgObjectSelectionList::GetSelSegment() const
        {
            QList<QTableWidgetItem*> selItems = _vpTable->selectedItems();
            std::set<int> rows;
            for (auto it : selItems)
            {
                rows.insert(it->row());
            }

            std::pair<ViewProviderDocumentObject*, std::string> res = { NULL, "" };
            if (!rows.empty())
            {
                int selRow = *rows.begin();
                res = _segments[selRow];
            }

            return res;
        }


        void DlgObjectSelectionList::CellEntered(int row, int column)
        {
            PreviewCurrentHover(row);
        }


        void DlgObjectSelectionList::accept()
        {
            QDialog::accept();
            _Close();
            signalSelectSegment(GetSelSegment());
        }


        void DlgObjectSelectionList::reject()
        {
            QDialog::reject();
            _Close();
            signalCancelSelect();
        }

        void DlgObjectSelectionList::paintEvent(QPaintEvent * event)
        {
            QDialog::paintEvent(event);
            if (preHoverRow == -1)
            {
                PreviewCurrentHover(0);
            }
        }

        void DlgObjectSelectionList::PreviewCurrentHover(int row)
        {
            if (preHoverRow == row || row >= _segments.size())
            {
                return;
            }

            if (preHoverRow >= 0)
            {
                for (int col = 0; col < _vpTable->columnCount(); ++col)
                {
                    QTableWidgetItem* tmp = _vpTable->item(preHoverRow, col);
                    tmp->setBackgroundColor(lastRowBkColor);
                }
            }
            for (int col = 0; col < _vpTable->columnCount(); ++col)
            {
                QTableWidgetItem* tmp = _vpTable->item(row, col);
                tmp->setBackgroundColor(QColor(193.0, 210.0, 240.0));//light blue
            }

            preHoverRow = row;
            RePreviewRow(row);
        }


        void DlgObjectSelectionList::RePreviewRow(int row)
        {
            std::pair<ViewProviderDocumentObject*, std::string> hoverSeg = _segments[row];
            std::string docName = hoverSeg.first->getObject()->getDocument()->getName();
            std::string objName = hoverSeg.first->getObject()->getNameInDocument();
            bool sel = Gui::Selection().setPreselect(docName.c_str()
                , objName.c_str()
                , hoverSeg.second.c_str());
            if (sel && hoverSeg.first->useNewSelectionModel())
            {
                bool highlighted = false;
                SoSearchAction sa;
                sa.setNode(hoverSeg.first->getRoot());
                sa.apply(hoverSeg.first->getRoot());
                if (sa.getPath()) {
                    highlighted = true;
                    if (currenthighlight)
                    {
                        Gui::SoHighlightElementAction action;
                        action.setHighlighted(false);
                        action.apply(currenthighlight);
                        currenthighlight->unref();
                        currenthighlight = NULL;
                    }
                    currenthighlight = static_cast<SoFullPath*>(sa.getPath()->copy());
                    currenthighlight->ref();
                }

                if (currenthighlight)
                {
                    SoHighlightElementAction action;
                    action.setHighlighted(highlighted);
                    App::Color highlightColor = hoverSeg.first->HighlightVpColor.getValue();
                    action.setColor(SbColor(highlightColor.r, highlightColor.g, highlightColor.b));
                    action.setElement(hoverSeg.first->getDetail(hoverSeg.second.c_str()));

                    if (hoverSeg.second.empty())
                    {
                        SoHighlightElementAction::Type type = SoHighlightElementAction::All;
                        action.setType(type);
                    }

                    action.apply(currenthighlight);
                    if (!highlighted) {
                        currenthighlight->unref();
                        currenthighlight = 0;
                    }
                }
            }
        }


        void DlgObjectSelectionList::_Close()
        {
            Gui::Selection().rmvPreselect();
            if (currenthighlight)
            {
                SoHighlightElementAction action;
                action.setHighlighted(false);
                action.apply(currenthighlight);
                currenthighlight->unref();
            }
            preHoverRow = -1;
            currenthighlight = NULL;

            if (Gui::StackControlBase().HasActiveDlg())
            {
                Gui::StackControlBase().EnableActiveDlg(true);
            }

            Gui::Selection().SetIsFilterEnabled(true);
        }

    }
}

