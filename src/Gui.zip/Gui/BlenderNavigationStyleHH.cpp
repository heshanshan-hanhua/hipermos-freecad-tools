﻿ /*===================================================================
 Copyright (c) 2023 HHintech
 Unpublished - All rights reserved

 =====================================================================
 File description:
 BlenderNavigationStyleHH used to view in 3D mode.

 =====================================================================
 Date            Name            Description of Change
 2023/04/27      LJ              Written
 2023/05/07      LL              Fixed bugs of key and mouse click at same time
 2023/05/09      LL              Process navi event only when specified mouse or key is pressed 
 HISTORY
 ====================================================================*/
#include "PreCompiled.h"
#ifndef _PreComp_
# include <cfloat>
# include "InventorAll.h"
# include <QAction>
# include <QActionGroup>
# include <QApplication>
# include <QByteArray>
# include <QCursor>
# include <QList>
# include <QMenu>
# include <QMetaObject>
# include <QRegExp>
#endif

#include <App/Application.h>
#include "NavigationStyle.h"
#include "View3DInventorViewer.h"
#include "Application.h"
#include "MenuManager.h"
#include "MouseSelection.h"

using namespace Gui;

// ----------------------------------------------------------------------------------

/* TRANSLATOR Gui::BlenderNavigationStyleHH */

TYPESYSTEM_SOURCE(Gui::BlenderNavigationStyleHH, Gui::UserNavigationStyle)

BlenderNavigationStyleHH::BlenderNavigationStyleHH()
{
}

BlenderNavigationStyleHH::~BlenderNavigationStyleHH()
{
}

const char* BlenderNavigationStyleHH::mouseButtons(ViewerMode mode)
{
    switch (mode) {
    case NavigationStyle::SELECTION:
        return QT_TR_NOOP("Press left mouse button");
    case NavigationStyle::PANNING:
        return QT_TR_NOOP("Press Shift + middle mouse button");
    case NavigationStyle::DRAGGING:
        return QT_TR_NOOP("Press middle mouse button");
    case NavigationStyle::ZOOMING:
        return QT_TR_NOOP("Scroll middle mouse button");
    default:
        return "No description";
    }
}

void BlenderNavigationStyleHH::keyBoardHandling(const SoEvent* const ev, const SoType& type, SbBool& processed)
{
    // Keyboard handling
    if (type.isDerivedFrom(SoKeyboardEvent::getClassTypeId()))
    {
        const SoKeyboardEvent* const event = (const SoKeyboardEvent*)ev;
        const SbBool press = event->getState() == SoButtonEvent::DOWN ? true : false;
        switch (event->getKey())
        {
        case SoKeyboardEvent::LEFT_CONTROL:
        case SoKeyboardEvent::RIGHT_CONTROL:
            this->ctrldown = press;
            break;
        case SoKeyboardEvent::LEFT_SHIFT:
        case SoKeyboardEvent::RIGHT_SHIFT:
            this->shiftdown = press;
            break;
        case SoKeyboardEvent::LEFT_ALT:
        case SoKeyboardEvent::RIGHT_ALT:
            this->altdown = press;
            break;
        case SoKeyboardEvent::H:
            processed = true;
            viewer->saveHomePosition();
            break;
        case SoKeyboardEvent::R:
            processed = true;
            viewer->resetToHomePosition();
            break;
        case SoKeyboardEvent::S:
        case SoKeyboardEvent::HOME:
        case SoKeyboardEvent::LEFT_ARROW:
        case SoKeyboardEvent::UP_ARROW:
        case SoKeyboardEvent::RIGHT_ARROW:
        case SoKeyboardEvent::DOWN_ARROW:
            if (!this->isViewing())
                this->setViewing(true);
            break;
        default:
            break;
        }
    }
}

void BlenderNavigationStyleHH::rightMouseButtonHandling(const SoEvent* const ev, const SbBool& press, ViewerMode& newmode, SbBool& processed)
{
    const SoMouseButtonEvent* const event = (const SoMouseButtonEvent*)ev;
    // If we are in edit mode then simply ignore the RMB events
    // to pass the event to the base class.
    this->lockrecenter = true;
    if (!viewer->isEditing()) {
        // If we are in zoom or pan mode ignore RMB events otherwise
        // the canvas doesn't get any release events
        if (press) {
            saveCursorPosition(ev);
            this->centerTime = ev->getTime();
            //processed = true;
        }
        else if (!press)
        {
            SbTime tmp = (ev->getTime() - this->centerTime);
            float dci = (float)QApplication::doubleClickInterval() / 1000.0f;
            if (tmp.getValue() < dci)
            {
                if (this->isPopupMenuEnabled())
                {
                    this->openPopupMenu(event->getPosition());
                }
            }
        }
    }

    this->button2down = press;
}

void BlenderNavigationStyleHH::mouseMovementHandling(const SoEvent* const ev, const SoType& type, const SbVec2f& posn, const SbVec2f prevnormalized, ViewerMode& newmode, SbBool& processed)
{
    const SbViewportRegion& vp = viewer->getSoRenderManager()->getViewportRegion();

    // Mouse Movement handling
    if (type.isDerivedFrom(SoLocation2Event::getClassTypeId())) {
        this->lockrecenter = true;
        const SoLocation2Event* const event = (const SoLocation2Event*)ev;
        if (this->currentmode == NavigationStyle::ZOOMING) {
            this->zoomByCursor(posn, prevnormalized);
            newmode = NavigationStyle::SELECTION;
            processed = true;
        }
        else if (this->currentmode == NavigationStyle::PANNING) {
            float ratio = vp.getViewportAspectRatio();
            panCamera(viewer->getSoRenderManager()->getCamera(), ratio, this->panningplane, posn, prevnormalized);
            newmode = NavigationStyle::SELECTION;
            processed = true;
        }
        else if (this->currentmode == NavigationStyle::DRAGGING) {
            this->addToLog(event->getPosition(), event->getTime());
            this->spin(posn);
            moveCursorPosition();
            processed = true;
        }
    }
}

void BlenderNavigationStyleHH::buttonComboHandling(const SoEvent* const ev, const ViewerMode& curmode, ButtonActionCombo combo, ViewerMode& newmode, SbBool& processed)
{
    unsigned int refactorCombo = (combo & BUTTON1DOWN ? BUTTON1DOWN : 0) |
        (combo & BUTTON2DOWN ? BUTTON2DOWN : 0) |
        (combo & BUTTON3DOWN ? BUTTON3DOWN : 0) |
        (combo & SHIFTDOWN ? SHIFTDOWN : 0)
        ;
    switch (refactorCombo) {
    case 0:
        if (curmode == NavigationStyle::SPINNING) { break; }
        newmode = NavigationStyle::IDLE;
        // The left mouse button has been released right now but
        // we want to avoid that the event is processed elsewhere
        if (this->lockButton1) {
            this->lockButton1 = false;
            processed = true;
        }

        break;
    case BUTTON1DOWN:
    case CTRLDOWN | BUTTON1DOWN:
        // make sure not to change the selection when stopping spinning
        if (curmode == NavigationStyle::SPINNING || this->lockButton1)
            newmode = NavigationStyle::IDLE;
        else
            newmode = NavigationStyle::SELECTION;
        break;
    //case BUTTON1DOWN | BUTTON2DOWN:
    //    newmode = NavigationStyle::PANNING;
    //    break;
    case SHIFTDOWN | BUTTON3DOWN:
        newmode = NavigationStyle::PANNING;
        break;
    case BUTTON3DOWN | BUTTON1DOWN:
    case BUTTON3DOWN | BUTTON2DOWN:
        newmode = NavigationStyle::IDLE;
        break;
    case BUTTON3DOWN:
        if (newmode != NavigationStyle::DRAGGING) {
            saveCursorPosition(ev);
        }
        newmode = NavigationStyle::DRAGGING;
        break;
    //case CTRLDOWN | SHIFTDOWN | BUTTON2DOWN:
    //case CTRLDOWN | BUTTON3DOWN:
    //    newmode = NavigationStyle::ZOOMING;
    //    break;

    default:
    {
        newmode = NavigationStyle::IDLE;
    }
        break;
    }
}
