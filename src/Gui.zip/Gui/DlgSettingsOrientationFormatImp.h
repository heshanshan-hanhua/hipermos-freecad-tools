﻿ /*===================================================================
 Copyright (c) 2023
 Unpublished - All rights reserved

 =====================================================================
 File description:

 =====================================================================
 Date            Name            Description of Change
 2023/05/15       LL             Written

 HISTORY
 ====================================================================*/

#ifndef DIALOG_DLGSETTINGSORIENTATIONFORMAT_IMP_H
#define DIALOG_DLGSETTINGSORIENTATIONFORMAT_IMP_H

#include <Gui/PropertyPage.h>
#include <memory>

namespace Gui 
{
    namespace Dialog 
    {
        class DlgSettingsOrientationFormat;

        class DlgSettingsOrientationFormatImp : public PreferencePage
        {
            Q_OBJECT

        public:
            explicit DlgSettingsOrientationFormatImp( QWidget* parent = 0 );
            ~DlgSettingsOrientationFormatImp();

            void saveSettings();
            void loadSettings();

            virtual void resetSettings();

        protected Q_SLOTS:
            void SlotOrientationFormatChanged(int index);

        protected:
            void changeEvent(QEvent *e);

        private:
            DlgSettingsOrientationFormat* _ui;
        };

    } // namespace Dialog
} // namespace Gui

#endif // DIALOG_DLGSETTINGSORIENTATIONFORMAT_IMP_H
