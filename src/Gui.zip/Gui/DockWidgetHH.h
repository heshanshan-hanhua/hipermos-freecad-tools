/*===================================================================
Copyright (c) 2018 MIRC, Wit
Unpublished - All rights reserved

=====================================================================
File description:
class DockWidget is derived from class QDockWidget. DockWidget 
will send close signal in close event, which can notify controls 
located on DockWidget to finish their work before parent is closed.

=====================================================================
Date            Name            Description of Change
2018/3/13       JHQ             Written(defect 54)
2018/04/08      MZG             Remove tabs and correct wrong line endings
2021/08/17       LL             Upgrade
====================================================================*/
#ifndef DOCKWIDGET_H
#define DOCKWIDGET_H

#include "qdockwidget.h"

namespace Gui 
{
    class GuiExport DockWidget : public QDockWidget
    {
        Q_OBJECT

    public:
        DockWidget(QWidget *parent = 0, Qt::WindowFlags flags = 0);
        ~DockWidget();

    Q_SIGNALS:
        void CloseDockWidgetSignal();

    protected:
        void closeEvent(QCloseEvent *event);

    };

}


#endif // DOCKWIDGET_H
