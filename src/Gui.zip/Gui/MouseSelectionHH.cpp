﻿/*===================================================================
Copyright (c) 2021 HHintech
Unpublished - All rights reserved

=====================================================================
File description:

=====================================================================
Date            Name            Description of Change
2021/07/13      LL              Written
====================================================================*/


#include "PreCompiled.h"

#ifndef _PreComp_
# include <qapplication.h>
# include <qevent.h>
# include <qpainter.h>
# include <qpixmap.h>
# include <QMenu>
# include <Inventor/SbBox.h>
# include <Inventor/events/SoEvent.h>
# include <Inventor/events/SoKeyboardEvent.h>
# include <Inventor/events/SoLocation2Event.h>
# include <Inventor/events/SoMouseButtonEvent.h>
#endif

#include <QtOpenGL.h>
#include <Base/Console.h>

#include "MouseSelectionHH.h"
#include "View3DInventor.h"
#include "View3DInventorViewer.h"

using namespace Gui;

MixedRectangleSelection::MixedRectangleSelection() : RubberbandSelection()
{
    rubberband.setColor(0.0, 0.0, 1.0, 1.0);
    _isLeftButtonPressed = false;
}

MixedRectangleSelection::~MixedRectangleSelection()
{
}
int MixedRectangleSelection::mouseButtonEvent(const SoMouseButtonEvent* const e, const QPoint& pos)
{
    const int button = e->getButton();
    const SbBool press = e->getState() == SoButtonEvent::DOWN ? true : false;

    int ret = Continue;

    if(press) {
        switch(button)
        {
        case SoMouseButtonEvent::BUTTON1:
        {
            if(_isMidButtonPressed == false)
            {
                m_iXold = m_iXnew = pos.x();
                m_iYold = m_iYnew = pos.y();
                _isLeftButtonPressed = true;
            }
            else
            {
                ret = Ignore;
            }

        }
        break;
        case SoMouseButtonEvent::BUTTON3:
        {
            _isMidButtonPressed = true;
            ret = Ignore;
        }
        break;
        default:
        {
            ret = Ignore;
        }   break;
        }
    }
    else {
        switch(button) {
        case SoMouseButtonEvent::BUTTON1:
        {
            rubberband.setWorking(false);
            if(_isKeepSelection == true)
            {
                if(_pcView3D)
                {
                    SetRenderType(View3DInventorViewer::Native);
                }
            }
            else
            {
                releaseMouseModel();
            }
            _clPoly.push_back(e->getPosition());
            ret = Finish;
            _isLeftButtonPressed = false;
        }
        break;
        case SoMouseButtonEvent::BUTTON3:
        {
            _isMidButtonPressed = false;
            ret = Ignore;
        }
        break;

        default:
        {
            ret = Ignore;
        }   break;
        }
    }

    return ret;
}

int MixedRectangleSelection::locationEvent(const SoLocation2Event* const e, const QPoint& pos)
{
    if(_isLeftButtonPressed == true && _isMidButtonPressed == false)
    {
        draw();  //refresh before
        SetRenderType(View3DInventorViewer::Image, false);
        rubberband.setWorking(true);
        m_iXnew = pos.x();
        m_iYnew = pos.y();
        rubberband.setCoords(m_iXold, m_iYold, m_iXnew, m_iYnew);
        draw();
        _mouseSelectionType = MouseSelectionType_Polygon;
        return Continue;
    }
    else
    {
        _clPoly.clear();
        rubberband.setWorking(false);
        if(_pcView3D)
        {
            SetRenderType(View3DInventorViewer::Native);
        }
        _mouseSelectionType = MouseSelectionType_Single;
        return Ignore;
    }

}

int MixedRectangleSelection::keyboardEvent(const SoKeyboardEvent* const e)
{
    return Continue;
}

