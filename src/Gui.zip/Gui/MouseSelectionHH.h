﻿/*===================================================================
Copyright (c) 2021 HHintech
Unpublished - All rights reserved

=====================================================================
File description:

=====================================================================
Date            Name            Description of Change
2021/07/13      LL              Written
====================================================================*/


#ifndef MOUSESELECTION_HH_H
#define MOUSESELECTION_HH_H
#include "MouseSelection.h"

namespace Gui {
    /**
    * The selection mouse model class
    * Draws a rectangle for selection
    * \author Werner Mayer
    */
    class GuiExport MixedRectangleSelection : public RubberbandSelection
    {
    public:
        MixedRectangleSelection();
        virtual ~MixedRectangleSelection();

    protected:
        virtual int mouseButtonEvent(const SoMouseButtonEvent* const e, const QPoint& pos);
        virtual int locationEvent(const SoLocation2Event* const e, const QPoint& pos);
        virtual int keyboardEvent(const SoKeyboardEvent* const e);
    };

    // -----------------------------------------------------------------------------------

} // namespace Gui

#endif // MOUSESELECTION_H
