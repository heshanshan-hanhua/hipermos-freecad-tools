﻿/*========================================================================
Copyright (c) 2023 HHintech
Unpublished - All rights reserved

==========================================================================
File description:

==========================================================================
Date              Name                 Description of Change
2023/05/15        LJ                   Written
2023/06/07        LJ                   Change the order of pose setting options
2023/06/28        LJ                   Supplementary explanation on the value of the dropdown option

HISTORY
====================================================================*/
#include "PreCompiled.h"
#include "DlgSettingsOrientationFormat.h"
#include <QtGui>
#include "Gui/PrefWidgets.h"
//#include "HHApplication.h"
//#include "GuiErrorList.h"

using namespace Gui;
using namespace Dialog;

namespace
{

}

DlgSettingsOrientationFormat::DlgSettingsOrientationFormat(QWidget* parent)
{

}

DlgSettingsOrientationFormat::~DlgSettingsOrientationFormat()
{}

void Gui::Dialog::DlgSettingsOrientationFormat::setupUi(QWidget* Gui__Dialog__DlgSettingsOrientationFormat)
{
    if (Gui__Dialog__DlgSettingsOrientationFormat->objectName().isEmpty())
        Gui__Dialog__DlgSettingsOrientationFormat->setObjectName(QString::fromUtf8("Gui__Dialog__DlgSettingsOrientationFormat"));
    Gui__Dialog__DlgSettingsOrientationFormat->resize(607, 859);
    gridLayout1 = new QGridLayout(Gui__Dialog__DlgSettingsOrientationFormat);
    gridLayout1->setSpacing(6);
    gridLayout1->setContentsMargins(11, 11, 11, 11);
    gridLayout1->setObjectName(QString::fromUtf8("gridLayout1"));

    groupBox1 = new QGroupBox(Gui__Dialog__DlgSettingsOrientationFormat);
    groupBox1->setObjectName(QString::fromUtf8("groupBox1"));

    gridLayout2 = new QGridLayout(groupBox1);
    gridLayout2->setSpacing(6);
    gridLayout2->setContentsMargins(11, 11, 11, 11);
    gridLayout2->setObjectName(QString::fromUtf8("gridLayout2"));

    textLabel1 = new QLabel(groupBox1);
    textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
    prefOrientationType = new Gui::PrefComboBox(groupBox1);
    prefOrientationType->addItem(QString());
    prefOrientationType->addItem(QString());
    prefOrientationType->addItem(QString());
    prefOrientationType->addItem(QString());
    prefOrientationType->setObjectName(QString::fromUtf8("prefOrientationType"));
    prefOrientationType->setEnabled(true);
    prefOrientationType->setEditable(false);
    prefOrientationType->setProperty("prefEntry", QVariant(QByteArray("OrientationFormat")));
    prefOrientationType->setProperty("prefPath", QVariant(QByteArray("OrientationFormat")));

    gridLayout2->addWidget(textLabel1, 0, 1, 1, 1);
    gridLayout2->addWidget(prefOrientationType, 0, 2, 1, 1);
    gridLayout1->addWidget(groupBox1, 0, 0, 1, 1);

    spacerItem1 = new QSpacerItem(429, 37, QSizePolicy::Minimum, QSizePolicy::Expanding);
    gridLayout1->addItem(spacerItem1, 2, 0, 1, 1);

    retranslateUi(Gui__Dialog__DlgSettingsOrientationFormat);
}


void Gui::Dialog::DlgSettingsOrientationFormat::retranslateUi(QWidget* Gui__Dialog__DlgSettingsOrientationFormat)
{
    Gui__Dialog__DlgSettingsOrientationFormat->setWindowTitle(QCoreApplication::translate("Gui::Dialog::DlgSettingsOrientationFormatImp", "Orientation format", nullptr));
    groupBox1->setTitle(QCoreApplication::translate("Gui::Dialog::DlgSettingsOrientationFormatImp", "General", nullptr));

    textLabel1->setText(QCoreApplication::translate("Gui::Dialog::DlgSettingsOrientationFormatImp", "Orientation format", nullptr));
    prefOrientationType->setItemText(0, QCoreApplication::translate("Gui::Dialog::DlgSettingsOrientationFormatImp", "Dynamic ZYX", nullptr));
    prefOrientationType->setItemText(1, QCoreApplication::translate("Gui::Dialog::DlgSettingsOrientationFormatImp", "Dynamic ZXZ", nullptr));
    prefOrientationType->setItemText(2, QCoreApplication::translate("Gui::Dialog::DlgSettingsOrientationFormatImp", "Dynamic ZYZ", nullptr));
    prefOrientationType->setItemText(3, QCoreApplication::translate("Gui::Dialog::DlgSettingsOrientationFormatImp", "Quaternion XYZW", nullptr));
    //prefOrientationType->setItemText(0, QCoreApplication::translate("Gui::Dialog::DlgSettingsOrientationFormatImp", "Dynamic ZYZ", nullptr));
    //prefOrientationType->setItemText(1, QCoreApplication::translate("Gui::Dialog::DlgSettingsOrientationFormatImp", "Dynamic ZXZ", nullptr));
    //prefOrientationType->setItemText(2, QCoreApplication::translate("Gui::Dialog::DlgSettingsOrientationFormatImp", "Dynamic ZYX", nullptr));
    //prefOrientationType->setItemText(3, QCoreApplication::translate("Gui::Dialog::DlgSettingsOrientationFormatImp", "Static ZYZ", nullptr));
    //prefOrientationType->setItemText(4, QCoreApplication::translate("Gui::Dialog::DlgSettingsOrientationFormatImp", "Static ZXZ", nullptr));
    //prefOrientationType->setItemText(5, QCoreApplication::translate("Gui::Dialog::DlgSettingsOrientationFormatImp", "Static ZYX", nullptr));

}

#include "moc_DlgSettingsOrientationFormat.cpp"
