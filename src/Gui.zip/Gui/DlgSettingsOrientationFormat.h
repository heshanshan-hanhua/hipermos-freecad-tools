﻿/*========================================================================
Copyright (c) 2018 MIRC, Wit
Unpublished - All rights reserved

==========================================================================
File description:

==========================================================================
Date              Name                 Description of Change
2023/05/15        LJ                   Written

HISTORY
====================================================================*/

#ifndef DLG_SETTINGS_ORIENTATION_FORMAT_H
#define DLG_SETTINGS_ORIENTATION_FORMAT_H
#include <FCConfig.h>
#include <QtWidgets/QtWidgets>
#include <set>

namespace Gui {
    class PrefComboBox;
    namespace Dialog {

        class DlgSettingsOrientationFormat : public QWidget
        {
            Q_OBJECT

        public:
            DlgSettingsOrientationFormat(QWidget* parent = 0);
            virtual ~DlgSettingsOrientationFormat();

            void setupUi(QWidget* Gui__Dialog__DlgSettingsOrientationFormat);

            void retranslateUi(QWidget* Gui__Dialog__DlgSettingsOrientationFormat);

            QGridLayout* gridLayout1;
            QGroupBox* groupBox1;
            QGridLayout* gridLayout2;
            QLabel* textLabel1;
            Gui::PrefComboBox* prefOrientationType;
            QSpacerItem* spacerItem1;

        //protected:
        public Q_SLOTS:
        };
    }// namespace Dialog
} // namespace Gui


#endif // DLG_SETTINGS_ORIENTATION_FORMAT_H
