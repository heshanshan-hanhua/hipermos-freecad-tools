﻿/*===================================================================
 Copyright (c) 2021 HHintech
 Unpublished - All rights reserved

=====================================================================
 File description: 

=====================================================================
 Date           Name            Description of Change
 2021/08/17     Liulei         add some general definition
 2023/12/26     HX             add UserDefine_MODE

 HISTORY
====================================================================*/
#ifndef COMMONDEFINITION_HH_H
#define COMMONDEFINITION_HH_H

namespace Gui {
    //Navigation Mode is set to distribute different mouse operation style
    enum NavigationMode
    {
        NavigationMode_None = 0,
        OBSERVE_MODE,
        SELECTION_MODE,
        UserDefine_MODE,
    };

    enum MouseSelectionType
    {
        MouseSelectionType_Single = 0,
        MouseSelectionType_Polygon,
        MouseSelectionType_Stay
    };

    //Tree
    /// highlight modes for the tree items
    enum class HighlightMode {
        Underlined,
        Italic,
        Overlined,
        Bold,
        Blue,
        LightBlue,
        UserDefined
    };

    /// highlight modes for the tree items
    enum class TreeItemMode {
        ExpandItem,
        ExpandPath,
        CollapseItem,
        ToggleItem
    };
} // namespace Gui

#endif // COMMONDEFINITION_HH_H
