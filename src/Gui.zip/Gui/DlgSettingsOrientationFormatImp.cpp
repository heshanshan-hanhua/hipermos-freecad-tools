﻿ /*===================================================================
 Copyright (c) 2023
 Unpublished - All rights reserved

 =====================================================================
 File description:

 =====================================================================
 Date            Name            Description of Change
 2023/05/15      LJ              Written
 2023/06/08      LJ              Fix bug in posture format settings

 HISTORY
 ====================================================================*/

#include "PreCompiled.h"
#include "DlgSettingsOrientationFormatImp.h"
#include "DlgSettingsOrientationFormat.h"
#include <Gui/PrefWidgets.h>
#include "StackControlBaseHH.h"

using namespace Gui::Dialog;

/* TRANSLATOR Gui::Dialog::DlgSettingsOrientationFormatImp */

/**
 *  Constructs a DlgSettingsOrientationFormatImp which is a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'
 */
DlgSettingsOrientationFormatImp::DlgSettingsOrientationFormatImp( QWidget* parent )
    : PreferencePage( parent )
{
    _ui = new DlgSettingsOrientationFormat();
    _ui->setupUi(this);
    connect(_ui->prefOrientationType, SIGNAL(currentIndexChanged(int)), this, SLOT(SlotOrientationFormatChanged(int)));

    if (Gui::StackControlBase().HasActiveDlg())
    {
        _ui->prefOrientationType->setEnabled(false);
    }
}

/**
 *  Destroys the object and frees any allocated resources
 */
DlgSettingsOrientationFormatImp::~DlgSettingsOrientationFormatImp()
{
    // no need to delete child widgets, Qt does it all for us
}


void DlgSettingsOrientationFormatImp::saveSettings()
{
    _ui->prefOrientationType->onSave();
}

void DlgSettingsOrientationFormatImp::loadSettings()
{
    _ui->prefOrientationType->onRestore();
}

/**
 * Sets the strings of the subwidgets using the current language.
 */
void DlgSettingsOrientationFormatImp::changeEvent(QEvent *e)
{
    if (e->type() == QEvent::LanguageChange) {
        _ui->retranslateUi(this);
    }
    else {
        QWidget::changeEvent(e);
    }
}

void Gui::Dialog::DlgSettingsOrientationFormatImp::resetSettings()
{
    _ui->prefOrientationType->setCurrentIndex(0);
}

void Gui::Dialog::DlgSettingsOrientationFormatImp::SlotOrientationFormatChanged(int index)
{

}

#include "moc_DlgSettingsOrientationFormatImp.cpp"
