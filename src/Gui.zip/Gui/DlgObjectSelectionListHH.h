/*===================================================================
Copyright (c) 2019
Unpublished - All rights reserved

=====================================================================
File description:
the dialog for select one object in list

=====================================================================
Date            Name            Description of Change
2019/10/09      WangSong        Written
2019/10/12      WangSong        fix highlight bug
2019/10/14      WangSong        code refactor
2021/08/17      LL              Upgrade
2023/10/25      HX              add GuiExport
HISTORY
====================================================================*/
#ifndef DLG_OBJECT_SELECTION_LIST_H
#define DLG_OBJECT_SELECTION_LIST_H

#include <QtGui/QtGui>
#include <boost/signal.hpp>

namespace Gui
{
    class ViewProviderDocumentObject;
    namespace Dialog
    {
        class GuiExport DlgObjectSelectionList : public QDialog
        {
            Q_OBJECT
        public:
            DlgObjectSelectionList(QWidget* parent = 0, Qt::WindowFlags fl = Qt::WindowCloseButtonHint);
            ~DlgObjectSelectionList();

            void SetSegmentsForSelection(const std::vector<std::pair<ViewProviderDocumentObject*, std::string> > &seg);

            std::pair<ViewProviderDocumentObject*, std::string> GetSelSegment() const;

            boost::signal<void(const std::pair<ViewProviderDocumentObject*, std::string>&)> signalSelectSegment;
            boost::signal<void()> signalCancelSelect;
        public Q_SLOTS:
            void CellEntered(int row, int column);
            void accept();
            virtual void reject();

        protected:
            virtual void paintEvent(QPaintEvent * event);

            void PreviewCurrentHover(int row);
            void RePreviewRow(int row);
        private:
            void _Close();
            QTableWidget* _vpTable;
            std::vector<std::pair<ViewProviderDocumentObject*, std::string> > _segments;
        };
    }
}
#endif // DLG_OBJECT_SELECTION_LIST_H